// App state holder: saves on this device and syncs with Firebase Firestore.
//
// Firestore layout (same as the claude.ai version):
//   orders/<id>, expenses/<id>, changes/<id>, att/<id>, shifts/<id>, petty/<id>
//       recent (last 3 days) or still-open records, one document each: {j: "<json>", u: <ms>}
//   arc_orders/<yyyy-mm-dd>[_n] ...   older finished records packed per day: {j: "[<json>,...]"}
//   menu/<id>, stock/<id>, tasks/<id>, staff/<id>   {j: "{i: order, x: item}"}
//   cfg/main   {j: "{hours, prep, rent}"}
// Photos (clock-in/out, receipts, dish photos) are NOT uploaded: they stay on the device that took them.
import 'dart:async';
import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'consts.dart';
import 'util.dart';

const _kState = 'niuma_state_v4';
const _kPhotoIdx = 'niuma_photo_index_v1';
const _hotDays = 3;

final Map<String, num Function(dynamic)> _grow = {
  'orders': (o) => N(o['t']),
  'expenses': (e) => e['at'] != null ? N(e['at']) : isoMs(Str(e['date']), '12:00'),
  'changes': (c) => N(c['at']),
  'att': (a) => N(a['inAt']),
  'shifts': (s) => N(s['openedAt']),
  'petty': (p) => N(p['openedAt']),
};
final Map<String, bool Function(dynamic)> _live = {
  'orders': (o) => o['status'] == 'pending' || (o['paid'] != true && o['status'] != 'voided'),
  'att': (a) => a['outAt'] == null,
  'shifts': (s) => s['closedAt'] == null || (s['tngOpenedAt'] != null && s['tngClosedAt'] == null),
  'petty': (p) => p['closedAt'] == null,
};
const _small = ['menu', 'stock', 'tasks', 'staff'];
// Photo fields kept only on this device.
const Map<String, List<String>> _photoFields = {
  'att': ['inPhoto', 'outPhoto'],
  'expenses': ['photo'],
  'menu': ['photo'],
};
// Settings that belong to this device only.
const _localOnly = ['lang', 'tab', 'cart', 'channel', 'note', 'tag', 'orderDisc', 'cat', 'range', 'delPlat', 'delSeg', 'expMonth'];

class Store extends ChangeNotifier {
  static final Store I = Store._();
  Store._();

  SharedPreferences? _prefs;
  FirebaseFirestore? _db;
  final Map<String, String> _r = {}; // what Firestore has (incl. this device's unconfirmed writes)
  Map<String, String> _a = {}; // what S was last built from / pushed
  final Map<String, String> _photos = {};
  final Set<String> _got = {};
  final List<StreamSubscription> _subs = [];
  bool on = false, ro = false, _defer = false, _offline = false;
  int _writing = 0, dialogs = 0;
  String state = 'local'; // local | connecting | ok | saving | offline | ro
  String toastMsg = '';
  String toastIcon = 'check';
  int toastAt = 0;

  /* ---------- local ---------- */
  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    S = freshState();
    try {
      final raw = _prefs!.getString(_kState);
      if (raw != null) {
        final m = jsonDecode(raw) as Map<String, dynamic>;
        S.addAll(m);
      }
    } catch (_) {}
    try {
      for (final k in (_prefs!.getStringList(_kPhotoIdx) ?? const <String>[])) {
        final v = _prefs!.getString('ph:$k');
        if (v != null) _photos[k] = v;
      }
    } catch (_) {}
    _attachPhotos();
  }

  Map<String, dynamic> _stripped() {
    final c = deepCopy(S) as Map<String, dynamic>;
    _photoFields.forEach((coll, fields) {
      for (final x in L(c[coll])) {
        for (final f in fields) {
          (x as Map).remove(f);
        }
      }
    });
    return c;
  }

  void _collectPhotos() {
    final keep = <String>{};
    final cutAtt = now() - 60 * kDay, cutExp = now() - 120 * kDay;
    _photoFields.forEach((coll, fields) {
      for (final x in L(S[coll])) {
        for (final f in fields) {
          final v = x[f];
          if (v is! String || v.isEmpty) continue;
          if (coll == 'att' && N(x['inAt']) < cutAtt) continue; // old attendance photos are dropped to save space
          if (coll == 'expenses' && isoMs(Str(x['date'])) < cutExp) continue;
          final k = '$coll:${x['id']}:$f';
          keep.add(k);
          if (_photos[k] != v) {
            _photos[k] = v;
            _prefs?.setString('ph:$k', v);
          }
        }
      }
    });
    for (final k in _photos.keys.toList()) {
      if (!keep.contains(k)) {
        _photos.remove(k);
        _prefs?.remove('ph:$k');
      }
    }
    _prefs?.setStringList(_kPhotoIdx, _photos.keys.toList());
  }

  void _attachPhotos() {
    _photoFields.forEach((coll, fields) {
      for (final x in L(S[coll])) {
        for (final f in fields) {
          final v = _photos['$coll:${x['id']}:$f'];
          if (v != null) x[f] = v;
        }
      }
    });
  }

  void _localSave() {
    try {
      _collectPhotos();
      _prefs?.setString(_kState, jsonEncode(_stripped()));
    } catch (_) {
      toast('Storage full: remove some photos', 'alert');
    }
  }

  /// Save after every change (like save() in the web app).
  void save() {
    _localSave();
    _push();
    notifyListeners();
  }

  /// Re-draw only (no data change).
  void refresh() => notifyListeners();

  void toast(String msg, [String icon = 'check']) {
    toastMsg = msg;
    toastIcon = icon;
    toastAt = now();
    notifyListeners();
  }

  /* ---------- sync map ---------- */
  String _seg(dynamic id) {
    final s = Str(id).replaceAll(RegExp(r'[^A-Za-z0-9_\-.~:@+]'), '_');
    return s.isEmpty ? '_' : s;
  }

  Map<String, String> _toMap() {
    final src = _stripped();
    final m = <String, String>{};
    final cut = dayStart(now()) - (_hotDays - 1) * kDay;
    _grow.forEach((c, at) {
      final arc = <String, List<dynamic>>{};
      for (final x in L(src[c])) {
        final ms = at(x);
        if (ms >= cut || (_live[c]?.call(x) ?? false)) {
          m['$c/${_seg(x['id'])}'] = jsonEncode(x);
        } else {
          arc.putIfAbsent(isoDate(ms), () => []).add(x);
        }
      }
      // one document per day, split so no document gets near Firestore's 1 MB limit
      arc.forEach((d, list) {
        list.sort((a, b) => Str(a['id']).compareTo(Str(b['id'])));
        var part = <String>[];
        var size = 0, k = 0;
        void put() {
          if (part.isNotEmpty) m['arc_$c/$d${k > 0 ? '_$k' : ''}'] = '[${part.join(',')}]';
          part = [];
          size = 0;
          k++;
        }

        for (final x in list) {
          final j = jsonEncode(x);
          if (size + j.length > 400000) put();
          part.add(j);
          size += j.length;
        }
        put();
      });
    });
    for (final c in _small) {
      final l = L(src[c]);
      for (var i = 0; i < l.length; i++) {
        m['$c/${_seg(l[i]['id'])}'] = jsonEncode({'i': i, 'x': l[i]});
      }
    }
    m['cfg/main'] = jsonEncode({'hours': src['hours'], 'prep': src['prep'], 'rent': src['rent']});
    return m;
  }

  void _fromMap(Map<String, String> m) {
    final g = {for (final c in _grow.keys) c: <String, dynamic>{}};
    final sm = {for (final c in _small) c: <Map<String, dynamic>>[]};
    for (final e in m.entries) {
      final c = e.key.split('/').first;
      if (!c.startsWith('arc_')) continue;
      final cc = c.substring(4);
      if (!g.containsKey(cc)) continue;
      try {
        for (final x in jsonDecode(e.value) as List) {
          g[cc]![Str(x['id'])] = x;
        }
      } catch (_) {}
    }
    for (final e in m.entries) {
      final c = e.key.split('/').first;
      try {
        if (g.containsKey(c)) {
          final x = jsonDecode(e.value);
          g[c]![Str(x['id'])] = x;
        } else if (sm.containsKey(c)) {
          sm[c]!.add(jsonDecode(e.value) as Map<String, dynamic>);
        } else if (c == 'cfg') {
          final f = jsonDecode(e.value) as Map<String, dynamic>;
          if (f['hours'] != null) S['hours'] = f['hours'];
          if (f['prep'] != null) S['prep'] = f['prep'];
          if (f['rent'] != null) S['rent'] = f['rent'];
        }
      } catch (_) {}
    }
    g.forEach((c, byId) {
      final list = byId.values.toList()..sort((a, b) => _grow[c]!(a).compareTo(_grow[c]!(b)));
      S[c] = c == 'changes' ? list.reversed.toList() : list;
    });
    sm.forEach((c, list) {
      list.sort((a, b) => N(a['i']).compareTo(N(b['i'])));
      S[c] = list.map((q) => q['x']).toList();
    });
    _attachPhotos();
  }

  // Push only what this device changed since it last took in the shared data,
  // so other devices' new orders are never removed.
  void _push() {
    if (!on || ro || _db == null) return;
    final m = _toMap();
    for (final e in m.entries) {
      if (_a[e.key] != e.value) {
        _a[e.key] = e.value;
        _write(e.key, e.value);
      }
    }
    for (final p in _a.keys.toList()) {
      if (!m.containsKey(p)) {
        _a.remove(p);
        _write(p, null);
      }
    }
  }

  void _write(String path, String? v) {
    final parts = path.split('/');
    final ref = _db!.collection(parts[0]).doc(parts[1]);
    _writing++;
    _paint();
    final Future<void> f = v == null ? ref.delete() : ref.set({'j': v, 'u': now()});
    f.then((_) {
      _writing--;
      _paint();
    }).catchError((Object e) {
      _writing--;
      if (e is FirebaseException && e.code == 'permission-denied') {
        ro = true;
      }
      _paint();
    });
  }

  void _paint() {
    final s = ro ? 'ro' : (_db == null ? 'local' : (!on ? 'connecting' : (_offline ? 'offline' : (_writing > 0 ? 'saving' : 'ok'))));
    if (s != state) {
      state = s;
      notifyListeners();
    }
  }

  void _apply({bool force = false}) {
    if (!on) return;
    if (!force && dialogs > 0) {
      _defer = true;
      return;
    }
    _defer = false;
    final local = {for (final k in _localOnly) k: S[k]};
    _fromMap(_r);
    S.addAll(local);
    _a = Map<String, String>.from(_r);
    _localSave();
    notifyListeners();
  }

  /// Dialogs call this when they close, so changes from other devices that came in meanwhile are shown.
  void dialogClosed() {
    dialogs = dialogs > 0 ? dialogs - 1 : 0;
    if (dialogs == 0 && _defer) _apply();
  }

  /* ---------- start / stop (after sign-in) ---------- */
  Future<void> start() async {
    await stop();
    final db = FirebaseFirestore.instance;
    _db = db;
    state = 'connecting';
    notifyListeners();
    bool? first;
    try {
      final d = await db.doc('cfg/main').get(const GetOptions(source: Source.server)).timeout(const Duration(seconds: 10));
      first = !d.exists;
    } catch (_) {
      try {
        final d = await db.doc('cfg/main').get(const GetOptions(source: Source.cache));
        if (d.exists) first = false;
      } catch (_) {}
    }
    if (first == null) {
      // offline and nothing cached yet: keep working on this device and try again
      state = 'offline';
      notifyListeners();
      Timer(const Duration(seconds: 10), () {
        if (_db == db && !on) start();
      });
      return;
    }
    if (first) {
      on = true;
      _a = {};
      _push();
    }
    final cols = [..._grow.keys, ..._grow.keys.map((c) => 'arc_$c'), ..._small];
    final need = cols.length + 1;
    void done(String k) {
      if (_got.contains(k)) {
        _apply();
        return;
      }
      _got.add(k);
      if (_got.length >= need) {
        if (!on) {
          on = true;
          _apply(force: true);
        } else {
          _apply();
        }
        _paint();
      }
    }

    for (final c in cols) {
      _subs.add(db.collection(c).snapshots(includeMetadataChanges: true).listen((snap) {
        _offline = snap.metadata.isFromCache;
        if (snap.docChanges.isEmpty && _got.contains(c)) {
          _paint();
          return;
        }
        _r.removeWhere((p, _) => p.startsWith('$c/'));
        for (final d in snap.docs) {
          final v = d.data()['j'];
          if (v is String) _r['$c/${d.id}'] = v;
        }
        done(c);
      }, onError: (Object e) {
        if (e is FirebaseException && e.code == 'permission-denied') ro = true;
        _offline = true;
        _paint();
      }));
    }
    _subs.add(db.doc('cfg/main').snapshots().listen((d) {
      final v = d.data()?['j'];
      if (d.exists && v is String) {
        _r['cfg/main'] = v;
      } else {
        _r.remove('cfg/main');
      }
      done('cfg');
    }, onError: (Object e) {
      _offline = true;
      _paint();
    }));
  }

  Future<void> stop() async {
    for (final s in _subs) {
      await s.cancel();
    }
    _subs.clear();
    _got.clear();
    _r.clear();
    _a = {};
    on = false;
    ro = false;
    _db = null;
    state = 'local';
  }
}

Store get store => Store.I;
void save() => Store.I.save();
void toast(String msg, [String icon = 'check']) => Store.I.toast(msg, icon);

// Silence unused import warnings in release builds.
const bool kIsWebBuild = kIsWeb;

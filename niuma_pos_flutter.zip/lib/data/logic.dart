// Business rules, ported one-to-one from the web app (core.js / views.js / actions.js).
import 'consts.dart';
import 'util.dart';

Map<String, dynamic>? item(dynamic id) {
  for (final m in menuList) {
    if (m['id'] == id) return m as Map<String, dynamic>;
  }
  return null;
}

/* ---------- money ---------- */
num lineBase(dynamic l) {
  final it = item(l['id']);
  if (it == null) return N(l['base']);
  num s = (l['big'] == true && it['pb'] != null) ? N(it['pb']) : N(it['ps']);
  for (final a in L(l['addons'])) {
    s += N(item(a)?['ps']);
  }
  return s;
}

num lineUnit(dynamic l) => l['price'] != null ? N(l['price']) : lineBase(l);
num cartSub() => cart.fold<num>(0, (s, l) => s + lineUnit(l) * N(l['qty']));
num cartBaseSub() => cart.fold<num>(0, (s, l) => s + lineBase(l) * N(l['qty']));
num orderDiscAmt(num sub, dynamic d) {
  if (d == null) return 0;
  final v = d['mode'] == 'pct' ? sub * N(d['v']) / 100 : N(d['v']);
  return v < sub ? v : sub;
}

num cartTotal() {
  final sub = cartSub();
  final v = sub - orderDiscAmt(sub, S['orderDisc']);
  return v < 0 ? 0 : v;
}

int cartCount() => cart.fold<int>(0, (s, l) => s + I(l['qty']));
num oSub(dynamic o) => L(o['lines']).fold<num>(0, (s, l) => s + N(l['unit']) * N(l['qty']));
bool isDel(dynamic o) => kDelivery.contains(o['ch']);
num oShop(dynamic o) {
  final v = oSub(o) - N(o['disc']);
  return v < 0 ? 0 : v;
}

// Delivery orders: the app's marked-up price until settled, then the amount actually received.
num oTotal(dynamic o) => isDel(o) ? N(o['received'] ?? o['gross'] ?? oShop(o)) : oShop(o);
num oCollected(dynamic o) => o['paid'] == true && o['status'] != 'voided' ? oTotal(o) : 0;
num oFee(dynamic o) =>
    isDel(o) && o['paid'] == true && o['received'] != null && o['gross'] != null ? N(o['gross']) - N(o['received']) : 0;

num itemApp(dynamic it, bool big, String ch) {
  if (it == null || !kDelivery.contains(ch)) return 0;
  final a = Mp(Mp(it['app'])[ch]);
  final f = kAppF[ch]!;
  final v = big && it['pb'] != null ? (a['pb'] ?? appRound(N(it['pb']), f)) : (a['ps'] ?? appRound(N(it['ps']), f));
  return N(v);
}

Map<String, dynamic>? dOpt(dynamic id) {
  for (final o in L(S['delOpts'])) {
    if (o['id'] == id) return o as Map<String, dynamic>;
  }
  return null;
}

num optApp(dynamic o, String ch) => N(Mp(o?['app'])[ch]);
num lineApp(dynamic l, [String? ch]) {
  final c = ch ?? Str(S['channel']);
  num s = itemApp(item(l['id']), l['big'] == true, c);
  for (final a in L(l['addons'])) {
    s += itemApp(item(a), false, c);
  }
  for (final o in L(l['opts'])) {
    s += optApp(dOpt(o), c);
  }
  return s;
}

num cartApp() => cart.fold<num>(0, (s, l) => s + lineApp(l) * N(l['qty']));
num oApp(dynamic o) => L(o['lines'])
    .fold<num>(0, (s, l) => s + N(l['app'] ?? appRound(N(l['unit']), kAppF[o['ch']] ?? 1.2)) * N(l['qty']));
bool isOverdue(dynamic o) => isDel(o) && o['status'] == 'pending' && o['due'] != null && now() > N(o['due']);
num oDiscount(dynamic o) =>
    L(o['lines']).fold<num>(0, (s, l) => s + (N(l['base']) - N(l['unit'])) * N(l['qty'])) + N(o['disc']);
String lineName(dynamic l) => nm(l['names']) + (l['hasSize'] == true ? ' (${t(l['big'] == true ? 'big' : 'small')})' : '');
String lineAddons(dynamic l) => L(l['addons']).map(nm).join(', ');
String choiceLabel(String g, dynamic v) {
  final G = kGroups[g];
  if (G == null) return '';
  List<dynamic>? o;
  for (final x in G['opts'] as List) {
    if (x[0] == v) o = x as List<dynamic>;
  }
  if (o == null) return '';
  return g == 'milk' || g == 'alcohol' ? '${nm(G['names'])}: ${nm(o[1])}' : nm(o[1]);
}

List<String> choiceList(dynamic l) =>
    Mp(l['choices']).entries.map((e) => choiceLabel(e.key, e.value)).where((s) => s.isNotEmpty).toList();
String? _codeOf(dynamic l) {
  final c = l['code'] ?? item(l['id'])?['code'];
  return c == null || Str(c).isEmpty ? null : Str(c);
}

String lineCode(dynamic l) {
  final code = _codeOf(l);
  return code != null ? code + Str(Mp(l['choices'])['noodle']) : nm(l['names']);
}

List<String> codeChoices(dynamic l) => Mp(l['choices'])
    .entries
    .where((e) => e.key != 'noodle' || _codeOf(l) == null)
    .map((e) => choiceLabel(e.key, e.value))
    .where((s) => s.isNotEmpty)
    .toList();
String sizeWord(dynamic l) => l['hasSize'] == true ? t(l['big'] == true ? 'big' : 'small') : '';
String lineText(dynamic l) => [
      sizeWord(l),
      ...codeChoices(l),
      ...L(l['addons']).map((a) => '+ ${nm(a)}'),
      ...L(l['opts']).map((o) => nm(o['names'])),
    ].where((s) => s.isNotEmpty).join(', ');
String orderCodes(dynamic o) => L(o['lines']).map((l) {
      final q = N(l['qty']) > 1 ? '${l['qty']}× ' : '';
      final big = l['hasSize'] == true && l['big'] == true ? ' ${t('big')}' : '';
      final ad = L(l['addons']).isNotEmpty ? ' + ${L(l['addons']).map(nm).join(' + ')}' : '';
      final op = L(l['opts']).isNotEmpty ? ' + ${L(l['opts']).map((x) => nm(x['names'])).join(' + ')}' : '';
      return q + lineCode(l) + big + ad + op;
    }).join(', ');
String dueText(dynamic o) {
  if (o['due'] == null) return t('pending');
  final left = N(o['due']) - now();
  return left >= 0 ? '${fmtLeft(left)} ${t('left')}' : '${t('overdue')} ${fmtLeft(left)}';
}

int pendingCount() => orders.where((o) => o['status'] == 'pending').length;
List<dynamic> unpaidOrders() => orders.where((o) => o['paid'] != true && o['status'] != 'voided').toList();
int nextNo() => orders.where((o) => sameDay(N(o['t']), now())).fold<int>(0, (a, o) => I(o['n']) > a ? I(o['n']) : a) + 1;
Map<String, dynamic>? curShift() {
  for (final s in shifts) {
    if (s['closedAt'] == null) return s as Map<String, dynamic>;
  }
  return null;
}

bool todayClosed() => shifts.any((s) => s['closedAt'] != null && sameDay(N(s['openedAt']), now()));
Map<String, dynamic>? shiftById(dynamic id) {
  for (final s in shifts) {
    if (s['id'] == id) return s as Map<String, dynamic>;
  }
  return null;
}

Map<String, dynamic>? pettyById(dynamic id) {
  for (final s in petty) {
    if (s['id'] == id) return s as Map<String, dynamic>;
  }
  return null;
}

Map<String, dynamic>? orderById(dynamic id) {
  for (final s in orders) {
    if (s['id'] == id) return s as Map<String, dynamic>;
  }
  return null;
}

// TNG runs until it is closed (it may be closed after the day close), or until the next day's TNG register opens.
num tngEnd(dynamic sh) {
  if (sh['tngClosedAt'] != null) return N(sh['tngClosedAt']);
  final next = shifts.where((x) => N(x['openedAt']) > N(sh['openedAt']) && x['tngOpenedAt'] != null).toList()
    ..sort((a, b) => N(a['openedAt']).compareTo(N(b['openedAt'])));
  return next.isNotEmpty ? N(next.first['tngOpenedAt']) : now();
}

num shiftSales(dynamic sh, String method) {
  final from = method == 'tng' ? sh['tngOpenedAt'] : sh['openedAt'];
  if (from == null) return 0;
  final to = sh['closedAt'] != null ? N(sh['closedAt']) : now();
  return orders
      .where((o) =>
          o['paid'] == true && o['status'] != 'voided' && o['pay'] == method && N(o['paidAt']) >= N(from) && N(o['paidAt']) <= to)
      .fold<num>(0, (s, o) => s + oTotal(o));
}

num expAt(dynamic e) => e['at'] != null ? N(e['at']) : isoMs(Str(e['date']), '12:00');
// money out of a register through expenses (income paid into it counts as money in)
num regFlow(String method, num from, num to) => expenses
    .where((e) => e['paidBy'] == method && expAt(e) >= from && expAt(e) <= to)
    .fold<num>(0, (s, e) => s + (e['cat'] == 'income' ? -N(e['amount']) : N(e['amount'])));
List<dynamic> regItems(String method, num from, num to) =>
    expenses.where((e) => e['paidBy'] == method && expAt(e) >= from && expAt(e) <= to).toList()
      ..sort((a, b) => expAt(b).compareTo(expAt(a)));
num cashSpent(dynamic sh) => regFlow('cash', N(sh['openedAt']), sh['closedAt'] != null ? N(sh['closedAt']) : now());
num tngSpent(dynamic sh) => sh['tngOpenedAt'] != null ? regFlow('tng', N(sh['tngOpenedAt']), tngEnd(sh)) : 0;
num expCash(dynamic sh) => N(sh['openTotal']) + shiftSales(sh, 'cash') - cashSpent(sh);
num? expTng(dynamic sh) => sh['tngOpenedAt'] != null ? N(sh['openTng']) + shiftSales(sh, 'tng') - tngSpent(sh) : null;
Map<String, dynamic>? lastShift() {
  if (shifts.isEmpty) return null;
  final l = [...shifts]..sort((a, b) => N(b['openedAt']).compareTo(N(a['openedAt'])));
  return l.first as Map<String, dynamic>;
}

/* ---- opening hours, off days, attendance ---- */
bool isOffDay(num ms) {
  final d = dt(ms);
  return d.weekday == DateTime.tuesday && L(hours['offTue']).map(N).contains((d.day / 7).ceil());
}

/// {k: open|break|before|off|after, until/at: ms}
Map<String, dynamic> bizStatus([int? at]) {
  final n = at ?? now();
  if (isOffDay(n)) return {'k': 'off'};
  final w = L(hours['open']).map((x) => [atHM(n, Str(x[0])), atHM(n, Str(x[1]))]).toList();
  for (var i = 0; i < w.length; i++) {
    if (n >= w[i][0] && n < w[i][1]) return {'k': 'open', 'until': w[i][1]};
    if (n < w[i][0]) return {'k': i > 0 ? 'break' : 'before', 'at': w[i][0]};
  }
  return {'k': 'after'};
}

int? nextOffDay() {
  for (var d = 0; d < 60; d++) {
    final ms = dayStart(now()) + d * kDay;
    if (isOffDay(ms)) return ms;
  }
  return null;
}

Map<String, dynamic>? attToday(dynamic id) {
  for (final a in att) {
    if (a['staff'] == id && sameDay(N(a['inAt']), now())) return a as Map<String, dynamic>;
  }
  return null;
}

bool clockedIn() => att.any((a) => sameDay(N(a['inAt']), now()) && a['outAt'] == null);
int lateMin(dynamic a) => ((N(a['inAt']) - atHM(N(a['inAt']), Str(hours['clockIn']))) / 60000).round();
int earlyMin(dynamic a) =>
    a['outAt'] != null ? ((atHM(N(a['inAt']), Str(hours['clockOut'])) - N(a['outAt'])) / 60000).round() : 0;
String staffName(dynamic id) {
  for (final s in staffList) {
    if (s['id'] == id) return Str(s['name']);
  }
  return '?';
}

Map<String, dynamic>? curPetty() {
  for (final p in petty) {
    if (p['closedAt'] == null) return p as Map<String, dynamic>;
  }
  return null;
}

num pettySpent(dynamic ps) => regFlow('petty', N(ps['openedAt']), ps['closedAt'] != null ? N(ps['closedAt']) : now());
num pettyExpected(dynamic ps) => N(ps['openTotal']) - pettySpent(ps);
List<dynamic> pettyItems(dynamic ps) => regItems('petty', N(ps['openedAt']), ps['closedAt'] != null ? N(ps['closedAt']) : now());

bool _onIso(num ms, String iso) => isoDate(ms) == iso;
// Which moment an expense is booked at, so it lands inside the right register (also when entered after closing).
num bookAt(dynamic e) {
  final date = Str(e['date']);
  final num base = date == isoDate(now()) ? now() : isoMs(date, '12:00');
  num clamp(num v, num lo, num hi) {
    final a = lo + 1000, b = hi - 1000;
    return v < a ? a : (v > b ? b : v);
  }

  if (e['paidBy'] == 'cash') {
    for (final sh in shifts) {
      if (_onIso(N(sh['openedAt']), date)) return clamp(base, N(sh['openedAt']), sh['closedAt'] != null ? N(sh['closedAt']) : now());
    }
  }
  if (e['paidBy'] == 'tng') {
    for (final sh in shifts) {
      if (_onIso(N(sh['openedAt']), date) && sh['tngOpenedAt'] != null) return clamp(base, N(sh['tngOpenedAt']), tngEnd(sh));
    }
  }
  if (e['paidBy'] == 'petty') {
    final end = isoMs(date, '23:59:59');
    dynamic ps;
    for (final p in petty) {
      if (base >= N(p['openedAt']) && base <= (p['closedAt'] != null ? N(p['closedAt']) : now())) {
        ps = p;
        break;
      }
    }
    if (ps == null) {
      final before = petty.where((p) => N(p['openedAt']) <= end).toList()
        ..sort((a, b) => N(b['openedAt']).compareTo(N(a['openedAt'])));
      if (before.isNotEmpty) ps = before.first;
    }
    if (ps != null) return clamp(base, N(ps['openedAt']), ps['closedAt'] != null ? N(ps['closedAt']) : now());
  }
  return base;
}

/// Which register an expense falls in: {kind, day, closed}
Map<String, dynamic>? regOf(dynamic e) {
  final at = e['at'] != null ? N(e['at']) : bookAt(e);
  if (e['paidBy'] == 'cash') {
    for (final sh in shifts) {
      if (at >= N(sh['openedAt']) && at <= (sh['closedAt'] != null ? N(sh['closedAt']) : now())) {
        return {'kind': 'cash', 'day': sh['openedAt'], 'closed': sh['closedAt'] != null};
      }
    }
    return null;
  }
  if (e['paidBy'] == 'tng') {
    for (final sh in shifts) {
      if (sh['tngOpenedAt'] != null && at >= N(sh['tngOpenedAt']) && at <= tngEnd(sh)) {
        return {'kind': 'tng', 'day': sh['openedAt'], 'closed': sh['tngClosedAt'] != null};
      }
    }
    return null;
  }
  if (e['paidBy'] == 'petty') {
    for (final p in petty) {
      if (at >= N(p['openedAt']) && at <= (p['closedAt'] != null ? N(p['closedAt']) : now())) {
        return {'kind': 'petty', 'day': p['openedAt'], 'closed': p['closedAt'] != null};
      }
    }
  }
  return null;
}

const Map<String, String> kRegName = {'cash': 'regCash', 'tng': 'regTng', 'petty': 'regVege'};

/* ---- changes made after a register was closed: logged so the owner sees what moved ---- */
Map<String, Map<String, dynamic>> regSnap() {
  final m = <String, Map<String, dynamic>>{};
  for (final sh in shifts) {
    if (sh['closedAt'] == null) continue;
    m['cash|${sh['id']}'] = {'reg': 'cash', 'id': sh['id'], 'day': sh['openedAt'], 'exp': expCash(sh), 'cnt': sh['closeTotal']};
    if (sh['tngOpenedAt'] != null) {
      m['tng|${sh['id']}'] = {
        'reg': 'tng', 'id': sh['id'], 'day': sh['openedAt'], 'exp': expTng(sh),
        'cnt': sh['tngClosedAt'] != null ? sh['closeTng'] : null
      };
    }
  }
  for (final p in petty) {
    if (p['closedAt'] != null) {
      m['petty|${p['id']}'] = {'reg': 'petty', 'id': p['id'], 'day': p['openedAt'], 'exp': pettyExpected(p), 'cnt': p['closeTotal']};
    }
  }
  return m;
}

/// Runs [fn]; if it moved a closed register, logs it. Returns true when something was logged.
bool track(String ref, void Function() fn, String Function() descFn) {
  final b = regSnap();
  fn();
  final a = regSnap();
  final fx = <dynamic>[];
  a.forEach((k, v) {
    final before = b[k];
    if (before == null) return;
    final d = r2(N(v['exp']) - N(before['exp']));
    if (d.abs() > .004) {
      fx.add(<String, dynamic>{
        'k': k, 'reg': v['reg'], 'id': v['id'], 'day': v['day'],
        'from': r2(N(before['exp'])), 'to': r2(N(v['exp'])), 'cnt': v['cnt'],
      });
    }
  });
  if (fx.isEmpty) return false;
  changes.insert(0, <String, dynamic>{'id': uid('c'), 'at': now(), 'ref': ref, 'desc': descFn(), 'fx': fx});
  return true;
}

String orderDesc(dynamic b, dynamic o) {
  final parts = <String>[];
  final tb = b['paid'] == true && b['status'] != 'voided' ? oTotal(b) : 0;
  final ta = o['paid'] == true && o['status'] != 'voided' ? oTotal(o) : 0;
  if (o['status'] == 'voided' && b['status'] != 'voided') {
    parts.add(t('chVoid').replaceAll('{x}', rm(tb)));
  } else {
    if (b['pay'] != o['pay']) parts.add('${t('pay_${b['pay']}')} → ${t('pay_${o['pay']}')}');
    if ((tb - ta).abs() > .004) {
      parts.add('${rm(tb)} → ${rm(ta)}${N(o['disc']) > N(b['disc']) ? ' (${t('discount')})' : ''}');
    }
  }
  return parts.isEmpty ? t('chEdited') : parts.join(' · ');
}

bool trackOrder(Map<String, dynamic> o, void Function() fn) {
  final b = deepCopy(o);
  return track('#${o['n']} · ${fmtD(N(o['t']))}', fn, () => orderDesc(b, o));
}

String expDesc(dynamic o, dynamic n) {
  if (o == null) return '${t('chAdded')} ${rm(n['amount'])} · ${t('paid_${n['paidBy']}')}';
  if (n == null) return '${t('chDeleted')} ${rm(o['amount'])} · ${t('paid_${o['paidBy']}')}';
  final p = <String>[];
  if (o['paidBy'] != n['paidBy']) p.add('${t('paid_${o['paidBy']}')} → ${t('paid_${n['paidBy']}')}');
  if ((N(o['amount']) - N(n['amount'])).abs() > .004) p.add('${rm(o['amount'])} → ${rm(n['amount'])}');
  if (o['date'] != n['date']) p.add('${fmtD(expAt(o))} → ${fmtD(expAt(n))}');
  return p.isEmpty ? t('chEdited') : p.join(' · ');
}

/* ---- clock out checklist ---- */
Map<String, dynamic>? todayShift() {
  for (final x in shifts) {
    if (sameDay(N(x['openedAt']), now())) return x as Map<String, dynamic>;
  }
  return null;
}

/* ---- Telegram message ---- */
String oosText(dynamic sh, List<dynamic> outs) => t('tgMsg')
    .replaceAll('{d}', fmtD(N(sh['closedAt'])))
    .replaceAll('{x}', outs.isNotEmpty ? outs.map((x) => '${nm(x['names'])} (0 ${x['unit']})').join(', ') : t('waNoneOut'));

String sizePrice(dynamic it) => it['pb'] != null
    ? '${t('small')} ${rm0(it['ps'])} · ${t('big')} ${rm0(it['pb'])}'
    : '${it['isAddon'] == true ? '+' : ''}${rm0(it['ps'])}';

String offTxt() => L(hours['offTue']).isNotEmpty
    ? t('offTueTxt').replaceAll('{w}', L(hours['offTue']).map((w) => t('wk$w')).join(' & '))
    : '–';

/* ---- dashboard range ---- */
List<int> rangeBounds() {
  final n = now(), td = dayStart(n), r = Mp(S['range']);
  if (r['preset'] == 'date' && Str(r['date']).isNotEmpty) {
    final s = dayStart(isoMs(Str(r['date'])));
    return [s, s + kDay, 1];
  }
  if (r['preset'] == 'yesterday') return [td - kDay, td, 1];
  if (r['preset'] == 'week') {
    final wd = dt(td).weekday - 1;
    return [td - wd * kDay, td + kDay, wd + 1];
  }
  if (r['preset'] == 'month') {
    final d = dt(td);
    final s = DateTime(d.year, d.month, 1).millisecondsSinceEpoch;
    return [s, td + kDay, ((td + kDay - s) / kDay).round()];
  }
  return [td, td + kDay, 1];
}

/* ---- order creation ---- */
Map<String, dynamic> buildOrder() {
  final n = now(), no = nextNo();
  final sub = cartSub(), disc = orderDiscAmt(sub, S['orderDisc']);
  final ch = Str(S['channel']);
  final lines = cart.map((l) {
    final it = item(l['id'])!;
    return <String, dynamic>{
      'id': it['id'], 'code': it['code'], 'names': deepCopy(it['names']), 'big': l['big'] == true,
      'hasSize': it['pb'] != null && it['isAddon'] != true, 'choices': deepCopy(Mp(l['choices'])),
      'addons': L(l['addons']).map((a) => deepCopy(item(a)?['names'] ?? <String, dynamic>{})).toList(),
      'opts': L(l['opts']).map((o) => <String, dynamic>{'names': deepCopy(dOpt(o)?['names']), 'app': optApp(dOpt(o), ch)}).toList(),
      'qty': l['qty'], 'base': lineBase(l), 'unit': lineUnit(l),
      'app': kDelivery.contains(ch) ? lineApp(l, ch) : null,
      'reason': l['price'] != null ? l['reason'] : null,
    };
  }).toList();
  final o = <String, dynamic>{
    'id': uid('o'), 'n': no, 't': n, 'ch': ch, 'lines': lines, 'disc': r2(disc),
    'discReason': S['orderDisc']?['reason'], 'note': Str(S['note']).trim(), 'tag': Str(S['tag']).trim(),
    'status': 'pending', 'paid': false, 'pay': null, 'paidAt': null,
  };
  if (kDelivery.contains(ch)) {
    o['gross'] = oApp(o);
    o['due'] = n + I(Mp(S['prep'])[ch] ?? 15) * 60000;
  }
  orders.add(o);
  S['cart'] = <dynamic>[];
  S['note'] = '';
  S['tag'] = '';
  S['orderDisc'] = null;
  return o;
}

String sigOf(dynamic l) =>
    '${l['id']}|${l['big']}|${L(l['addons']).join(',')}|${L(l['opts']).join(',')}|${Mp(l['choices']).entries.map((e) => '${e.key}=${e.value}').join(',')}';

void addToCart(Map<String, dynamic> line) {
  for (final l in cart) {
    if (sigOf(l) == sigOf(line) && l['price'] == null) {
      l['qty'] = I(l['qty']) + I(line['qty']);
      return;
    }
  }
  cart.add(line);
}

Map<String, num> draftTotals(Map<String, dynamic> d) {
  final sub = L(d['lines']).fold<num>(0, (s, l) => s + N(l['unit']) * N(l['qty']));
  final base = L(d['lines']).fold<num>(0, (s, l) => s + N(l['base']) * N(l['qty']));
  final disc = N(d['disc']) < sub ? N(d['disc']) : sub;
  final total = sub - disc < 0 ? 0 : sub - disc;
  return {'sub': sub, 'base': base, 'disc': disc, 'total': total, 'saved': base - sub + disc};
}

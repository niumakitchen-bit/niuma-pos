import 'package:flutter/material.dart';

import '../../data/logic.dart';
import '../../data/util.dart';
import '../actions.dart';
import '../theme.dart';
import '../widgets.dart';
import 'kitchen.dart';

class AttendancePage extends StatefulWidget {
  const AttendancePage({super.key});
  @override
  State<AttendancePage> createState() => _AttendancePageState();
}

class _AttendancePageState extends State<AttendancePage> {
  int page = 0;

  (Widget, Widget) _tags(dynamic a) {
    final l = lateMin(a), e = earlyMin(a);
    final inTag = l > 0 ? Tag(t('lateM').replaceAll('{n}', '$l'), kind: TK.bad) : Tag(t('onTime'), kind: TK.ok);
    final outTag = a['outAt'] == null
        ? Tag(t('notOut'), kind: TK.warn)
        : e > 0
            ? Tag(t('earlyM').replaceAll('{n}', '$e'), kind: TK.bad)
            : Tag(t('onTime'), kind: TK.ok);
    return (inTag, outTag);
  }

  @override
  Widget build(BuildContext context) {
    final nOff = nextOffDay();
    final today = [
      for (final st in staffList)
        Builder(builder: (_) {
          final a = attToday(st['id']);
          final tg = a != null ? _tags(a) : null;
          return CardBox(
            child: Row(children: [
              Thumb(a?['inPhoto'] as String?, Str(st['name'])),
              hgap(12),
              Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(Str(st['name']), style: ts(16, w: w8)),
                gap(4),
                a == null
                    ? Text(t('notIn'), style: ts(13.5, c: C.muted))
                    : Wrap(spacing: 6, runSpacing: 4, crossAxisAlignment: WrapCrossAlignment.center, children: [
                        Text('${t('clockIn')} ${fmtT(N(a['inAt']))}', style: ts(13.5, c: C.muted)),
                        tg!.$1,
                        if (a['outAt'] != null) ...[Text('· ${t('clockOut')} ${fmtT(N(a['outAt']))}', style: ts(13.5, c: C.muted)), tg!.$2],
                      ]),
              ])),
              if (a == null)
                Btn(t('clockIn'), icon: 'camera', onTap: () => clockIn(context, st['id']))
              else if (a['outAt'] == null)
                Btn(t('clockOut'), kind: BK.sec, onTap: () => clockOut(context, st['id']))
              else
                Thumb(a['outPhoto'] as String?, Str(st['name'])),
            ]),
          );
        }),
    ];
    final all = [...att]..sort((a, b) => N(b['inAt']).compareTo(N(a['inAt'])));
    final pages = all.isEmpty ? 1 : (all.length / 5).ceil();
    final p = page.clamp(0, pages - 1);
    final rows = all.skip(p * 5).take(5).toList();
    final lateCount = all.where((a) => N(a['inAt']) > now() - 30 * kDay).where((a) => lateMin(a) > 0).length;
    final w = MediaQuery.sizeOf(context).width;
    final hoursCard = CardBox(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          Container(
              width: 38, height: 38, alignment: Alignment.center,
              decoration: BoxDecoration(color: C.pSoft, borderRadius: BorderRadius.circular(12)),
              child: const Ic('clock', color: C.p)),
          hgap(10),
          H2(t('hoursTitle')),
        ]),
        gap(12),
        KV.txt('${t('clockIn')} / ${t('clockOut')}', '${hours['clockIn']} / ${hours['clockOut']}', bold: true),
        KV.txt(t('opHours'), L(hours['open']).map((x) => '${x[0]}–${x[1]}').join(', '), bold: true),
        KV.txt(t('offDays'), offTxt(), bold: true),
        KV.txt(t('nextOff'), nOff != null ? longDate(nOff) : '–', bold: true),
        KV(t('late30'), Text('$lateCount', style: ts(14.5, w: w8, c: lateCount > 0 ? C.bad : C.ok))),
      ]),
    );
    return ListView(padding: pagePad(context), children: [
      w < 900
          ? Column(children: [for (final x in today) Padding(padding: const EdgeInsets.only(bottom: 14), child: x), hoursCard])
          : Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(flex: 2, child: Column(children: [for (final x in today) Padding(padding: const EdgeInsets.only(bottom: 14), child: x)])),
              hgap(14),
              Expanded(child: hoursCard),
            ]),
      gap(14),
      Note(t('attNote')),
      gap(26),
      Section(
        titleWidget: Row(children: [
          Container(
              width: 30, height: 30, alignment: Alignment.center,
              decoration: BoxDecoration(color: C.pSoft, borderRadius: BorderRadius.circular(9)),
              child: const Ic('user', size: 16, color: C.p)),
          hgap(10),
          H2(t('attHistory')),
        ]),
        child: CardBox(
          padding: const EdgeInsets.fromLTRB(16, 6, 16, 6),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            rows.isEmpty
                ? Padding(padding: const EdgeInsets.all(12), child: Text('–', style: ts(14, c: C.muted)))
                : SimpleTable(head: [t('date'), t('clockIn'), t('clockOut'), t('worked')], rows: [
                    for (final a in rows)
                      [
                        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(fmtD(N(a['inAt'])), style: ts(14, w: w8)),
                          Text(staffName(a['staff']), style: ts(12, c: C.muted)),
                        ]),
                        Row(mainAxisSize: MainAxisSize.min, children: [
                          Thumb(a['inPhoto'] as String?, staffName(a['staff']), size: 32),
                          hgap(8),
                          Text(fmtT(N(a['inAt']))),
                          if (w >= 700) ...[hgap(8), _tags(a).$1],
                        ]),
                        Row(mainAxisSize: MainAxisSize.min, children: [
                          if (a['outAt'] != null) ...[Thumb(a['outPhoto'] as String?, staffName(a['staff']), size: 32), hgap(8), Text(fmtT(N(a['outAt'])))],
                          if (w >= 700 || a['outAt'] == null) ...[hgap(8), _tags(a).$2],
                        ]),
                        Text(a['outAt'] != null ? '${((N(a['outAt']) - N(a['inAt'])) / 3600000).toStringAsFixed(1)} h' : '–'),
                      ]
                  ]),
            Pager(page: p, pages: pages, onPage: (v) => setState(() => page = v)),
          ]),
        ),
      ),
    ]);
  }
}

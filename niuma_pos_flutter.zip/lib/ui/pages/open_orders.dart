// Dine-in & takeaway on top, delivery (orange) at the bottom with platform + status filters.
import 'package:flutter/material.dart';

import '../../data/consts.dart';
import '../../data/logic.dart';
import '../../data/store.dart';
import '../../data/util.dart';
import '../actions.dart';
import '../theme.dart';
import '../widgets.dart';
import 'kitchen.dart';

class OpenOrdersPage extends StatelessWidget {
  const OpenOrdersPage({super.key});
  @override
  Widget build(BuildContext context) {
    final unpaid = unpaidOrders()..sort((a, b) => N(a['t']).compareTo(N(b['t'])));
    final walk = unpaid.where((o) => !isDel(o)).toList();
    final delWait = unpaid.where(isDel).toList();
    final td = dayStart(now()), n = now();
    final delDone = orders
        .where((o) => isDel(o) && o['paid'] == true && o['status'] != 'voided' && N(o['paidAt'] ?? o['t']) >= td)
        .toList()
      ..sort((a, b) => N(b['paidAt']).compareTo(N(a['paidAt'])));
    final plat = Str(S['delPlat']).isEmpty ? 'all' : Str(S['delPlat']);
    final seg = Str(S['delSeg']).isEmpty ? 'wait' : Str(S['delSeg']);
    List<dynamic> byPlat(List<dynamic> l) => plat == 'all' ? l : l.where((o) => o['ch'] == plat).toList();
    final src = seg == 'done' ? delDone : delWait;
    final list = byPlat(src);

    Widget walkCard(dynamic o) => CardBox(
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              NoBox('${o['n']}', kCh[o['ch']] ?? C.p),
              hgap(12),
              Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(Str(o['tag']).isNotEmpty ? Str(o['tag']) : t('ch_${o['ch']}'), style: ts(15.5, w: w8)),
                Sub('${t('ch_${o['ch']}')}, ${fmtT(N(o['t']))} (${((n - N(o['t'])) / 60000).floor()} ${t('min')})'),
              ])),
              Tag(t(Str(o['status'])), kind: o['status'] == 'pending' ? TK.p : TK.ok),
            ]),
            gap(14),
            for (final l in L(o['lines']))
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${l['qty']}× ${lineCode(l)}', style: ts(14, w: w8, ls: 0.3)),
                  if (lineText(l).isNotEmpty) Text(lineText(l), style: ts(13, c: C.muted)),
                ]),
              ),
            gap(8),
            Row(children: [
              Expanded(child: Text(rm(oTotal(o)), style: ts(22, w: w8, ls: -0.4))),
              IconBtn('trash', onTap: () => voidOrder(context, o['id'])),
            ]),
            gap(10),
            Btn(t('takePayment'), icon: 'cash', full: true, onTap: () => payOrder(context, o['id'])),
          ]),
        );

    Widget delCard(dynamic o) {
      final cooking = o['status'] == 'pending';
      final stage = cooking
          ? Tag(dueText(o), kind: isOverdue(o) ? TK.bad : TK.p)
          : o['delivered'] == true
              ? Tag(t('deliveredTag'), kind: TK.ok)
              : Tag(o['appReady'] == true ? t('readyTag').replaceAll('{p}', t('ch_${o['ch']}')) : t('withRider'));
      return Container(
        decoration: BoxDecoration(color: C.surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: C.delLine)),
        clipBehavior: Clip.antiAlias,
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Container(height: 4, color: const Color(0xFFF97316)),
          Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            NoBox('${o['n']}', kCh[o['ch']] ?? C.p),
            hgap(12),
            Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(Str(o['tag']).isNotEmpty ? Str(o['tag']) : t('ch_${o['ch']}'), style: ts(15.5, w: w8)),
              Sub('${t('ch_${o['ch']}')}, ${fmtT(N(o['t']))}'),
              gap(6),
              Tag(t('deliveryLabel'), kind: TK.del, icon: 'scooter'),
            ])),
            stage,
          ]),
          gap(14),
          DelLines(o),
          if (Str(o['note']).isNotEmpty) ...[gap(10), Note(Str(o['note']), kind: NK.warn)],
          gap(14),
          Row(children: [
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t('appPrice'), style: ts(12, w: w7, c: C.muted)),
              Text(rm(oTotal(o)), style: ts(22, w: w8, ls: -0.4)),
            ]),
            hgap(18),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t('shopPrice'), style: ts(12, w: w7, c: C.muted)),
              Text(rm(oShop(o)), style: ts(16, w: w7, c: C.ink2)),
            ]),
            const Spacer(),
            IconBtn('trash', onTap: () => voidOrder(context, o['id'])),
          ]),
          gap(12),
          if (o['delivered'] == true) ...[
            Row(children: [
              const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: C.warn)),
              hgap(8),
              Expanded(child: Text(t('waitingPlatform').replaceAll('{p}', t('ch_${o['ch']}')), style: ts(13, w: w7, c: C.warn))),
            ]),
            gap(10),
            Row(children: [
              Expanded(child: Btn(t('simPayout'), icon: 'sparkle', kind: BK.soft, full: true, onTap: () => simPayout(o['id']))),
              hgap(10),
              Expanded(child: Btn(t('enterManually'), icon: 'edit', full: true, onTap: () => settleOrder(context, o['id']))),
            ]),
          ] else ...[
            Text(t('notDelivered'), style: ts(13, w: w6, c: C.muted)),
            gap(10),
            Row(children: [
              Expanded(child: Btn(t('simDelivered'), icon: 'sparkle', kind: BK.soft, full: true, onTap: () => simDelivered(o['id']))),
              hgap(10),
              Expanded(child: Btn(t('enterManually'), icon: 'edit', kind: BK.sec, full: true, onTap: () => settleOrder(context, o['id']))),
            ]),
          ],
        ])),
        ]),
      );
    }

    Widget doneRow(dynamic o) => InkWell(
          onTap: () => settleOrder(context, o['id']),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: C.line))),
            child: Row(children: [
              NoBox('${o['n']}', kCh[o['ch']] ?? C.p, size: 42),
              hgap(12),
              Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(Str(o['tag']).isNotEmpty ? Str(o['tag']) : t('ch_${o['ch']}'), style: ts(14.5, w: w7)),
                Text('${t('ch_${o['ch']}')}, ${fmtT(N(o['paidAt'] ?? o['t']))} · ${orderCodes(o)}', maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(12.5, c: C.muted)),
              ])),
              _money(t('appPrice'), rm(o['gross'] ?? oApp(o)), C.ink2),
              _money(t('platformFee'), rm(-oFee(o)), C.warn),
              _money(t('recvShort'), rm(o['received'] ?? 0), C.ink, bold: true),
              const Ic('edit', size: 15, color: C.muted),
            ]),
          ),
        );

    final walkSum = walk.fold<num>(0, (s, o) => s + oTotal(o));
    final cnt = (String c) => (c == 'all' ? src : src.where((o) => o['ch'] == c)).length;
    return ListView(padding: pagePad(context), children: [
      Section(
        titleWidget: Text.rich(TextSpan(children: [
          TextSpan(text: t('walkinOrders'), style: ts(16, w: w8)),
          TextSpan(text: '  (${walk.length})', style: ts(16, w: w7, c: C.muted)),
        ])),
        trailing: walk.isNotEmpty ? Text(rm(walkSum), style: ts(15, w: w7, c: C.muted)) : null,
        child: walk.isEmpty
            ? CardBox(child: Center(child: Column(children: [Text(t('openEmpty'), style: ts(15, w: w7)), Sub(t('openEmptySub'))])))
            : CardGrid(minW: 300, children: walk.map(walkCard).toList()),
      ),
      Container(
        padding: const EdgeInsets.only(top: 22),
        decoration: const BoxDecoration(border: Border(top: BorderSide(color: Color(0xFFFDBA74), width: 2))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Wrap(spacing: 10, runSpacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: [
            Tag(t('deliveryOrders'), kind: TK.del, icon: 'scooter', size: 13),
            Text(t('pendingPayHint'), style: ts(13.5, c: C.muted)),
            if (seg == 'done' && list.isNotEmpty)
              Text('${t('recvShort')}: ${rm(list.fold<num>(0, (s, o) => s + N(o['received'])))}', style: ts(14, w: w7, c: C.muted)),
          ]),
          gap(14),
          wrapRow([
            Seg<String>(
              items: [('wait', '${t('waitingPay')} (${byPlat(delWait).length})'), ('done', '${t('donePaid')} (${byPlat(delDone).length})')],
              value: seg,
              onChanged: (v) {
                S['delSeg'] = v;
                save();
              },
            ),
            for (final c in ['all', ...kDelivery])
              PillBtn('${c == 'all' ? t('allPlatforms') : t('ch_$c')} ${cnt(c)}', on: plat == c, dot: c == 'all' ? null : kCh[c], onTap: () {
                S['delPlat'] = c;
                save();
              }),
          ]),
          gap(16),
          if (seg == 'done')
            list.isEmpty
                ? CardBox(child: Center(child: Text(t('noDelDone'), style: ts(15, w: w7))))
                : CardBox(padding: const EdgeInsets.symmetric(vertical: 4), child: Column(children: list.map(doneRow).toList()))
          else
            list.isEmpty ? CardBox(child: Center(child: Text(t('noDelWait'), style: ts(15, w: w7)))) : CardGrid(minW: 360, children: list.map(delCard).toList()),
        ]),
      ),
    ]);
  }

  Widget _money(String label, String value, Color c, {bool bold = false}) => Container(
        constraints: const BoxConstraints(minWidth: 92),
        padding: const EdgeInsets.only(left: 10),
        child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text(label, style: ts(11.5, w: w7, c: C.muted)),
          Text(value, style: ts(14, w: bold ? w8 : w6, c: c)),
        ]),
      );
}

import 'package:flutter/material.dart';

import '../../data/consts.dart';
import '../../data/logic.dart';
import '../../data/util.dart';
import '../actions.dart';
import '../theme.dart';
import '../widgets.dart';

class EmptyState extends StatelessWidget {
  final String icon, title, sub;
  const EmptyState(this.icon, this.title, this.sub, {super.key});
  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 70, horizontal: 20),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 72, height: 72, alignment: Alignment.center,
              decoration: BoxDecoration(color: C.surface, borderRadius: BorderRadius.circular(22), border: Border.all(color: C.line)),
              child: Ic(icon, size: 26, color: const Color(0xFFB7B2C4)),
            ),
            gap(16),
            H2(title, size: 18),
            Sub(sub),
          ]),
        ),
      );
}

EdgeInsets pagePad(BuildContext c) => isNarrow(c) ? const EdgeInsets.fromLTRB(16, 16, 16, 40) : const EdgeInsets.fromLTRB(28, 24, 28, 40);

/// Lays children in a responsive grid of cards with a minimum width.
class CardGrid extends StatelessWidget {
  final double minW, gapSize;
  final List<Widget> children;
  const CardGrid({super.key, required this.minW, required this.children, this.gapSize = 16});
  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (c, k) {
        final cols = (k.maxWidth / minW).floor().clamp(1, 6);
        final w = (k.maxWidth - (cols - 1) * gapSize) / cols;
        return Wrap(spacing: gapSize, runSpacing: gapSize, children: [for (final x in children) SizedBox(width: w, child: x)]);
      });
}

class KitchenPage extends StatelessWidget {
  const KitchenPage({super.key});
  @override
  Widget build(BuildContext context) {
    final p = orders.where((o) => o['status'] == 'pending').toList();
    if (p.isEmpty) return EmptyState('flame', t('kitchenClear'), t('kitchenClearSub'));
    final n = now();
    return ListView(padding: pagePad(context), children: [
      CardGrid(minW: 290, children: [for (final o in p) _Ticket(o, n)]),
    ]);
  }
}

class _Ticket extends StatelessWidget {
  final dynamic o;
  final int n;
  const _Ticket(this.o, this.n);
  @override
  Widget build(BuildContext context) {
    final mins = ((n - N(o['t'])) / 60000).floor();
    final del = isDel(o);
    final late = del ? isOverdue(o) : mins >= 15;
    final canDone = o['paid'] == true || del;
    return Container(
      decoration: BoxDecoration(
        color: C.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: late ? const Color(0xFFF4B4B4) : C.line),
        boxShadow: late ? const [BoxShadow(color: C.badSoft, spreadRadius: 3)] : null,
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: C.line))),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('#${o['n']}', style: ts(24, w: w8, ls: -0.5)),
            hgap(10),
            Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [Dot(kCh[o['ch']] ?? C.muted), hgap(6), Text(t('ch_${o['ch']}'), style: ts(13, w: w7, c: C.ink2))]),
              if (Str(o['tag']).isNotEmpty) Text(Str(o['tag']), style: ts(12.5, w: w6, c: C.muted)),
              if (del) Padding(padding: const EdgeInsets.only(top: 5), child: Tag(t('deliveryLabel'), kind: TK.del, icon: 'scooter')),
            ])),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              del && o['due'] != null ? Tag(dueText(o), kind: isOverdue(o) ? TK.bad : TK.p) : Tag('$mins ${t('min')}', kind: late ? TK.bad : TK.mute),
              gap(5),
              o['paid'] == true ? Tag(t('paid'), kind: TK.ok) : Tag(t(del ? 'pendingPay' : 'unpaid'), kind: TK.warn),
            ]),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            for (final l in L(o['lines']))
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Container(
                    width: 28, height: 28, alignment: Alignment.center,
                    decoration: BoxDecoration(color: C.pSoft, borderRadius: BorderRadius.circular(8)),
                    child: Text('${l['qty']}', style: ts(14, w: w8, c: C.p)),
                  ),
                  hgap(10),
                  Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(lineCode(l), style: ts(22, w: w8, ls: 0.5, h: 1.3)),
                    ChoiceChips(l),
                    if (L(l['addons']).isNotEmpty) Padding(padding: const EdgeInsets.only(top: 2), child: Text('+ ${lineAddons(l)}', style: ts(13.5, c: C.ink2))),
                  ])),
                ]),
              ),
            if (Str(o['note']).isNotEmpty)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration(color: C.warnSoft, borderRadius: BorderRadius.circular(10)),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Ic('alert', size: 16, color: Color(0xFF92400E)),
                  hgap(8),
                  Expanded(child: Text(Str(o['note']), style: ts(14, w: w7, c: const Color(0xFF92400E)))),
                ]),
              ),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: canDone
              ? Btn(t('markDone'), icon: 'check', kind: BK.ok, full: true, onTap: () => markDone(o['id']))
              : Column(children: [
                  Row(children: [
                    Expanded(flex: 14, child: Btn(t('takePayment'), icon: 'cash', full: true, onTap: () => payOrder(context, o['id']))),
                    hgap(10),
                    Expanded(flex: 10, child: Btn(t('markDone'), icon: 'check', full: true)),
                  ]),
                  gap(8),
                  Text(t('collectFirst'), textAlign: TextAlign.center, style: ts(12.5, c: C.muted)),
                ]),
        ),
      ]),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// Same tokens as the web app's :root CSS variables.
class C {
  static const bg = Color(0xFFF6F6F9);
  static const surface = Colors.white;
  static const sunken = Color(0xFFF1F0F5);
  static const line = Color(0xFFECEBF1);
  static const line2 = Color(0xFFE2E0EA);
  static const ink = Color(0xFF16131F);
  static const ink2 = Color(0xFF4A4558);
  static const muted = Color(0xFF8A8598);
  static const p = Color(0xFF6D28D9);
  static const pHover = Color(0xFF5B21B6);
  static const pSoft = Color(0xFFF3EEFE);
  static const pLine = Color(0xFFDDD0FB);
  static const ok = Color(0xFF16A34A);
  static const okSoft = Color(0xFFEAF7EF);
  static const warn = Color(0xFFD97706);
  static const warnSoft = Color(0xFFFEF6E7);
  static const bad = Color(0xFFDC2626);
  static const badSoft = Color(0xFFFDEEEE);
  static const del = Color(0xFFC2410C);
  static const delSoft = Color(0xFFFFEDD5);
  static const delLine = Color(0xFFFED7AA);
  static const disabled = Color(0xFFD9D6E3);
}

const kFallback = ['Noto Sans SC', 'Noto Sans Myanmar', 'PingFang SC', 'Myanmar Sangam MN'];

TextStyle ts(double size, {FontWeight w = FontWeight.w500, Color c = C.ink, double? h, double ls = 0}) =>
    GoogleFonts.plusJakartaSans(fontSize: size, fontWeight: w, color: c, height: h, letterSpacing: ls)
        .copyWith(fontFamilyFallback: kFallback, fontFeatures: const [FontFeature.tabularFigures()]);

const w5 = FontWeight.w500, w6 = FontWeight.w600, w7 = FontWeight.w700, w8 = FontWeight.w800;

ThemeData buildTheme() {
  final base = ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: C.p, primary: C.p, surface: C.surface));
  return base.copyWith(
    scaffoldBackgroundColor: C.bg,
    textTheme: GoogleFonts.plusJakartaSansTextTheme(base.textTheme).apply(bodyColor: C.ink, displayColor: C.ink),
    splashFactory: NoSplash.splashFactory,
    highlightColor: Colors.transparent,
    dividerColor: C.line,
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: C.surface,
      isDense: true,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
      hintStyle: ts(14.5, c: C.muted),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: C.line2, width: 1.5)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: C.line2, width: 1.5)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: C.p, width: 1.5)),
    ),
  );
}

// New / edit expense. Payment method and category are required before Save.
import 'package:flutter/material.dart';

import '../../data/consts.dart';
import '../../data/logic.dart';
import '../../data/store.dart';
import '../../data/util.dart';
import '../../services.dart';
import '../theme.dart';
import '../widgets.dart';

class ExpenseDialog extends StatefulWidget {
  final Map<String, dynamic> e;
  final bool isNew;
  const ExpenseDialog({super.key, required this.e, required this.isNew});
  @override
  State<ExpenseDialog> createState() => _ExpenseDialogState();
}

class _ExpenseDialogState extends State<ExpenseDialog> {
  late final Map<String, dynamic> e = widget.e;
  late final vendor = TextEditingController(text: Str(e['vendor']));
  late final amount = TextEditingController(text: e['amount'] == null ? '' : '${e['amount']}');
  bool tried = false;

  Widget _regHint() {
    final p = e['paidBy'];
    if (p == null || p == 'card') return const SizedBox.shrink();
    final same = expenses.any((x) => x['id'] == e['id'] && x['date'] == e['date'] && x['paidBy'] == e['paidBy']);
    final probe = Map<String, dynamic>.from(e)..['at'] = e['at'] != null && same ? e['at'] : bookAt(e);
    final r = regOf(probe);
    if (r == null) {
      return Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Text(t('noRegFor').replaceAll('{r}', t(kRegName[p] ?? '')), style: ts(13, w: w7, c: C.warn)));
    }
    return Padding(
      padding: const EdgeInsets.only(top: 6),
      child: Text(
          '${t('goesTo').replaceAll('{r}', '${t(kRegName[r['kind']] ?? '')} ${fmtD(N(r['day']))}')}${r['closed'] == true ? ' · ${t('goesToClosed')}' : ''}',
          style: ts(13, c: C.muted)),
    );
  }

  Future<void> _pickDate() async {
    final cur = dt(isoMs(Str(e['date'])));
    final d = await showDatePicker(context: context, initialDate: cur, firstDate: DateTime(2024), lastDate: DateTime.now().add(const Duration(days: 1)));
    if (d != null) setState(() => e['date'] = isoDate(d.millisecondsSinceEpoch));
  }

  void _save() {
    e['vendor'] = vendor.text.trim();
    final a = double.tryParse(amount.text);
    e['amount'] = a;
    if (a == null || a <= 0) {
      setState(() => tried = true);
      return;
    }
    if (e['paidBy'] == null || e['cat'] == null) {
      setState(() => tried = true);
      return;
    }
    final i = expenses.indexWhere((x) => x['id'] == e['id']);
    final old = i >= 0 ? Map<String, dynamic>.from(expenses[i] as Map) : null;
    if (old == null || old['date'] != e['date'] || old['paidBy'] != e['paidBy'] || e['at'] == null) e['at'] = bookAt(e);
    final logged = track(Str(e['vendor']).isNotEmpty ? Str(e['vendor']) : t('cat_${e['cat']}'), () {
      if (i >= 0) {
        expenses[i] = e;
      } else {
        expenses.add(e);
      }
    }, () => expDesc(old, e));
    S['expMonth'] = Str(e['date']).substring(0, 7);
    save();
    Navigator.pop(context);
    toast(logged ? t('chToast') : t('savedExpense'));
  }

  Future<void> _delete() async {
    final old = expenses.firstWhere((x) => x['id'] == e['id'], orElse: () => null);
    if (old == null) return;
    final logged = track(Str(old['vendor']).isNotEmpty ? Str(old['vendor']) : t('cat_${old['cat']}'), () {
      expenses.removeWhere((x) => x['id'] == old['id']);
    }, () => expDesc(old, null));
    save();
    Navigator.pop(context);
    if (logged) toast(t('chToast'));
  }

  @override
  Widget build(BuildContext context) {
    final photo = photoBytes(e['photo'] is String ? e['photo'] as String : null);
    final missPay = e['paidBy'] == null, missCat = e['cat'] == null;
    return Dlg(
      title: t(widget.isNew ? 'newExpense' : 'editExpense'),
      body: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        if (photo != null) ...[
          ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.memory(photo, height: 220, fit: BoxFit.cover)),
          gap(12),
        ],
        Field(t('vendor'), TextField(controller: vendor, style: ts(15))),
        gap(14),
        Row(children: [
          Expanded(
              child: Field(
                  t('date'),
                  InkWell(
                    onTap: _pickDate,
                    child: InputDecorator(
                      decoration: const InputDecoration(),
                      child: Row(children: [Expanded(child: Text(Str(e['date']), style: ts(15))), const Ic('calendar', size: 17, color: C.muted)]),
                    ),
                  ))),
          hgap(14),
          Expanded(
              child: Field(
                  t('amount'),
                  TextField(
                      controller: amount,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      style: ts(15, w: w7),
                      decoration: InputDecoration(
                          hintText: '0.00',
                          enabledBorder: tried && (double.tryParse(amount.text) ?? 0) <= 0
                              ? OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: C.bad, width: 1.5))
                              : null)))),
        ]),
        Lbl(t('paidWith'), trailing: missPay ? Tag(t('pickOne'), kind: tried ? TK.bad : TK.warn) : null),
        Container(
          decoration: missPay && tried ? BoxDecoration(borderRadius: BorderRadius.circular(14), border: Border.all(color: C.bad, width: 2)) : null,
          child: Seg<String?>(
            items: [for (final k in ['petty', 'cash', 'tng', 'card']) (k, t('paid_$k'))],
            value: e['paidBy'] as String?,
            onChanged: (v) => setState(() => e['paidBy'] = v),
          ),
        ),
        _regHint(),
        Lbl(t('category'), trailing: missCat ? Tag(t('pickOne'), kind: tried ? TK.bad : TK.warn) : null),
        Container(
          padding: missCat && tried ? const EdgeInsets.all(6) : EdgeInsets.zero,
          decoration: missCat && tried ? BoxDecoration(borderRadius: BorderRadius.circular(14), border: Border.all(color: C.bad, width: 2)) : null,
          child: wrapRow([
            for (final c in kCats) PillBtn(t('cat_$c'), on: e['cat'] == c, dot: kCatCol[c], onTap: () => setState(() => e['cat'] = c)),
          ]),
        ),
      ]),
      foot: [
        if (!widget.isNew) Btn(t('delete'), kind: BK.danger, onTap: _delete),
        const Spacer(),
        Btn(t('cancel'), kind: BK.sec, onTap: () => Navigator.pop(context)),
        Btn(t('save'), onTap: missPay || missCat ? null : _save),
      ],
    );
  }
}

// Take payment (cash / TNG) with line price adjustments and order discount. Also used to edit a paid order.
import 'package:flutter/material.dart';

import '../../data/consts.dart';
import '../../data/logic.dart';
import '../../data/store.dart';
import '../../data/util.dart';
import '../actions.dart';
import '../theme.dart';
import '../widgets.dart';

class PayDialog extends StatefulWidget {
  final dynamic orderId;
  final bool edit;
  const PayDialog({super.key, required this.orderId, this.edit = false});
  @override
  State<PayDialog> createState() => _PayDialogState();
}

class _PayDialogState extends State<PayDialog> {
  late final Map<String, dynamic> o = orderById(widget.orderId)!;
  late final Map<String, dynamic> d = <String, dynamic>{
    'lines': L(o['lines']).map((l) => Map<String, dynamic>.from(l as Map)).toList(),
    'disc': N(o['disc']),
    'discReason': o['discReason'],
  };
  late String method = widget.edit && o['pay'] != null ? Str(o['pay']) : 'cash';
  String received = '';
  final recCtl = TextEditingController();
  // adjustment sub-screen
  Map<String, dynamic>? adj;
  final adjCtl = TextEditingController();

  num _adjResult(num base) {
    final a = adj!;
    final v = double.tryParse(adjCtl.text) ?? 0;
    final pct = v > 100 ? 100 : v;
    num r;
    if (a['target'] == 'line') {
      r = a['mode'] == 'set' ? (adjCtl.text.isEmpty ? base : v) : (a['mode'] == 'pct' ? base * (1 - pct / 100) : base - v);
    } else {
      r = a['mode'] == 'pct' ? base * (1 - pct / 100) : base - v;
    }
    return r < 0 ? 0 : r;
  }

  @override
  Widget build(BuildContext context) => adj != null ? _adjView(context) : _payView(context);

  Widget _payView(BuildContext context) {
    final tot = draftTotals(d);
    final total = tot['total']!;
    final rec = double.tryParse(received) ?? 0;
    final lines = L(d['lines']);
    final ok = method != 'cash' || received.isEmpty || rec >= total - 0.001;
    return Dlg(
      wide: true,
      title: widget.edit ? t('editOrder') : t('takePayment'),
      sub: '#${o['n']} · ${Str(o['tag']).isNotEmpty ? o['tag'] : t('ch_${o['ch']}')}${widget.edit ? ' · ${fmtT(N(o['t']))}' : ''}',
      body: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          decoration: BoxDecoration(border: Border.all(color: C.line), borderRadius: BorderRadius.circular(14)),
          child: Column(children: [
            for (var i = 0; i < lines.length; i++) _line(i, lines[i], i == lines.length - 1),
          ]),
        ),
        gap(12),
        _sum(t('subtotal'), rm(tot['base'])),
        gap(8),
        Row(children: [
          LinkBtn(N(d['disc']) > 0 ? '${t('orderDiscount')}: ${t(Str(d['discReason'] ?? 'r_other'))}' : t('addDiscount'),
              icon: 'tag', color: C.warn, onTap: () => setState(() {
                    adj = {'target': 'order', 'mode': 'rm', 'reason': d['discReason'] ?? 'r_regular'};
                    adjCtl.text = N(d['disc']) > 0 ? '${d['disc']}' : '';
                  })),
          const Spacer(),
          if (tot['saved']! > 0.001) Text(rm(-tot['saved']!), style: ts(14, w: w6, c: C.warn)),
        ]),
        gap(14),
        Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Expanded(child: Text(t('total'), style: ts(14, w: w7, c: C.muted))),
          Text(rm(total), style: ts(34, w: w8, ls: -0.8)),
        ]),
        Lbl(t('method')),
        Row(children: [
          for (final p in kPays) ...[
            if (p != kPays.first) hgap(10),
            Expanded(child: _method(p)),
          ]
        ]),
        if (method == 'cash') ...[
          gap(16),
          Field(t('received'), TextField(
            controller: recCtl,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            style: ts(20, w: w8),
            decoration: InputDecoration(hintText: total.toStringAsFixed(2)),
            onChanged: (s) => setState(() => received = s),
          )),
          gap(10),
          wrapRow([
            Btn(t('exact'), kind: BK.sec, onTap: () => _quick(total)),
            for (final v in [10, 20, 50, 100].where((v) => v >= total).take(3)) Btn('RM$v', kind: BK.sec, onTap: () => _quick(v)),
          ]),
          if (rec >= total && rec > 0) ...[
            gap(12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(color: C.okSoft, borderRadius: BorderRadius.circular(14)),
              child: Row(children: [
                Expanded(child: Text(t('change'), style: ts(15, w: w7, c: C.ok))),
                Text(rm(rec - total), style: ts(24, w: w8, c: C.ok)),
              ]),
            ),
          ],
        ] else ...[
          gap(16),
          Note('${t('tngWaiting')}\n${t('tngAuto')}', icon: 'wallet'),
        ],
      ]),
      foot: [
        if (widget.edit)
          Btn(t('void'), kind: BK.danger, onTap: () {
            final ctx = navContext(context);
            Navigator.pop(context);
            voidOrder(ctx, o['id']);
          }),
        Btn(t('cancel'), kind: BK.sec, onTap: () => Navigator.pop(context)),
        Expanded(
            child: Btn(widget.edit ? t('saveChanges') : t('confirmPaid'), icon: 'check', kind: BK.ok, size: BS.lg, full: true, onTap: ok ? _confirm : null)),
      ],
    );
  }

  void _quick(num v) {
    received = v.toStringAsFixed(v % 1 == 0 ? 0 : 2);
    recCtl.text = received;
    setState(() {});
  }

  void _confirm() {
    final tot = draftTotals(d);
    final logged = trackOrder(o, () {
      o['lines'] = d['lines'];
      o['disc'] = tot['disc'];
      o['discReason'] = d['discReason'];
      o['paid'] = true;
      o['pay'] = method;
      o['paidAt'] = o['paidAt'] ?? now();
      o['received'] = method == 'cash' ? (double.tryParse(received) ?? tot['total']) : tot['total'];
    });
    save();
    Navigator.pop(context);
    toast(logged ? t('chToast') : (widget.edit ? t('orderSaved', o['n']) : t('paidToast', o['n'])));
  }

  Widget _sum(String l, String v) => Row(children: [
        Expanded(child: Text(l, style: ts(14, w: w6, c: C.ink2))),
        Text(v, style: ts(14, w: w6, c: C.ink2)),
      ]);

  Widget _method(String p) {
    final on = method == p;
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: () => setState(() {
        method = p;
        received = '';
        recCtl.clear();
      }),
      child: Container(
        height: 84,
        decoration: BoxDecoration(
          color: on ? C.pSoft : C.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: on ? C.p : C.line2, width: on ? 2 : 1.5),
        ),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Ic(p == 'cash' ? 'cash' : 'wallet', size: 26, color: on ? C.p : C.ink2),
          gap(6),
          Text(t('pay_$p'), style: ts(14.5, w: w7, c: on ? C.p : C.ink)),
        ]),
      ),
    );
  }

  Widget _line(int i, dynamic l, bool last) {
    final adjd = (N(l['unit']) - N(l['base'])).abs() > 0.001;
    final it = item(l['id']);
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(border: last ? null : const Border(bottom: BorderSide(color: C.line))),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Pic(it ?? {'names': l['names']}),
        hgap(12),
        Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${l['qty']}× ${lineCode(l)}', style: ts(14.5, w: w8, ls: 0.3)),
          if (lineText(l).isNotEmpty) Text(lineText(l), style: ts(12.5, c: C.muted)),
          gap(4),
          LinkBtn(adjd ? '${t('adjusted')}: ${t(Str(l['reason'] ?? 'r_other'))}' : t('adjust'),
              icon: 'tag', color: adjd ? C.warn : C.p, onTap: () => setState(() {
                    adj = {'target': 'line', 'i': i, 'mode': 'set', 'reason': l['reason'] ?? 'r_regular'};
                    adjCtl.text = adjd ? '${l['unit']}' : '';
                  })),
        ])),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          if (adjd) Text(rm(N(l['base']) * N(l['qty'])), style: ts(12.5, c: C.muted).copyWith(decoration: TextDecoration.lineThrough)),
          Text(rm(N(l['unit']) * N(l['qty'])), style: ts(14.5, w: w7)),
        ]),
      ]),
    );
  }

  Widget _adjView(BuildContext context) {
    final a = adj!;
    final isLine = a['target'] == 'line';
    final l = isLine ? L(d['lines'])[I(a['i'])] : null;
    final base = isLine ? N(l['base']) : draftTotals(d)['sub']!;
    final has = isLine ? (N(l['unit']) - N(l['base'])).abs() > 0.001 : N(d['disc']) > 0;
    final modes = isLine ? ['set', 'rm', 'pct'] : ['rm', 'pct'];
    return Dlg(
      title: isLine ? '${t('adjust')}: ${nm(l['names'])}' : t('orderDiscount'),
      closeBtn: false,
      body: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(color: C.sunken, borderRadius: BorderRadius.circular(12)),
          child: Row(children: [
            Expanded(child: Text(isLine ? t('defaultPrice') : t('subtotal'), style: ts(14, w: w7, c: C.muted))),
            Text(rm(base), style: ts(15, w: w8)),
          ]),
        ),
        gap(16),
        Seg<String>(
          items: [for (final k in modes) (k, t(k == 'set' ? 'setPrice' : (k == 'rm' ? 'discRM' : 'discPct')))],
          value: Str(a['mode']),
          onChanged: (v) => setState(() {
            a['mode'] = v;
            adjCtl.clear();
          }),
        ),
        gap(12),
        TextField(
          controller: adjCtl,
          autofocus: true,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          style: ts(22, w: w8),
          decoration: InputDecoration(hintText: a['mode'] == 'pct' ? '10' : '0.00'),
          onChanged: (_) => setState(() {}),
        ),
        Lbl(t('reason')),
        wrapRow([
          for (final r in kReasons) PillBtn(t(r), on: a['reason'] == r, onTap: () => setState(() => a['reason'] = r)),
        ]),
        gap(18),
        Row(children: [
          Expanded(child: Text(isLine ? t('newPrice') : t('total'), style: ts(15, w: w7))),
          Text(rm(_adjResult(base)), style: ts(22, w: w8)),
        ]),
      ]),
      foot: [
        if (has)
          Btn(t('removeAdj'), kind: BK.danger, onTap: () => setState(() {
                if (isLine) {
                  l['unit'] = l['base'];
                  l['reason'] = null;
                } else {
                  d['disc'] = 0;
                  d['discReason'] = null;
                }
                adj = null;
              })),
        const Spacer(),
        Btn(t('back'), kind: BK.sec, onTap: () => setState(() => adj = null)),
        Btn(t('apply'), onTap: () {
          final v = double.tryParse(adjCtl.text);
          if (v == null || v < 0) return;
          setState(() {
            if (isLine) {
              l['unit'] = r2(_adjResult(N(l['base'])));
              l['reason'] = (N(l['unit']) - N(l['base'])).abs() > 0.001 ? a['reason'] : null;
            } else {
              final sub = draftTotals(d)['sub']!;
              d['disc'] = r2(sub - _adjResult(sub));
              d['discReason'] = N(d['disc']) > 0 ? a['reason'] : null;
            }
            adj = null;
          });
        }),
      ],
    );
  }
}

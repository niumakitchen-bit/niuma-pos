// User actions (the web app's `A` object) and the smaller dialogs.
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../data/consts.dart';
import '../data/logic.dart';
import '../data/store.dart';
import '../data/util.dart';
import '../services.dart';
import 'dialogs/clock.dart';
import 'dialogs/close_day.dart';
import 'dialogs/expense.dart';
import 'dialogs/pay.dart';
import 'dialogs/reg_hist.dart';
import 'theme.dart';
import 'widgets.dart';

void _go(String tab) {
  S['tab'] = tab;
  store.save();
}

/* ---------------- shift ---------------- */
Future<void> openShift(BuildContext context) async {
  if (!clockedIn()) {
    toast(t('clockFirst'), 'alert');
    await clockIn(context);
    return;
  }
  if (S['tab'] != 'registers') _go('registers');
  final cash = <String, dynamic>{};
  await showDlg(context, (c) {
    return StatefulBuilder(builder: (c, set) {
      final ok = denTotal(cash) > 0;
      return Dlg(
        title: t('openShiftTitle'),
        sub: t('openShiftSub'),
        wide: true,
        body: Column(children: [
          DenGrid(counts: cash, onChanged: () => set(() {})),
          gap(10),
          Note(t('tngLater'), icon: 'wallet'),
        ]),
        foot: [
          Btn(t('cancel'), kind: BK.sec, onTap: () => Navigator.pop(c)),
          Expanded(
              child: Btn(t('openShift'), icon: 'cash', size: BS.lg, full: true, onTap: ok
                  ? () {
                      shifts.add(<String, dynamic>{
                        'id': uid('sh'), 'openedAt': now(), 'openCash': Map<String, dynamic>.from(cash), 'openTotal': denTotal(cash),
                        'openTng': null, 'tngOpenedAt': null,
                      });
                      if (S['tab'] == 'dashboard') S['tab'] = 'pos';
                      save();
                      Navigator.pop(c);
                      toast(t('shiftOpened'));
                    }
                  : null)),
        ],
      );
    });
  });
}

Future<void> openTng(BuildContext context) async {
  String v = '';
  await showDlg(context, (c) {
    return Dlg(
      title: t('openTngTitle'),
      sub: t('openTngSub'),
      body: Field(t('tngBalance'), Inp(number: true, big: true, hint: '0.00', autofocus: true, onChanged: (s) => v = s)),
      foot: [
        Btn(t('cancel'), kind: BK.sec, onTap: () => Navigator.pop(c)),
        Expanded(
            child: Btn(t('openTng'), icon: 'wallet', size: BS.lg, full: true, onTap: () {
          final x = double.tryParse(v);
          final sh = curShift();
          if (x == null || x < 0 || sh == null) return;
          sh['openTng'] = r2(x);
          sh['tngOpenedAt'] = now();
          save();
          Navigator.pop(c);
          toast(t('tngOpened'));
        })),
      ],
    );
  });
}

bool _outFlow = false;

Future<void> closeTng(BuildContext context, dynamic id) async {
  final sh = shiftById(id) ?? lastShift();
  if (sh == null) return;
  String v = '';
  await showDlg(context, (c) {
    return StatefulBuilder(builder: (c, set) {
      final et = expTng(sh) ?? 0;
      final x = double.tryParse(v);
      return Dlg(
        title: t('closeTng'),
        sub: '${fmtD(N(sh['openedAt']))} · ${t('since')} ${fmtT(N(sh['tngOpenedAt']))}',
        body: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          ExpBox([
            (t('opening'), Text(rm(sh['openTng']), style: ts(17, w: w8))),
            (t('tngSales'), Text(rm(shiftSales(sh, 'tng')), style: ts(17, w: w8))),
            (t('expected'), Text(rm(et), style: ts(17, w: w8))),
          ]),
          gap(14),
          Field(t('tngBalance'), Inp(number: true, big: true, hint: '0.00', autofocus: true, onChanged: (s) => set(() => v = s))),
          gap(12),
          Row(children: [Expanded(child: Text(t('overShort'), style: ts(14.5, w: w7))), VarTxt(x == null ? null : x - et)]),
        ]),
        foot: [
          Btn(t('cancel'), kind: BK.sec, onTap: () => Navigator.pop(c)),
          Expanded(
              child: Btn(t('closeTng'), icon: 'lock', size: BS.lg, full: true, onTap: x == null || x < 0
                  ? null
                  : () {
                      sh['closeTng'] = r2(x!);
                      sh['tngClosedAt'] = now();
                      save();
                      Navigator.pop(c);
                      toast(t('tngClosedT'));
                    })),
        ],
      );
    });
  });
  if (_outFlow && context.mounted) clockOut(context);
}

/* ---------------- petty cash ---------------- */
Future<void> openPetty(BuildContext context) async {
  final closed = petty.where((p) => p['closedAt'] != null).toList()..sort((a, b) => N(b['closedAt']).compareTo(N(a['closedAt'])));
  final cash = <String, dynamic>{...Mp(closed.isNotEmpty ? closed.first['closeCash'] : null)};
  await showDlg(context, (c) {
    return StatefulBuilder(builder: (c, set) {
      return Dlg(
        title: t('openVege'),
        sub: t('openVegeSub'),
        wide: true,
        body: DenGrid(counts: cash, onChanged: () => set(() {})),
        foot: [
          Btn(t('cancel'), kind: BK.sec, onTap: () => Navigator.pop(c)),
          Expanded(
              child: Btn(t('openVege'), icon: 'bag', size: BS.lg, full: true, onTap: denTotal(cash) > 0
                  ? () {
                      petty.add(<String, dynamic>{'id': uid('p'), 'openedAt': now(), 'openCash': Map<String, dynamic>.from(cash), 'openTotal': denTotal(cash)});
                      save();
                      Navigator.pop(c);
                      toast(t('vegeOpened'));
                    }
                  : null)),
        ],
      );
    });
  });
}

Future<void> closePetty(BuildContext context) async {
  final ps = curPetty();
  if (ps == null) return;
  final cash = <String, dynamic>{};
  await showDlg(context, (c) {
    return StatefulBuilder(builder: (c, set) {
      final ex = pettyExpected(ps);
      return Dlg(
        title: t('closeVege'),
        sub: t('closeVegeSub'),
        wide: true,
        body: Column(children: [
          ExpBox([
            (t('opening'), Text(rm(ps['openTotal']), style: ts(17, w: w8))),
            (t('vegeSpent'), Text(rm(-pettySpent(ps)), style: ts(17, w: w8))),
            (t('expected'), Text(rm(ex), style: ts(17, w: w8))),
          ]),
          DenGrid(counts: cash, onChanged: () => set(() {}), expected: ex),
        ]),
        foot: [
          Btn(t('cancel'), kind: BK.sec, onTap: () => Navigator.pop(c)),
          Expanded(
              child: Btn(t('closeVege'), icon: 'lock', size: BS.lg, full: true, onTap: () {
            ps['closedAt'] = now();
            ps['closeCash'] = Map<String, dynamic>.from(cash);
            ps['closeTotal'] = denTotal(cash);
            save();
            Navigator.pop(c);
            toast(t('vegeClosedT'));
          })),
        ],
      );
    });
  });
  if (_outFlow && context.mounted) clockOut(context);
}

/* ---------------- attendance ---------------- */
Future<void> clockIn(BuildContext context, [dynamic id]) async {
  dynamic sid = id;
  if (sid == null) {
    final free = staffList.where((st) => attToday(st['id']) == null).toList();
    sid = (free.isNotEmpty ? free.first : (staffList.isNotEmpty ? staffList.first : null))?['id'];
  }
  if (sid == null) return;
  final a = attToday(sid);
  if (a != null && a['outAt'] == null) {
    toast(t('alreadyIn'), 'info');
    return;
  }
  await showDlg(context, (c) => ClockDialog(mode: 'in', staffId: sid));
}

class TodoItem {
  final String label;
  final String? sub;
  final Widget btn;
  TodoItem(this.label, this.btn, [this.sub]);
}

List<TodoItem> outTodo(BuildContext context, BuildContext dlg) {
  final l = <TodoItem>[];
  final sh = todayShift();
  final cook = orders.where((o) => o['status'] == 'pending').length;
  final un = unpaidOrders().length;
  void close() => Navigator.pop(dlg);
  if (cook > 0) {
    l.add(TodoItem(t('cookBlock', cook), Btn(t('kitchen'), kind: BK.sec, size: BS.sm, onTap: () {
      close();
      _go('kitchen');
    })));
  }
  if (un > 0) {
    l.add(TodoItem(t('openBlock', un), Btn(t('openOrders'), kind: BK.sec, size: BS.sm, onTap: () {
      close();
      _go('openOrders');
    })));
  }
  if (sh != null && sh['closedAt'] == null) {
    l.add(TodoItem(t('todoCash'), Btn(t('closeDay'), size: BS.sm, onTap: () {
      close();
      closeDay(context);
    }), t('todoCashSub')));
  }
  if (sh != null && sh['tngOpenedAt'] != null && sh['tngClosedAt'] == null) {
    l.add(TodoItem(
        t('todoTng'),
        Btn(t('closeTng'), size: BS.sm, onTap: sh['closedAt'] != null
            ? () {
                close();
                closeTng(context, sh['id']);
              }
            : null)));
  }
  if (curPetty() != null) {
    l.add(TodoItem(t('todoPetty'), Btn(t('closeVege'), size: BS.sm, onTap: () {
      close();
      closePetty(context);
    })));
  }
  return l;
}

List<String> outDone() {
  final l = <String>[];
  final sh = todayShift();
  if (sh != null && sh['closedAt'] != null) l.add(t('todoCash'));
  if (sh != null && sh['tngClosedAt'] != null) l.add(t('todoTng'));
  if (curPetty() == null && petty.any((p) => p['closedAt'] != null && sameDay(N(p['closedAt']), now()))) l.add(t('todoPetty'));
  return l;
}

Future<void> clockOut(BuildContext context, [dynamic id]) async {
  final hasTodo = outTodo(context, context).isNotEmpty;
  if (hasTodo) {
    _outFlow = true;
    await showDlg(context, (c) {
      final todo = outTodo(context, c);
      if (todo.isEmpty) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (Navigator.of(c).canPop()) Navigator.of(c).pop();
        });
      }
      Widget row(Widget ic, String label, String? sub, Widget? btn, bool done) => Container(
            padding: const EdgeInsets.symmetric(vertical: 12),
            decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: C.line))),
            child: Row(children: [
              Container(
                  width: 30, height: 30, alignment: Alignment.center,
                  decoration: BoxDecoration(color: done ? C.okSoft : C.warnSoft, borderRadius: BorderRadius.circular(9)),
                  child: ic),
              hgap(12),
              Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(label, style: ts(14.5, w: w7, c: done ? C.muted : C.ink)),
                if (sub != null) Text(sub, style: ts(12.5, c: C.muted)),
              ])),
              if (btn != null) btn,
            ]),
          );
      return Dlg(
        title: t('outListTitle'),
        sub: t('outListSub'),
        body: Column(children: [
          for (final x in todo) row(const Ic('alert', size: 16, color: C.warn), x.label, x.sub, x.btn, false),
          for (final d in outDone()) row(const Ic('check', size: 16, color: C.ok), d, null, null, true),
        ]),
        foot: [Expanded(child: Btn(t('close'), kind: BK.sec, onTap: () => Navigator.pop(c)))],
      );
    });
    if (outTodo(context, context).isNotEmpty) return;
  }
  _outFlow = false;
  if (!context.mounted) return;
  final open = att.where((a) => sameDay(N(a['inAt']), now()) && a['outAt'] == null).toList();
  final sid = id ?? (open.isNotEmpty ? open.first['staff'] : null);
  if (sid == null) {
    toast(t('notIn'), 'info');
    return;
  }
  await showDlg(context, (c) => ClockDialog(mode: 'out', staffId: sid));
}

/* ---------------- close day ---------------- */
Future<void> closeDay(BuildContext context) async {
  final cook = orders.where((o) => o['status'] == 'pending').length;
  final un = unpaidOrders().length;
  if (cook > 0 || un > 0) {
    await showDlg(context, (c) => Dlg(
          title: t('cantClose'),
          sub: t('cantCloseSub'),
          body: Column(children: [
            if (cook > 0) Note(t('cookBlock', cook), kind: NK.bad, icon: 'flame'),
            if (cook > 0 && un > 0) gap(10),
            if (un > 0) Note(t('openBlock', un), kind: NK.bad),
          ]),
          foot: [
            Btn(t('cancel'), kind: BK.sec, onTap: () => Navigator.pop(c)),
            if (cook > 0)
              Expanded(child: Btn(t('kitchen'), kind: BK.sec, full: true, onTap: () {
                Navigator.pop(c);
                _go('kitchen');
              })),
            if (un > 0)
              Expanded(child: Btn(t('openOrders'), full: true, onTap: () {
                Navigator.pop(c);
                _go('openOrders');
              })),
          ],
        ));
    return;
  }
  if (curShift() == null) return;
  final sh = await showDlg<Map<String, dynamic>>(context, (c) => const CloseDayDialog());
  if (sh == null || !context.mounted) return;
  S['tab'] = 'dashboard';
  S['range'] = <String, dynamic>{'preset': 'today', 'date': ''};
  save();
  toast(t('dayClosed'));
  final outs = stockList.where((x) => D(Mp(sh['stock'])[x['id']]) == 0 && Mp(sh['stock'])[x['id']] != null).toList();
  await showDlg(context, (c) => _ClosedDialog(sh: sh, outs: outs));
}

class _ClosedDialog extends StatefulWidget {
  final Map<String, dynamic> sh;
  final List<dynamic> outs;
  const _ClosedDialog({required this.sh, required this.outs});
  @override
  State<_ClosedDialog> createState() => _ClosedDialogState();
}

class _ClosedDialogState extends State<_ClosedDialog> {
  String status = 'sending';
  String? err;
  @override
  void initState() {
    super.initState();
    if (widget.sh['tgSent'] != null) {
      status = 'ok';
    } else {
      _send();
    }
  }

  Future<void> _send() async {
    setState(() => status = 'sending');
    final e = await sendTelegram(oosText(widget.sh, widget.outs));
    if (!mounted) return;
    if (e == null) {
      widget.sh['tgSent'] = now();
      save();
    }
    setState(() {
      status = e == null ? 'ok' : 'fail';
      err = e;
    });
  }

  @override
  Widget build(BuildContext context) {
    final msg = oosText(widget.sh, widget.outs);
    return Dlg(
      title: t('dayClosed'),
      sub: t('waAutoSub'),
      body: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (widget.outs.isNotEmpty) ...[
          wrapRow(widget.outs.map((x) => Tag('${nm(x['names'])} · 0 ${x['unit']}', kind: TK.bad, size: 13)).toList()),
          gap(12),
        ],
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: const Color(0xFFEAF6FC), borderRadius: BorderRadius.circular(12)),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Ic('bell', size: 17, color: Color(0xFF0E7490)),
            hgap(10),
            Expanded(child: Text(msg, style: ts(13.5, w: w6, c: const Color(0xFF0E4A5E), h: 1.45))),
          ]),
        ),
        gap(8),
        if (status == 'sending') Note(t('tgSending'), icon: 'bell'),
        if (status == 'ok') Note(t('tgSentOk'), kind: NK.ok),
        if (status == 'fail') ...[
          Note('${t('tgFailed')}${err != null ? ' ($err)' : ''}', kind: NK.warn),
          gap(8),
          Btn(t('tgSendBot'), kind: BK.tg, size: BS.sm, icon: 'bell', onTap: _send),
        ],
      ]),
      foot: [
        Btn(t('close'), kind: BK.sec, onTap: () => Navigator.pop(context)),
        Expanded(
            child: Btn(t('clockOut'), full: true, onTap: () {
          final ctx = navContext(context);
          Navigator.pop(context);
          clockOut(ctx);
        })),
      ],
    );
  }
}

/// A context that stays valid after a dialog closes (the root navigator's).
BuildContext navContext(BuildContext c) => Navigator.of(c, rootNavigator: true).context;

/* ---------------- orders ---------------- */
Future<void> voidOrder(BuildContext context, dynamic id) async {
  final o = orderById(id);
  if (o == null) return;
  final ok = await confirmDlg(context, t('voidConfirm', o['n']),
      body: Text(L(o['lines']).map((l) => '${l['qty']}× ${lineName(l)}').join('\n'), style: ts(14, c: C.ink2, h: 1.55)), okLabel: t('void'));
  if (!ok) return;
  if (trackOrder(o, () => o['status'] = 'voided')) toast(t('chToast'));
  save();
}

void markDone(dynamic id) {
  final o = orderById(id);
  if (o == null) return;
  o['status'] = 'done';
  o['readyAt'] = now();
  save();
  if (isDel(o)) {
    o['appReady'] = true;
    save();
    toast(t('readySynced').replaceAll('{p}', t('ch_${o['ch']}')), 'scooter');
  }
}

Future<void> payOrder(BuildContext context, dynamic id) => showDlg(context, (c) => PayDialog(orderId: id));

Future<void> viewOrder(BuildContext context, dynamic id) async {
  final o = orderById(id);
  if (o == null) return;
  if (o['status'] == 'voided') {
    await showDlg(context, (c) => Dlg(
        title: '#${o['n']} · ${t('voided')}',
        sub: '${fmtD(N(o['t']))} ${fmtT(N(o['t']))}',
        body: Text(orderCodes(o), style: ts(14, c: C.ink2, h: 1.55)),
        foot: [Btn(t('close'), kind: BK.sec, onTap: () => Navigator.pop(c))]));
    return;
  }
  if (isDel(o)) return settleOrder(context, id);
  await showDlg(context, (c) => PayDialog(orderId: id, edit: o['paid'] == true));
}

Future<void> settleOrder(BuildContext context, dynamic id) async {
  final o = orderById(id);
  if (o == null) return;
  String v = o['received'] != null ? '${o['received']}' : '';
  await showDlg(context, (c) {
    return StatefulBuilder(builder: (c, set) {
      final g = N(o['gross'] ?? oShop(o));
      final r = double.tryParse(v);
      final fee = r == null ? null : g - r;
      return Dlg(
        title: t('settleTitle'),
        sub: '#${o['n']} · ${t('ch_${o['ch']}')}${Str(o['tag']).isNotEmpty ? ' · ${o['tag']}' : ''}',
        body: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(t('settleSub'), style: ts(13.5, c: C.muted)),
          gap(14),
          ExpBox([
            (t('appPrice'), Text(rm(g), style: ts(17, w: w8))),
            (t('shopPrice'), Text(rm(oShop(o)), style: ts(17, w: w8))),
          ]),
          gap(14),
          Field(t('receivedAmt'), Inp(value: v, number: true, big: true, hint: '0.00', autofocus: true, onChanged: (s) => set(() => v = s))),
          gap(14),
          Row(children: [
            Expanded(child: Text(t('platformFee'), style: ts(14.5, w: w7))),
            Text(fee == null ? '–' : '${rm(fee)} (${g > 0 ? (fee / g * 100).toStringAsFixed(0) : 0}%)', style: ts(15, w: w8, c: C.warn)),
          ]),
        ]),
        foot: [
          Btn(t('cancel'), kind: BK.sec, onTap: () => Navigator.pop(c)),
          Expanded(
              child: Btn(t('closeSale'), icon: 'check', kind: BK.ok, size: BS.lg, full: true, onTap: r == null || r < 0
                  ? null
                  : () {
                      final logged = trackOrder(o, () {
                        o['received'] = r2(r!);
                        o['paid'] = true;
                        o['pay'] = 'platform';
                        o['paidAt'] = o['paidAt'] ?? now();
                        o['status'] = 'done';
                        o['delivered'] = true;
                      });
                      save();
                      Navigator.pop(c);
                      toast(logged ? t('chToast') : t('settledToast', o['n']).replaceAll('{x}', rm(o['received'])));
                    })),
        ],
      );
    });
  });
}

void simDelivered(dynamic id) {
  final o = orderById(id);
  if (o == null) return;
  o['delivered'] = true;
  o['deliveredAt'] = now();
  o['status'] = 'done';
  save();
  toast(t('deliveredToast', o['n']), 'scooter');
}

void simPayout(dynamic id) {
  final o = orderById(id);
  if (o == null) return;
  final g = N(o['gross'] ?? oApp(o));
  o['received'] = r2(g * (0.70 + math.Random().nextDouble() * 0.06));
  o['paid'] = true;
  o['pay'] = 'platform';
  o['paidAt'] = now();
  o['status'] = 'done';
  o['delivered'] = true;
  save();
  toast(t('autoPaid', o['n']).replaceAll('{p}', t('ch_${o['ch']}')).replaceAll('{x}', rm(o['received'])));
}

/* ---------------- delivery alarm + test order ---------------- */
bool _alarmOpen = false;
int _lastAlarm = 0;
void checkOverdue(BuildContext context) {
  final late = orders.where((o) => isOverdue(o) && o['alerted'] != true).toList();
  if (late.isEmpty) return;
  if (_alarmOpen) {
    if (now() - _lastAlarm > 3000) {
      _lastAlarm = now();
      alarmSound();
    }
    return;
  }
  if (store.dialogs > 0) {
    if (now() - _lastAlarm > 10000) {
      _lastAlarm = now();
      alarmSound();
      toast(t('alarmTitle'), 'bell');
    }
    return;
  }
  _alarmOpen = true;
  _lastAlarm = now();
  alarmSound();
  final ids = late.map((o) => o['id']).toList();
  void ack() {
    for (final id in ids) {
      orderById(id)?['alerted'] = true;
    }
    save();
  }

  showDlg(context, dismissible: false, (c) {
    final list = ids.map(orderById).whereType<Map<String, dynamic>>().toList();
    return Dlg(
      headColor: C.bad,
      closeBtn: false,
      titleWidget: Row(children: [
        const Ic('bell', size: 26, color: Colors.white),
        hgap(12),
        Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(t('alarmTitle'), style: ts(22, w: w8, c: Colors.white)),
          Text(t('alarmSub'), style: ts(13.5, c: Colors.white70)),
        ])),
      ]),
      body: Column(children: [
        for (final o in list)
          Container(
            margin: const EdgeInsets.only(top: 10),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(color: C.badSoft, borderRadius: BorderRadius.circular(12)),
            child: Row(children: [
              Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('#${o['n']} ${t('ch_${o['ch']}')} ${Str(o['tag'])}', style: ts(14.5, w: w8)),
                Text(orderCodes(o), style: ts(13, c: C.muted)),
              ])),
              Tag(dueText(o), kind: TK.bad),
            ]),
          ),
      ]),
      foot: [
        Btn(t('gotIt'), kind: BK.sec, onTap: () {
          ack();
          Navigator.pop(c);
        }),
        Expanded(
            child: Btn(t('goKitchen'), icon: 'flame', size: BS.lg, full: true, bg: C.bad, onTap: () {
          ack();
          Navigator.pop(c);
          _go('kitchen');
        })),
      ],
    );
  }).whenComplete(() => _alarmOpen = false);
}

void testAlarm() {
  Map<String, dynamic>? o;
  for (final x in orders) {
    if (isDel(x) && x['status'] == 'pending') o = x as Map<String, dynamic>;
  }
  if (o == null) {
    toast(t('noCooking'), 'info');
    return;
  }
  o['due'] = now() - 1000;
  o['alerted'] = false;
  save();
}

Future<void> testOrder(BuildContext context) async {
  final mains = menuList.where((m) => m['isAddon'] != true && m['available'] == true).toList();
  if (mains.isEmpty) return;
  final rnd = math.Random();
  final ch = kDelivery[rnd.nextInt(3)];
  final m1 = mains.first, m2 = mains[rnd.nextInt(mains.length)];
  Map<String, dynamic> ln(dynamic m, bool big) {
    final b = big && m['pb'] != null;
    return <String, dynamic>{
      'id': m['id'], 'code': m['code'], 'names': deepCopy(m['names']), 'big': b, 'hasSize': m['pb'] != null,
      'choices': m['series'] == 'fish'
          ? <String, dynamic>{'fish': 'masak', 'noodle': 'B', 'milk': 'yes', 'alcohol': 'no'}
          : <String, dynamic>{'noodle': 'C'},
      'addons': <dynamic>[], 'opts': <dynamic>[], 'qty': 1,
      'base': b ? m['pb'] : m['ps'], 'unit': b ? m['pb'] : m['ps'], 'app': itemApp(m, b, ch),
    };
  }

  final order = <String, dynamic>{
    'id': uid('o'), 'n': 0, 't': now(), 'ch': ch, 'lines': [ln(m1, true), ln(m2, false)], 'disc': 0,
    'note': 'Less spicy please', 'tag': '${{'grab': 'GF-', 'foodpanda': 'FP-', 'shopee': 'SF-'}[ch]}${100 + rnd.nextInt(900)}',
    'status': 'pending', 'paid': false, 'pay': null,
  };
  order['gross'] = oApp(order);
  var ringing = true;
  Future<void> ring() async {
    while (ringing) {
      chime();
      await Future<void>.delayed(const Duration(milliseconds: 2500));
    }
  }

  ring();
  final accept = await showDlg<bool>(context, dismissible: false, (c) => Dlg(
        headColor: kCh[ch],
        closeBtn: false,
        titleWidget: Row(children: [
          const Ic('bell', size: 26, color: Colors.white),
          hgap(12),
          Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(t('incoming'), style: ts(13, w: w7, c: Colors.white70)),
            Text('${t('ch_$ch')} ${order['tag']}', style: ts(24, w: w8, c: Colors.white)),
          ])),
        ]),
        body: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          DelLines(order),
          gap(12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: C.warnSoft, borderRadius: BorderRadius.circular(10)),
            child: Text(Str(order['note']), style: ts(14, w: w7, c: const Color(0xFF92400E))),
          ),
          gap(14),
          Row(children: [Expanded(child: Text(t('appPrice'), style: ts(15, w: w7))), Text(rm(oTotal(order)), style: ts(22, w: w8))]),
          Row(children: [Expanded(child: Text(t('shopPrice'), style: ts(14, w: w6, c: C.muted))), Text(rm(oShop(order)), style: ts(14, c: C.muted))]),
          Sub(t('pendingPayHint')),
        ]),
        foot: [
          Btn(t('reject'), kind: BK.sec, onTap: () => Navigator.pop(c, false)),
          Expanded(child: Btn(t('accept'), icon: 'check', kind: BK.ok, size: BS.lg, full: true, onTap: () => Navigator.pop(c, true))),
        ],
      ));
  ringing = false;
  if (accept == true) {
    order['n'] = nextNo();
    order['t'] = now();
    order['due'] = N(order['t']) + I(Mp(S['prep'])[ch] ?? 15) * 60000;
    orders.add(order);
    save();
    toast(t('accepted', order['n']));
  } else {
    toast(t('rejected'), 'x');
  }
}

/// Delivery order lines with app price and shop price side by side.
class DelLines extends StatelessWidget {
  final dynamic o;
  const DelLines(this.o, {super.key});
  @override
  Widget build(BuildContext context) {
    return SimpleTable(
      head: ['', t('appPrice'), t('shopPrice')],
      fs: 13.5,
      rows: [
        for (final l in L(o['lines']))
          [
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${l['qty']}× ${lineCode(l)}', style: ts(14, w: w8, ls: 0.3)),
              ChoiceChips(l),
              if (L(l['addons']).isNotEmpty) Text('+ ${lineAddons(l)}', style: ts(12.5, c: C.muted)),
            ]),
            Text(rm(N(l['app'] ?? appRound(N(l['unit']), kAppF[o['ch']] ?? 1.2)) * N(l['qty']))),
            Text(rm(N(l['unit']) * N(l['qty'])), style: ts(13.5, w: w6, c: C.muted)),
          ]
      ],
    );
  }
}

/* ---------------- registers / expenses ---------------- */
Future<void> regHist(BuildContext context, String r, dynamic id) => showDlg(context, (c) => RegHistDialog(r: r, id: id));

Future<void> editExpense(BuildContext context, dynamic id, {Map<String, dynamic>? back}) async {
  Map<String, dynamic>? e;
  for (final x in expenses) {
    if (x['id'] == id) e = x as Map<String, dynamic>;
  }
  if (e == null) return;
  await showDlg(context, (c) => ExpenseDialog(e: Map<String, dynamic>.from(e!), isNew: false));
}

Future<void> manualExpense(BuildContext context, {String? paidBy, int? at}) => showDlg(
    context,
    (c) => ExpenseDialog(
          isNew: true,
          e: <String, dynamic>{
            'id': uid('e'), 'date': isoDate(at ?? now()), 'vendor': '', 'amount': null, 'cat': null, 'photo': null, 'paidBy': paidBy,
          },
        ));

Future<void> snapReceipt(BuildContext context) async {
  final photo = await takePhoto(maxSize: 900, quality: 70);
  if (photo == null || !context.mounted) return;
  await showDlg(
      context,
      (c) => ExpenseDialog(
            isNew: true,
            e: <String, dynamic>{'id': uid('e'), 'date': isoDate(now()), 'vendor': '', 'amount': null, 'cat': null, 'photo': photo, 'paidBy': null},
          ));
}

/* ---------------- more sheet (phones) ---------------- */
Future<void> moreSheet(BuildContext context) => showDlg(
    context,
    (c) => Dlg(
          title: t('more'),
          body: Column(children: [
            for (final n in kNav2)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Material(
                  color: C.surface,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: const BorderSide(color: C.line2, width: 1.5)),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(14),
                    onTap: () {
                      Navigator.pop(c);
                      _go(n[0]);
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Row(children: [Ic(n[1], color: C.ink2), hgap(12), Text(t(n[0]), style: ts(15, w: w7))]),
                    ),
                  ),
                ),
              ),
          ]),
        ));

import 'dart:async';

import 'package:flutter/material.dart';

import '../data/consts.dart';
import '../data/logic.dart';
import '../data/store.dart';
import '../data/util.dart';
import 'actions.dart';
import 'pages/attendance.dart';
import 'pages/dashboard.dart';
import 'pages/expenses.dart';
import 'pages/kitchen.dart';
import 'pages/menu.dart';
import 'pages/open_orders.dart';
import 'pages/pos.dart';
import 'pages/registers.dart';
import 'pages/settings.dart';
import 'theme.dart';
import 'widgets.dart';

final navKey = GlobalKey<NavigatorState>();

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  Timer? _tick;
  int _sec = 0;
  @override
  void initState() {
    super.initState();
    // Every second: countdowns refresh and the late-delivery alarm is checked. Every 30 s the clock-based pills refresh.
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      _sec++;
      final hasDue = orders.any((o) => o['status'] == 'pending' && o['due'] != null);
      if (hasDue || _sec % 30 == 0) store.refresh();
      checkOverdue(context);
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (S['tab'] == 'pos' && curShift() == null && !todayClosed() && clockedIn()) openShift(context);
    });
  }

  @override
  void dispose() {
    _tick?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final w = MediaQuery.sizeOf(context).width;
        final mobile = w < 700, compact = w < 1180;
        final tab = Str(S['tab']).isEmpty ? 'pos' : Str(S['tab']);
        final body = Column(children: [
          _Header(tab: tab, mobile: mobile),
          Expanded(child: _page(tab)),
        ]);
        return Scaffold(
          backgroundColor: C.bg,
          body: Stack(children: [
            SafeArea(
              bottom: false,
              child: mobile
                  ? Column(children: [Expanded(child: body), _BottomNav(tab: tab)])
                  : Row(children: [_SideNav(tab: tab, compact: compact), Expanded(child: body)]),
            ),
            _Toast(key: ValueKey(store.toastAt)),
          ]),
        );
      },
    );
  }

  Widget _page(String tab) {
    switch (tab) {
      case 'dashboard':
        return DashboardPage(); // not const: must rebuild when data changes
      case 'kitchen':
        return KitchenPage(); // not const: must rebuild when data changes
      case 'openOrders':
        return OpenOrdersPage(); // not const: must rebuild when data changes
      case 'registers':
        return RegistersPage(); // not const: must rebuild when data changes
      case 'attendance':
        return AttendancePage(); // not const: must rebuild when data changes
      case 'expenses':
        return ExpensesPage(); // not const: must rebuild when data changes
      case 'menu':
        return MenuPage(); // not const: must rebuild when data changes
      case 'settings':
        return SettingsPage(); // not const: must rebuild when data changes
      default:
        return PosPage(); // not const: must rebuild when data changes
    }
  }
}

String? _badge(String k) {
  if (k == 'kitchen' && pendingCount() > 0) return '${pendingCount()}';
  if (k == 'openOrders' && unpaidOrders().isNotEmpty) return '${unpaidOrders().length}';
  if (k == 'registers') {
    final n = changes.where((c) => c['seen'] != true).length;
    if (n > 0) return '$n';
  }
  return null;
}

class _NavBtn extends StatelessWidget {
  final String k, icon;
  final bool on, compact, mobile;
  final VoidCallback onTap;
  const _NavBtn(this.k, this.icon, {required this.on, required this.onTap, this.compact = false, this.mobile = false});
  @override
  Widget build(BuildContext context) {
    final b = _badge(k);
    final f = on ? C.p : C.ink2;
    final badge = b == null
        ? null
        : Container(
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 1),
            constraints: const BoxConstraints(minWidth: 20),
            decoration: BoxDecoration(color: k == 'kitchen' ? C.p : C.warn, borderRadius: BorderRadius.circular(999)),
            child: Text(b, textAlign: TextAlign.center, style: ts(11, w: w7, c: Colors.white)),
          );
    final vertical = compact || mobile;
    return Material(
      color: on && !mobile ? C.pSoft : Colors.transparent,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Container(
          width: mobile ? null : (compact ? 64 : double.infinity),
          padding: EdgeInsets.symmetric(horizontal: vertical ? 4 : 12, vertical: vertical ? (mobile ? 6 : 10) : 11),
          child: vertical
              ? Stack(clipBehavior: Clip.none, children: [
                  Column(mainAxisSize: MainAxisSize.min, children: [
                    Ic(icon, size: 20, color: f),
                    gap(4),
                    Text(t(k), maxLines: 2, textAlign: TextAlign.center, overflow: TextOverflow.ellipsis, style: ts(mobile ? 10 : 11, w: w6, c: f)),
                  ]),
                  if (badge != null) Positioned(top: -4, right: 0, child: badge),
                ])
              : Row(children: [
                  Ic(icon, size: 20, color: f),
                  hgap(12),
                  Expanded(child: Text(t(k), style: ts(14.5, w: w6, c: f))),
                  if (badge != null) badge,
                ]),
        ),
      ),
    );
  }
}

void goTab(String k) {
  S['tab'] = k;
  store.save();
}

class _SideNav extends StatelessWidget {
  final String tab;
  final bool compact;
  const _SideNav({required this.tab, required this.compact});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: compact ? 84 : 232,
      decoration: const BoxDecoration(color: C.surface, border: Border(right: BorderSide(color: C.line))),
      padding: EdgeInsets.symmetric(horizontal: compact ? 10 : 14, vertical: 20),
      child: SingleChildScrollView(
        child: Column(crossAxisAlignment: compact ? CrossAxisAlignment.center : CrossAxisAlignment.stretch, children: [
          Padding(
            padding: EdgeInsets.fromLTRB(compact ? 0 : 8, 2, 8, 22),
            child: Row(mainAxisSize: compact ? MainAxisSize.min : MainAxisSize.max, children: [
              Container(
                width: 38, height: 38, alignment: Alignment.center,
                decoration: BoxDecoration(color: C.p, borderRadius: BorderRadius.circular(12)),
                child: Text('N', style: ts(17, w: w8, c: Colors.white)),
              ),
              if (!compact) ...[
                hgap(11),
                Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Niuma Kitchen', style: ts(15, w: w8)),
                  Text('Heart Garden, Balakong', style: ts(12, w: w6, c: C.muted)),
                ])),
              ],
            ]),
          ),
          for (final n in kNav) Padding(padding: const EdgeInsets.only(bottom: 2), child: _NavBtn(n[0], n[1], on: tab == n[0], compact: compact, onTap: () => goTab(n[0]))),
          if (!compact)
            Padding(padding: const EdgeInsets.fromLTRB(12, 18, 12, 8), child: Text(t('more'), style: ts(12, w: w7, c: C.muted)))
          else
            const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: SizedBox(width: 40, child: Divider(height: 1))),
          for (final n in kNav2) Padding(padding: const EdgeInsets.only(bottom: 2), child: _NavBtn(n[0], n[1], on: tab == n[0], compact: compact, onTap: () => goTab(n[0]))),
        ]),
      ),
    );
  }
}

class _BottomNav extends StatelessWidget {
  final String tab;
  const _BottomNav({required this.tab});
  @override
  Widget build(BuildContext context) {
    final moreOn = kNav2.any((n) => n[0] == tab);
    return Container(
      decoration: const BoxDecoration(color: C.surface, border: Border(top: BorderSide(color: C.line))),
      padding: EdgeInsets.fromLTRB(4, 6, 4, 6 + MediaQuery.paddingOf(context).bottom),
      child: Row(children: [
        for (final n in kNav) Expanded(child: _NavBtn(n[0], n[1], on: tab == n[0], mobile: true, onTap: () => goTab(n[0]))),
        Expanded(child: _NavBtn('more', 'grid', on: moreOn, mobile: true, onTap: () => moreSheet(context))),
      ]),
    );
  }
}

class _Header extends StatelessWidget {
  final String tab;
  final bool mobile;
  const _Header({required this.tab, required this.mobile});
  @override
  Widget build(BuildContext context) {
    final sh = curShift();
    final bs = bizStatus();
    final cin = clockedIn();
    final k = bs['k'];
    final bizTxt = k == 'open'
        ? t('bizOpen').replaceAll('{x}', fmtT(bs['until'] as int))
        : k == 'break'
            ? t('bizBreak').replaceAll('{x}', fmtT(bs['at'] as int))
            : k == 'before'
                ? t('bizBefore').replaceAll('{x}', fmtT(bs['at'] as int))
                : k == 'off'
                    ? t('bizOff')
                    : t('bizAfter');
    final (Color bb, Color bf) = switch (k) {
      'open' => (C.okSoft, C.ok),
      'break' || 'before' => (C.warnSoft, C.warn),
      'off' => (C.badSoft, C.bad),
      _ => (C.sunken, C.muted),
    };
    final ls = lastShift();
    final items = <Widget>[
      _pill(bizTxt, bb, bf),
      if (cin)
        Btn(t('clockOut'), icon: 'user', kind: BK.sec, size: BS.sm, onTap: () => clockOut(context))
      else if (staffList.isNotEmpty && staffList.every((st) => attToday(st['id']) != null))
        _pill(t('allOut'), C.sunken, C.muted)
      else
        Btn(t('clockIn'), icon: 'camera', kind: sh != null ? BK.sec : BK.primary, size: BS.sm, onTap: () => clockIn(context)),
      if (sh != null) ...[
        _pill(mobile ? '' : '${t('shiftOpen')} ${t('since')} ${fmtT(N(sh['openedAt']))}', C.okSoft, C.ok, dot: true),
        if (sh['tngOpenedAt'] == null) Btn(t('openTng'), icon: 'wallet', kind: BK.soft, size: BS.sm, onTap: () => openTng(context)),
        Btn(t('closeDay'), icon: 'lock', kind: BK.sec, size: BS.sm, onTap: () => closeDay(context)),
      ] else ...[
        _pill(mobile ? '' : t('shiftClosed'), C.sunken, C.muted, dot: true),
        if (ls != null && ls['tngOpenedAt'] != null && ls['tngClosedAt'] == null)
          Btn(t('closeTng'), icon: 'wallet', kind: BK.soft, size: BS.sm, onTap: () => closeTng(context, ls['id'])),
        if (cin && !shifts.any((x) => x['closedAt'] != null && sameDay(N(x['openedAt']), now())))
          Btn(t('openShift'), size: BS.sm, onTap: () => openShift(context)),
      ],
    ];
    return Container(
      decoration: const BoxDecoration(color: C.surface, border: Border(bottom: BorderSide(color: C.line))),
      padding: EdgeInsets.symmetric(horizontal: mobile ? 16 : 28, vertical: mobile ? 10 : 14),
      constraints: BoxConstraints(minHeight: mobile ? 60 : 72),
      child: Row(children: [
        Text(t(tab), style: ts(mobile ? 18 : 20, w: w8, ls: -0.3)),
        hgap(10),
        _SyncPill(),
        hgap(10),
        Expanded(
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            reverse: true,
            child: Row(children: [for (final w in items) Padding(padding: const EdgeInsets.only(left: 8), child: w)]),
          ),
        ),
      ]),
    );
  }

  Widget _pill(String text, Color b, Color f, {bool dot = false}) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
        decoration: BoxDecoration(color: b, borderRadius: BorderRadius.circular(999)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          if (dot) Dot(f),
          if (dot && text.isNotEmpty) hgap(8),
          if (text.isNotEmpty) Text(text, style: ts(12.5, w: w7, c: f)),
        ]),
      );
}

class _SyncPill extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final s = store.state;
    final (Color b, Color f) = switch (s) {
      'ok' => (C.okSoft, C.ok),
      'saving' || 'connecting' => (C.warnSoft, C.warn),
      'offline' || 'ro' => (C.badSoft, C.bad),
      _ => (C.sunken, C.muted),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(color: b, borderRadius: BorderRadius.circular(999)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Dot(f),
        if (!isNarrow(context)) ...[hgap(6), Text(t('sync_$s'), style: ts(12.5, w: w7, c: f))],
      ]),
    );
  }
}

class _Toast extends StatefulWidget {
  const _Toast({super.key});
  @override
  State<_Toast> createState() => _ToastState();
}

class _ToastState extends State<_Toast> {
  bool show = false;
  Timer? _t;
  @override
  void initState() {
    super.initState();
    if (store.toastMsg.isNotEmpty && now() - store.toastAt < 1000) {
      show = true;
      _t = Timer(const Duration(milliseconds: 2400), () {
        if (mounted) setState(() => show = false);
      });
    }
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final mobile = isNarrow(context);
    return Positioned(
      left: 0,
      right: 0,
      bottom: mobile ? 84 : 24,
      child: IgnorePointer(
        child: AnimatedOpacity(
          opacity: show ? 1 : 0,
          duration: const Duration(milliseconds: 200),
          child: Center(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
              decoration: BoxDecoration(
                  color: C.ink, borderRadius: BorderRadius.circular(14), boxShadow: const [BoxShadow(color: Color(0x2E16131F), blurRadius: 64, offset: Offset(0, 24))]),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Ic(store.toastIcon, size: 17, color: Colors.white),
                hgap(9),
                Flexible(child: Text(store.toastMsg, style: ts(14, w: w7, c: Colors.white))),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}

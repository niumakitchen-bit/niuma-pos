# Niuma POS（Flutter + Firebase + Cloudflare）

同一份代码出三个版本：**网页版**（放在 Cloudflare Pages）、**iPhone app**、**iPad app**。
资料存在 **Firebase Firestore**（免费方案），所有设备即时同步，断网也能继续用，网络回来自动补传。
照片（打卡照片、收据、菜品图）压缩后存在 **Firestore**（不用付费的 Storage），每台设备都看得到。
缺货提醒由 **Cloudflare 服务器**发到 Telegram，bot token 只放在服务器，不放在任何设备里。

功能、逻辑和设计跟 claude.ai 上的 Niuma POS v4.0 一样。只少了一样：收据 AI 自动识别（自己的服务器没有 Claude，拍照后手动填写）。

---

## 一次性设置（大约 40 分钟）

### 1. Firebase（资料库和登入）
1. 打开 https://console.firebase.google.com ，用 niumakitchen@gmail.com 登入，按 **Create a project**，名字填 `niuma-pos`，Google Analytics 可以关掉。
2. 左边 **Build → Firestore Database → Create database**：地点选 **asia-southeast1 (Singapore)**，选 **Production mode**。
3. 打开 **Rules** 分页，把本项目的 `firestore.rules` 整个贴进去。把 `PUT_BUDDY_EMAIL_HERE@gmail.com` 换成你伙伴的邮箱，然后按 **Publish**。
4. 左边 **Build → Authentication → Get started → Email/Password → Enable**。
5. 打开 **Users** 分页，按 **Add user**，为你和伙伴各加一个账号（邮箱加密码）。以后就用这两个账号登入 POS。
6. 左上角齿轮 **Project settings → General → Your apps**：
   - 按 `</>`（Web），名字填 `niuma-web`，注册后会看到一段 `firebaseConfig`。
   - 再按 **Add app → iOS**，Bundle ID 填 `com.niumakitchen.niumaPos`，下载 `GoogleService-Info.plist`。
7. 打开 `lib/config.dart`，把上面的值填进去：
   - 网页的 `apiKey`、`appId`、`messagingSenderId`、`projectId`、`authDomain`、`storageBucket`
   - iOS 的 `API_KEY` 和 `GOOGLE_APP_ID`（在 GoogleService-Info.plist 里）

### 2. GitHub（放代码，自动编译）
1. 在 https://github.com 新建一个 **Private** repository，名字填 `niuma-pos`。
2. 按 **Add file → Upload files**，把这个文件夹里的所有文件拖进去（包括 `.github` 文件夹），然后按 **Commit**。

### 3. Cloudflare（网页版和 Telegram 服务器）
1. 打开 https://dash.cloudflare.com 注册（免费），左边 **Workers & Pages**，在右边记下 **Account ID**。
2. 右上角头像 **My Profile → API Tokens → Create Token**，选 **Edit Cloudflare Workers** 模板，按 **Create**，复制 token。
3. 回到 GitHub repo：**Settings → Secrets and variables → Actions → New repository secret**，加两个：
   - `CLOUDFLARE_API_TOKEN` = 上一步复制的 token
   - `CLOUDFLARE_ACCOUNT_ID` = 你的 Account ID
4. 打开 GitHub repo 的 **Actions → Deploy web app → Run workflow**。大约 5 分钟后，网站会出现在 **https://niuma-pos.pages.dev**。
5. 回到 Cloudflare：**Workers & Pages → niuma-pos → Settings → Variables and Secrets**，加四个（Production）：
   - `TG_TOKEN`（选 Secret）= BotFather 给的 bot token
   - `TG_CHAT_ID`（选 Secret）= 你的 chat ID
   - `FIREBASE_PROJECT` = 你的 Firebase project ID（例如 `niuma-pos-1a2b3`）
   - `ALLOWED_EMAILS` = `niumakitchen@gmail.com,伙伴的邮箱`
6. 回 GitHub **Actions → Run workflow** 再跑一次，让设置生效。
7. 在 Firebase **Authentication → Settings → Authorized domains** 里加上 `niuma-pos.pages.dev`。

**第一次编译如果失败：** 打开 Actions 里红色的那一次，点 **Check the code** 或 **Build the web app**，把红字错误复制给 Adam。代码是在没有 Flutter 的环境里写的，第一次编译可能要修一两轮。

### 4. 网页版
- 电脑、iPad、iPhone 都可以直接开 https://niuma-pos.pages.dev ，用 Firebase 里加的账号登入。
- iPad 或 iPhone 用 Safari 打开后，按分享，再按 **加入主画面**，就会像 app 一样全屏打开。

### 5. iPhone 和 iPad app（需要一台 Mac）
1. Mac 上安装 **Xcode**（App Store）、**Flutter**（https://docs.flutter.dev/get-started/install/macos ）和 CocoaPods（终端输入 `sudo gem install cocoapods`）。
2. 把 GitHub 上的代码下载到 Mac（**Code → Download ZIP**，解压）。
3. 打开终端，进入那个文件夹，输入 `bash tool/setup_ios.sh`。
4. Xcode 会自动打开：点左边 **Runner → Signing & Capabilities → Team**，选你的 Apple ID。
5. 用线把 iPhone 或 iPad 接上 Mac，上面选那台设备，按 ▶ **Run**。iPhone 第一次需要在 **设置 → 通用 → VPN 与设备管理** 里信任开发者。

关于 Apple 账号：
- **免费 Apple ID**：可以装到自己的 iPhone 和 iPad，但每 7 天要接回 Mac 重新按一次 Run。
- **Apple Developer（每年 99 美元）**：可以用 TestFlight 装到你和伙伴的手机，每个版本可以用 90 天，不用接线。要上 App Store 也需要这个账号。

---

## 每天使用
- 打卡（一定要用前置镜头拍照）→ 开钱箱 → 落单 → 收档（任务、库存、点钱）→ 自动发缺货清单到 Telegram → 关 TNG、零用钱 → 下班打卡。
- 顶部的小标签显示同步状态：绿色是已同步，橙色是保存中，红色是离线（资料先存在这台设备，网络回来自动补传）。

## 资料
- 新系统从零开始，没有示例数据。
- 员工名字、营业时间、菜单价钱，如果在 claude.ai 版本里改过，请在 **设置** 和 **菜单** 里重新填一次。
- Firestore 免费额度：每天 5 万次读取、2 万次写入，一间店用不完。

## 文件说明
| 路径 | 内容 |
|---|---|
| `lib/config.dart` | Firebase 设定和网站网址（**唯一要改的代码**） |
| `lib/data/` | 资料、同步、计算逻辑（钱箱、零用钱、改单记录、打卡） |
| `lib/ui/` | 页面和对话框 |
| `functions/api/telegram.js` | Cloudflare 服务器：发 Telegram |
| `firestore.rules` | 谁可以读写资料 |
| `.github/workflows/deploy-web.yml` | 自动编译并发布网页版 |
| `tool/setup_ios.sh` | Mac 上生成 iPhone/iPad app |

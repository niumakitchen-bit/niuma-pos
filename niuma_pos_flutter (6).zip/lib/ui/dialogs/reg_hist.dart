// Full history of one register session: amounts, note/coin counts at open and close, its payments and later changes.
import 'package:flutter/material.dart';

import '../../data/consts.dart';
import '../../data/logic.dart';
import '../../data/util.dart';
import '../actions.dart';
import '../pages/registers.dart';
import '../theme.dart';
import '../widgets.dart';

class RegHistDialog extends StatelessWidget {
  final String r;
  final dynamic id;
  const RegHistDialog({super.key, required this.r, required this.id});

  Widget _items(BuildContext context, List<dynamic> list) {
    if (list.isEmpty) return Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text(t('vegeNone'), style: ts(14, c: C.muted)));
    return Column(children: [
      for (final e in list)
        InkWell(
          onTap: () => editExpense(context, e['id']),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 10),
            decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: C.line))),
            child: Row(children: [
              Dot(kCatCol[e['cat']] ?? C.muted, size: 10),
              hgap(12),
              Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(Str(e['vendor']).isNotEmpty ? Str(e['vendor']) : t('cat_${e['cat']}'), style: ts(14.5, w: w7)),
                Text('${t('cat_${e['cat']}')} · ${fmtD(expAt(e))} ${fmtT(expAt(e))}', style: ts(12.5, c: C.muted)),
              ])),
              Text(e['cat'] == 'income' ? '+${rm(e['amount'])}' : rm(-N(e['amount'])), style: ts(14.5, w: w8)),
              hgap(8),
              const Ic('edit', size: 15, color: C.muted),
            ]),
          ),
        ),
    ]);
  }

  Widget _den(dynamic open, dynamic close) {
    final ds = kDenoms.where((d) => N(Mp(open)[denKey(d)]) > 0 || N(Mp(close)[denKey(d)]) > 0).toList();
    if (ds.isEmpty) return const SizedBox.shrink();
    num q(dynamic c, num d) => N(Mp(c)[denKey(d)]);
    return SimpleTable(head: [t('denom'), t('openCount'), '', t('closeCount'), ''], fs: 13.5, rows: [
      for (final d in ds)
        [
          Text(denLbl(d), style: ts(13.5, w: w8)),
          Text(open != null ? '× ${q(open, d)}' : '–'),
          Text(open != null ? rm(q(open, d) * d) : ''),
          Text(close != null ? '× ${q(close, d)}' : '–'),
          Text(close != null ? rm(q(close, d) * d) : ''),
        ],
      [
        Text(t('total'), style: ts(13.5, w: w8)),
        const Text(''),
        Text(open != null ? rm(denTotal(open)) : '–', style: ts(13.5, w: w8)),
        const Text(''),
        Text(close != null ? rm(denTotal(close)) : '–', style: ts(13.5, w: w8)),
      ],
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final chs = changes.where((c) => L(c['fx']).any((f) => f['reg'] == r && f['id'] == id)).toList();
    final chBlock = chs.isEmpty
        ? const SizedBox.shrink()
        : Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [Lbl(t('changesTitle')), for (final c in chs) ChangeRow(c)]);
    String title, sub;
    Widget body;
    final foot = <Widget>[Expanded(child: Btn(t('close'), kind: BK.sec, full: true, onTap: () => Navigator.pop(context)))];
    if (r == 'petty') {
      final ps = pettyById(id);
      if (ps == null) return const SizedBox.shrink();
      final ex = pettyExpected(ps);
      final closed = ps['closedAt'] != null;
      title = '${t('regVege')} · ${fmtD(N(ps['openedAt']))}';
      sub = '${t('openedAt')} ${fmtD(N(ps['openedAt']))} ${fmtT(N(ps['openedAt']))}${closed ? ' · ${t('closedAt')} ${fmtD(N(ps['closedAt']))} ${fmtT(N(ps['closedAt']))}' : ' · ${t('open')}'}';
      body = Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        KV.txt(t('opening'), rm(ps['openTotal'])),
        KV.txt(t('vegeSpent'), rm(-pettySpent(ps))),
        KV.txt(t('expected'), rm(ex), bold: true),
        KV.txt(t('counted'), closed ? rm(ps['closeTotal']) : '–'),
        KV(t('overShort'), VarTxt(closed ? N(ps['closeTotal']) - ex : null)),
        Lbl(t('notesCoins')),
        _den(ps['openCash'], closed ? ps['closeCash'] : null),
        Lbl(t('vegePayments')),
        _items(context, pettyItems(ps)),
        chBlock,
      ]);
      foot.add(Expanded(
          child: Btn(t('vegeAddPay'), icon: 'plus', full: true, onTap: () {
        final at = closed ? N(ps['closedAt']).toInt() - 60000 : now();
        manualExpense(context, paidBy: 'petty', at: at);
      })));
    } else {
      final sh = shiftById(id);
      if (sh == null) return const SizedBox.shrink();
      if (r == 'cash') {
        final ec = expCash(sh);
        final closed = sh['closedAt'] != null;
        title = '${t('regCash')} · ${fmtD(N(sh['openedAt']))}';
        sub = '${t('openedAt')} ${fmtT(N(sh['openedAt']))}${closed ? ' · ${t('closedAt')} ${fmtD(N(sh['closedAt']))} ${fmtT(N(sh['closedAt']))}' : ' · ${t('open')}'}';
        body = Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          KV.txt(t('opening'), rm(sh['openTotal'])),
          KV.txt(t('cashSales'), rm(shiftSales(sh, 'cash'))),
          KV.txt(t('paidOut'), rm(-cashSpent(sh))),
          KV.txt(t('expected'), rm(ec), bold: true),
          KV.txt(t('counted'), closed ? rm(sh['closeTotal']) : '–'),
          KV(t('overShort'), VarTxt(closed ? N(sh['closeTotal']) - ec : null)),
          Lbl(t('notesCoins')),
          _den(sh['openCash'], closed ? sh['closeCash'] : null),
          Lbl(t('paidOutList')),
          _items(context, regItems('cash', N(sh['openedAt']), closed ? N(sh['closedAt']) : now())),
          chBlock,
        ]);
      } else {
        final et = expTng(sh) ?? 0;
        final closed = sh['tngClosedAt'] != null;
        title = '${t('regTng')} · ${fmtD(N(sh['openedAt']))}';
        sub = '${t('openedAt')} ${fmtT(N(sh['tngOpenedAt']))}${closed ? ' · ${t('closedAt')} ${fmtD(N(sh['tngClosedAt']))} ${fmtT(N(sh['tngClosedAt']))}' : ' · ${t('open')}'}';
        body = Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          KV.txt(t('opening'), rm(sh['openTng'])),
          KV.txt(t('tngSales'), rm(shiftSales(sh, 'tng'))),
          KV.txt(t('paidOut'), rm(-tngSpent(sh))),
          KV.txt(t('expected'), rm(et), bold: true),
          KV.txt(t('counted'), closed ? rm(sh['closeTng']) : '–'),
          KV(t('overShort'), VarTxt(closed ? N(sh['closeTng']) - et : null)),
          Lbl(t('paidOutList')),
          _items(context, regItems('tng', N(sh['tngOpenedAt']), tngEnd(sh))),
          chBlock,
        ]);
        if (!closed && sh['closedAt'] != null) {
          foot.add(Expanded(
              child: Btn(t('closeTng'), icon: 'lock', full: true, onTap: () {
            final ctx = navContext(context);
            Navigator.pop(context);
            closeTng(ctx, sh['id']);
          })));
        }
      }
    }
    return Dlg(wide: true, title: title, sub: sub, body: body, foot: foot);
  }
}

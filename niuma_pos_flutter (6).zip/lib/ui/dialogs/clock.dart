// Clock in / out: a front-camera photo is required.
import 'package:flutter/material.dart';

import '../../data/logic.dart';
import '../../data/store.dart';
import '../../data/util.dart';
import '../../services.dart';
import '../theme.dart';
import '../widgets.dart';

class ClockDialog extends StatefulWidget {
  final String mode; // in | out
  final dynamic staffId;
  const ClockDialog({super.key, required this.mode, required this.staffId});
  @override
  State<ClockDialog> createState() => _ClockDialogState();
}

class _ClockDialogState extends State<ClockDialog> {
  late dynamic staff = widget.staffId;
  String? photo;
  bool busy = false;

  Future<void> _snap() async {
    setState(() => busy = true);
    final p = await takePhoto(front: true, maxSize: 360, quality: 60);
    if (!mounted) return;
    setState(() {
      busy = false;
      if (p != null) photo = p;
    });
  }

  @override
  Widget build(BuildContext context) {
    final isIn = widget.mode == 'in';
    final n = now();
    final target = atHM(n, Str(isIn ? hours['clockIn'] : hours['clockOut']));
    final diff = ((n - target) / 60000).round();
    final timing = isIn
        ? (diff > 0 ? Tag(t('lateM').replaceAll('{n}', '$diff'), kind: TK.bad) : Tag(t('onTime'), kind: TK.ok))
        : (diff < 0 ? Tag(t('earlyM').replaceAll('{n}', '${-diff}'), kind: TK.bad) : Tag(t('onTime'), kind: TK.ok));
    final bytes = photoBytes(photo);
    final free = staffList.where((st) => attToday(st['id']) == null).toList();
    return Dlg(
      title: '${t(isIn ? 'clockIn' : 'clockOut')} · ${staffName(staff)}',
      sub: '${t(isIn ? 'clockInBy' : 'clockOutAt')} ${isIn ? hours['clockIn'] : hours['clockOut']}',
      body: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        if (isIn && staffList.length > 1) ...[
          wrapRow([for (final st in free) PillBtn(Str(st['name']), on: staff == st['id'], onTap: () => setState(() => staff = st['id']))]),
          gap(12),
        ],
        if (isIn && isOffDay(n)) ...[Note(t('offToday'), kind: NK.warn), gap(12)],
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
          decoration: BoxDecoration(color: C.sunken, borderRadius: BorderRadius.circular(16)),
          child: Row(children: [Expanded(child: Text(fmtT(n), style: ts(40, w: w8, ls: -0.8))), timing]),
        ),
        gap(12),
        GestureDetector(
          onTap: busy ? null : _snap,
          child: AspectRatio(
            aspectRatio: 4 / 3,
            child: Container(
              decoration: BoxDecoration(color: const Color(0xFF17131F), borderRadius: BorderRadius.circular(16)),
              clipBehavior: Clip.antiAlias,
              child: bytes != null
                  ? Image.memory(bytes, fit: BoxFit.cover)
                  : Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Ic('camera', size: 40, color: Colors.white.withValues(alpha: 0.8)),
                      gap(10),
                      Text(busy ? t('camWait') : t('takePhoto'), style: ts(14, w: w7, c: Colors.white)),
                    ]),
            ),
          ),
        ),
        gap(10),
        Row(children: [
          if (bytes != null)
            Btn(t('retake'), icon: 'camera', kind: BK.sec, size: BS.sm, onTap: busy ? null : _snap)
          else
            Btn(t('takePhoto'), icon: 'camera', size: BS.sm, onTap: busy ? null : _snap),
        ]),
        if (bytes == null) ...[gap(10), Note(t('photoNeed'), kind: NK.warn)],
      ]),
      foot: [
        Btn(t('cancel'), kind: BK.sec, onTap: () => Navigator.pop(context)),
        Expanded(
          child: Btn(t(isIn ? 'confirmIn' : 'confirmOut'), icon: 'check', kind: BK.ok, size: BS.lg, full: true, onTap: photo == null
              ? null
              : () {
                  final t0 = now();
                  Map<String, dynamic>? rec;
                  if (isIn) {
                    rec = <String, dynamic>{'id': uid('a'), 'staff': staff, 'inAt': t0, 'inPhoto': photo, 'outAt': null, 'outPhoto': null};
                    att.add(rec);
                  } else {
                    rec = attToday(staff);
                    if (rec == null) return;
                    rec['outAt'] = t0;
                    rec['outPhoto'] = photo;
                  }
                  save();
                  Navigator.pop(context);
                  if (isIn) {
                    final l = lateMin(rec);
                    toast(l > 0 ? t('inLateT').replaceAll('{n}', '$l') : t('inT'), l > 0 ? 'alert' : 'check');
                  } else {
                    toast(t('outT'));
                  }
                }),
        ),
      ],
    );
  }
}

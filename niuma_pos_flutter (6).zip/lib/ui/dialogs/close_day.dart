// Close day: 1) tasks + stock count  2) cash count with expected  3) review → Close sales.
// Returns the closed shift.
import 'package:flutter/material.dart';

import '../../data/logic.dart';
import '../../data/store.dart';
import '../../data/util.dart';
import '../theme.dart';
import '../widgets.dart';

class CloseDayDialog extends StatefulWidget {
  const CloseDayDialog({super.key});
  @override
  State<CloseDayDialog> createState() => _CloseDayDialogState();
}

class _CloseDayDialogState extends State<CloseDayDialog> {
  int step = 1;
  final tasks = <String, bool>{};
  late final Map<String, String> stock = {for (final x in stockList) Str(x['id']): '1'};
  final cash = <String, dynamic>{};
  final ctl = <String, TextEditingController>{};

  TextEditingController _c(String id) => ctl.putIfAbsent(id, () => TextEditingController(text: stock[id]));

  bool get _step1Done =>
      taskList.every((x) => tasks[Str(x['id'])] == true) && stockList.every((x) => (double.tryParse(stock[Str(x['id'])] ?? '') ?? -1) >= 0);

  @override
  Widget build(BuildContext context) {
    final sh = curShift();
    if (sh == null) return const SizedBox.shrink();
    final steps = Row(children: [
      for (var n = 1; n <= 3; n++) ...[
        if (n > 1) hgap(6),
        Expanded(child: Container(height: 4, decoration: BoxDecoration(color: step >= n ? C.p : C.line, borderRadius: BorderRadius.circular(2)))),
      ]
    ]);
    late String title, sub;
    late Widget body;
    late List<Widget> foot;
    if (step == 1) {
      title = t('step1');
      sub = t('tasksSub');
      body = Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Lbl(t('tasksTodo')),
        for (final x in taskList) ...[
          _task(x),
          gap(8),
        ],
        Lbl('${t('stockLeft')} (${t('stockHint')})'),
        for (final x in stockList) _stockRow(x),
        if (!_step1Done) ...[gap(14), Note(t('fillAll'), kind: NK.warn)],
      ]);
      foot = [
        Btn(t('cancel'), kind: BK.sec, onTap: () => Navigator.pop(context)),
        Expanded(child: Btn(t('next'), size: BS.lg, full: true, onTap: _step1Done ? () => setState(() => step = 2) : null)),
      ];
    } else if (step == 2) {
      title = t('step2');
      sub = t('countCashSub');
      body = Column(children: [
        DenGrid(counts: cash, onChanged: () => setState(() {}), expected: expCash(sh)),
        gap(12),
        Note(sh['tngOpenedAt'] != null ? t('tngLaterClose') : t('tngNotOpenedClose'), icon: 'wallet'),
      ]);
      foot = [
        Btn(t('back'), kind: BK.sec, onTap: () => setState(() => step = 1)),
        Expanded(child: Btn(t('next'), size: BS.lg, full: true, onTap: denTotal(cash) > 0 ? () => setState(() => step = 3) : null)),
      ];
    } else {
      final cashS = shiftSales(sh, 'cash'), expC = expCash(sh), cnt = denTotal(cash);
      final un = unpaidOrders();
      final unpaidW = un.where((o) => !isDel(o)).length, unpaidD = un.where(isDel).length;
      final delRecv = orders
          .where((o) => isDel(o) && o['paid'] == true && o['status'] != 'voided' && N(o['paidAt']) >= N(sh['openedAt']))
          .fold<num>(0, (s, o) => s + oTotal(o));
      title = t('step3');
      sub = longDate(now());
      body = Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        SimpleTable(head: ['', t('cash')], rows: [
          [Text(t('opening')), Text(rm(sh['openTotal']))],
          [Text(t('cashSales')), Text(rm(cashS))],
          [Text(t('expected'), style: ts(14, w: w8)), Text(rm(expC), style: ts(14, w: w8))],
          [Text(t('counted')), Text(rm(cnt))],
          [Text(t('overShort'), style: ts(14, w: w8)), VarTxt(cnt - expC)],
        ]),
        if (sh['tngOpenedAt'] != null) ...[gap(12), Note(t('tngLaterClose'), icon: 'wallet')],
        gap(14),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(color: C.sunken, borderRadius: BorderRadius.circular(12)),
          child: Row(children: [Expanded(child: Text(t('deliveryRecv'), style: ts(14, w: w7))), Text(rm(delRecv), style: ts(15, w: w8))]),
        ),
        if (unpaidW > 0) ...[gap(12), Note(t('unpaidBlock', unpaidW), kind: NK.bad)],
        if (unpaidD > 0) ...[gap(12), Note(t('unsettledBlock', unpaidD), kind: NK.bad)],
      ]);
      foot = [
        Btn(t('back'), kind: BK.sec, onTap: () => setState(() => step = 2)),
        Expanded(
          child: un.isNotEmpty
              ? Btn(t('openOrders'), kind: BK.sec, size: BS.lg, full: true, onTap: () {
                  Navigator.pop(context);
                  S['tab'] = 'openOrders';
                  save();
                })
              : Btn(t('closeSales'), icon: 'lock', size: BS.lg, full: true, onTap: () {
                  if (!(denTotal(cash) > 0)) return;
                  sh['closedAt'] = now();
                  sh['closeCash'] = Map<String, dynamic>.from(cash);
                  sh['closeTotal'] = denTotal(cash);
                  sh['stock'] = <String, dynamic>{for (final e in stock.entries) e.key: double.tryParse(e.value) ?? 0};
                  sh['tasks'] = <String, dynamic>{for (final e in tasks.entries) e.key: e.value};
                  save();
                  Navigator.pop(context, sh);
                }),
        ),
      ];
    }
    return Dlg(
      wide: true,
      kicker: '${t('closeDay')} · $step/3',
      title: title,
      sub: sub,
      body: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [gap(4), steps, gap(6), body]),
      foot: foot,
    );
  }

  Widget _task(dynamic x) {
    final id = Str(x['id']);
    final on = tasks[id] == true;
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: () => setState(() => tasks[id] = !on),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        decoration: BoxDecoration(
            color: on ? C.okSoft : C.surface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: on ? const Color(0xFFBBE5C8) : C.line2, width: 1.5)),
        child: Row(children: [
          Container(
            width: 24, height: 24, alignment: Alignment.center,
            decoration: BoxDecoration(
                color: on ? C.ok : C.surface, borderRadius: BorderRadius.circular(7), border: Border.all(color: on ? C.ok : C.line2, width: 1.5)),
            child: on ? const Ic('check', size: 15, color: Colors.white) : null,
          ),
          hgap(12),
          Expanded(child: Text(nm(x['names']), style: ts(14.5, w: w7, c: on ? const Color(0xFF166534) : C.ink))),
        ]),
      ),
    );
  }

  Widget _stockRow(dynamic x) {
    final id = Str(x['id']);
    final zero = double.tryParse(stock[id] ?? '') == 0;
    final c = _c(id);
    void setV(double v) {
      final s = v % 1 == 0 ? v.toStringAsFixed(0) : v.toString();
      stock[id] = s;
      c.text = s;
      setState(() {});
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(color: zero ? C.badSoft : Colors.transparent, borderRadius: BorderRadius.circular(12)),
      child: Row(children: [
        Expanded(child: Text(nm(x['names']), style: ts(14.5, w: w7, c: zero ? C.bad : C.ink))),
        Container(
          height: 40,
          decoration: BoxDecoration(color: C.sunken, borderRadius: BorderRadius.circular(10)),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            InkWell(
                onTap: () {
                  final cur = double.tryParse(stock[id] ?? '') ?? 1;
                  setV(((cur - 0.5).clamp(0, 9999) * 2).round() / 2);
                },
                child: const SizedBox(width: 38, height: 40, child: Center(child: Ic('minus', size: 15, color: C.ink2)))),
            SizedBox(
              width: 56,
              child: TextField(
                controller: c,
                textAlign: TextAlign.center,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                style: ts(15, w: w8),
                decoration: const InputDecoration(
                    border: InputBorder.none, enabledBorder: InputBorder.none, focusedBorder: InputBorder.none, filled: false,
                    contentPadding: EdgeInsets.zero, isDense: true),
                onChanged: (s) => setState(() => stock[id] = s),
              ),
            ),
            InkWell(
                onTap: () {
                  final cur = double.tryParse(stock[id] ?? '') ?? 1;
                  setV(((cur + 0.5) * 2).round() / 2);
                },
                child: const SizedBox(width: 38, height: 40, child: Center(child: Ic('plus', size: 15, color: C.ink2)))),
          ]),
        ),
        hgap(10),
        SizedBox(width: 52, child: Text(Str(x['unit']), style: ts(13, w: w6, c: C.muted))),
      ]),
    );
  }
}

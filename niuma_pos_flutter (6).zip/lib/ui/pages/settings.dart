import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../../data/consts.dart';
import '../../data/store.dart';
import '../../data/util.dart';
import '../../l10n_data.dart';
import '../../services.dart';
import '../actions.dart';
import '../theme.dart';
import '../widgets.dart';
import 'kitchen.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  Future<void> _time(BuildContext context, String current, void Function(String) set) async {
    final p = current.split(':');
    final r = await showTimePicker(
        context: context,
        initialTime: TimeOfDay(hour: int.tryParse(p[0]) ?? 8, minute: p.length > 1 ? (int.tryParse(p[1]) ?? 0) : 0),
        builder: (c, child) => MediaQuery(data: MediaQuery.of(c).copyWith(alwaysUse24HourFormat: true), child: child!));
    if (r != null) {
      set('${two(r.hour)}:${two(r.minute)}');
      save();
    }
  }

  Widget _timeBox(BuildContext context, String v, void Function(String) set) => InkWell(
        onTap: () => _time(context, v, set),
        child: InputDecorator(
          decoration: const InputDecoration(),
          child: Row(children: [Expanded(child: Text(v, style: ts(15, w: w7))), const Ic('clock', size: 17, color: C.muted)]),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final email = FirebaseAuth.instance.currentUser?.email ?? '';
    Widget listEditor(String kind, List<dynamic> arr, bool withUnit) => CardBox(
          padding: EdgeInsets.zero,
          child: Column(children: [
            for (final x in arr)
              Container(
                padding: const EdgeInsets.fromLTRB(16, 10, 8, 10),
                decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: C.line))),
                child: Row(children: [
                  Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(nm(x['names']), style: ts(14.5, w: w7)),
                    if (withUnit) Text(Str(x['unit']), style: ts(12.5, c: C.muted)),
                  ])),
                  IconBtn('trash', onTap: () {
                    arr.removeWhere((y) => y['id'] == x['id']);
                    save();
                  }),
                ]),
              ),
            _AddRow(kind: kind, withUnit: withUnit),
          ]),
        );
    final open = L(hours['open']);
    final offTue = L(hours['offTue']).map(I).toList();
    return Align(
      alignment: Alignment.topLeft,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 860),
        child: ListView(padding: pagePad(context), children: [
          Section(
            title: t('language'),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Seg<String>(
                items: [for (final e in kLangs.entries) (e.key, e.value)],
                value: lang,
                onChanged: (v) {
                  S['lang'] = v;
                  save();
                },
              ),
            ),
          ),
          Section(
            title: t('testOrder'),
            sub: t('testOrderSub'),
            trailing: Btn(t('testBtn'), icon: 'bell', kind: BK.soft, onTap: () => testOrder(context)),
            child: const SizedBox.shrink(),
          ),
          Section(
            title: t('hoursTitle'),
            child: CardBox(
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Row(children: [
                  Expanded(child: FieldBox(t('clockInBy'), _timeBox(context, Str(hours['clockIn']), (v) => hours['clockIn'] = v))),
                  hgap(14),
                  Expanded(child: FieldBox(t('clockOutAt'), _timeBox(context, Str(hours['clockOut']), (v) => hours['clockOut'] = v))),
                ]),
                Lbl(t('opHours')),
                for (var i = 0; i < open.length; i++)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(children: [
                      Expanded(child: _timeBox(context, Str(open[i][0]), (v) => open[i][0] = v)),
                      Padding(padding: const EdgeInsets.symmetric(horizontal: 8), child: Text('–', style: ts(15, c: C.muted))),
                      Expanded(child: _timeBox(context, Str(open[i][1]), (v) => open[i][1] = v)),
                    ]),
                  ),
                Lbl(t('offTueLbl')),
                wrapRow([
                  for (final w in [1, 2, 3, 4, 5])
                    PillBtn(t('wk$w'), on: offTue.contains(w), onTap: () {
                      final l = offTue.contains(w) ? offTue.where((x) => x != w).toList() : ([...offTue, w]..sort());
                      hours['offTue'] = l;
                      save();
                    }),
                ]),
              ]),
            ),
          ),
          Section(
            title: t('staffTitle'),
            child: CardBox(
              padding: EdgeInsets.zero,
              child: Column(children: [
                for (final st in staffList)
                  Container(
                    padding: const EdgeInsets.fromLTRB(16, 10, 8, 10),
                    decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: C.line))),
                    child: Row(children: [
                      Expanded(
                          child: Inp(
                              key: ValueKey('st${st['id']}'),
                              value: Str(st['name']),
                              small: true,
                              onChanged: (v) {
                                st['name'] = v;
                                save();
                              })),
                      if (staffList.length > 1)
                        IconBtn('trash', onTap: () {
                          staffList.removeWhere((x) => x['id'] == st['id']);
                          save();
                        }),
                    ]),
                  ),
                const _AddRow(kind: 'staff', withUnit: false),
              ]),
            ),
          ),
          Section(
            title: t('tgTitle'),
            sub: t('tgSub'),
            child: CardBox(
              child: Row(children: [
                Expanded(child: Text('Telegram · ${Str(tg['phone'])}', style: ts(14.5, w: w7))),
                Btn(t('tgTest'), icon: 'bell', kind: BK.tg, size: BS.sm, onTap: () async {
                  final e = await sendTelegram(t('tgTestMsg'));
                  toast(e == null ? t('tgSentOk') : '${t('tgFailed')} ($e)', e == null ? 'check' : 'alert');
                }),
              ]),
            ),
          ),
          Section(title: t('dailyTasks'), child: listEditor('tasks', taskList, false)),
          Section(title: t('stockItems'), child: listEditor('stock', stockList, true)),
          Section(
            title: t('deliveryPlatforms'),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              CardBox(
                padding: EdgeInsets.zero,
                child: Column(children: [
                  for (final c in kDelivery)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: C.line))),
                      child: Row(children: [
                        Container(
                            width: 42, height: 42, alignment: Alignment.center,
                            decoration: BoxDecoration(color: kCh[c], borderRadius: BorderRadius.circular(12)),
                            child: const Ic('scooter', color: Colors.white)),
                        hgap(12),
                        Expanded(child: Text(t('ch_$c'), style: ts(14.5, w: w7))),
                        Text(t('prepTime'), style: ts(13, w: w7, c: C.muted)),
                        hgap(8),
                        Inp(
                            key: ValueKey('prep$c'),
                            value: '${Mp(S['prep'])[c] ?? 15}',
                            number: true,
                            small: true,
                            width: 72,
                            align: TextAlign.right,
                            onChanged: (v) {
                              final n = int.tryParse(v);
                              if (n != null && n > 0) {
                                final p = Mp(S['prep']);
                                p[c] = n > 90 ? 90 : n;
                                S['prep'] = p;
                                save();
                              }
                            }),
                        hgap(6),
                        Text(t('min'), style: ts(13, w: w7, c: C.muted)),
                      ]),
                    ),
                ]),
              ),
              gap(10),
              Row(children: [
                Expanded(child: Text(t('prepHint'), style: ts(13.5, c: C.muted))),
                Btn(t('testAlarm'), icon: 'bell', kind: BK.soft, size: BS.sm, onTap: testAlarm),
              ]),
              gap(12),
              Note(t('integrationNote')),
            ]),
          ),
          Section(
            title: t('syncTitle'),
            sub: t('syncHelp'),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Note(
                  '${t('sync_${store.state}')}${store.state == 'local' || store.state == 'ro' ? ' · ${t('syncFix_${store.state}')}' : ''}',
                  kind: store.state == 'ok' ? NK.ok : NK.warn),
              gap(12),
              Row(children: [
                Expanded(child: Text(email, style: ts(13.5, c: C.muted))),
                Btn('Sign out', kind: BK.sec, size: BS.sm, onTap: () async {
                  await store.stop();
                  await FirebaseAuth.instance.signOut();
                }),
              ]),
              gap(10),
              Text('Niuma POS v4.0 (Flutter)', style: ts(13, c: C.muted)),
            ]),
          ),
        ]),
      ),
    );
  }
}

class _AddRow extends StatefulWidget {
  final String kind;
  final bool withUnit;
  const _AddRow({required this.kind, required this.withUnit});
  @override
  State<_AddRow> createState() => _AddRowState();
}

class _AddRowState extends State<_AddRow> {
  final name = TextEditingController();
  final unit = TextEditingController();
  void _add() {
    final v = name.text.trim();
    if (v.isEmpty) return;
    if (widget.kind == 'staff') {
      staffList.add(<String, dynamic>{'id': uid('st'), 'name': v});
    } else {
      final x = <String, dynamic>{'id': uid(widget.kind[0]), 'names': <String, dynamic>{'en': v, 'zh': v, 'my': v}};
      if (widget.kind == 'stock') x['unit'] = unit.text.trim().isEmpty ? 'pcs' : unit.text.trim();
      (S[widget.kind] as List).add(x);
    }
    name.clear();
    unit.clear();
    save();
  }

  @override
  Widget build(BuildContext context) {
    final label = widget.kind == 'tasks' ? 'taskName' : (widget.kind == 'stock' ? 'stockName' : 'staffName');
    final btn = widget.kind == 'tasks' ? 'addTask' : (widget.kind == 'stock' ? 'addStock' : 'addStaff');
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Row(children: [
        Expanded(child: Inp(controller: name, hint: t(label), small: true, onSubmitted: (_) => _add())),
        if (widget.withUnit) ...[hgap(8), Inp(controller: unit, hint: t('unit'), small: true, width: 90)],
        hgap(8),
        Btn(t(btn), icon: 'plus', kind: BK.soft, size: BS.sm, onTap: _add),
      ]),
    );
  }
}

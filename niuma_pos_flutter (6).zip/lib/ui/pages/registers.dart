// Cash register, TNG register and petty cash: live boxes, changes after closing, and three paged history tables.
import 'package:flutter/material.dart';

import '../../data/logic.dart';
import '../../data/store.dart';
import '../../data/util.dart';
import '../actions.dart';
import '../theme.dart';
import '../widgets.dart';
import 'kitchen.dart';

/// Paging state (5 rows a page, back to page 1 when the tab changes).
final Map<String, int> pages = {};

class ChangeRow extends StatelessWidget {
  final dynamic c;
  const ChangeRow(this.c, {super.key});
  @override
  Widget build(BuildContext context) {
    final isNew = c['seen'] != true;
    final fx = L(c['fx']);
    final left = Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(Str(c['ref']), style: ts(14.5, w: w8)),
      gap(2),
      Text(Str(c['desc']), style: ts(14, c: C.ink2)),
      Text('${t('changedAt')} ${fmtD(N(c['at']))} ${fmtT(N(c['at']))}', style: ts(12.5, c: C.muted)),
    ]);
    final right = Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      for (final f in fx)
        Padding(
          padding: const EdgeInsets.only(bottom: 4),
          child: Wrap(spacing: 6, runSpacing: 2, crossAxisAlignment: WrapCrossAlignment.center, children: [
            Text('${t(kRegName[f['reg']] ?? '')} ${fmtD(N(f['day']))}', style: ts(13.5, w: w7)),
            Text.rich(TextSpan(children: [
              TextSpan(text: '${t('expected')} ${rm(f['from'])} → ', style: ts(13.5, c: C.muted)),
              TextSpan(text: rm(f['to']), style: ts(13.5, w: w8)),
              TextSpan(
                  text: ' (${N(f['to']) - N(f['from']) > 0 ? '+' : '−'}${rm((N(f['to']) - N(f['from'])).abs())})', style: ts(13.5, c: C.muted)),
            ])),
            if (f['cnt'] != null) ...[Text('· ${t('overShort')}', style: ts(13.5, c: C.muted)), VarTxt(r2(N(f['cnt']) - N(f['to'])), size: 13.5)],
          ]),
        ),
    ]);
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
      decoration: BoxDecoration(
        color: isNew ? const Color(0xFFFFFBF2) : null,
        border: const Border(bottom: BorderSide(color: C.line)),
      ),
      child: isNarrow(context)
          ? Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [left, gap(8), right])
          : Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(flex: 4, child: left), hgap(16), Expanded(flex: 6, child: right)]),
    );
  }
}

class RegistersPage extends StatefulWidget {
  const RegistersPage({super.key});
  @override
  State<RegistersPage> createState() => _RegistersPageState();
}

class _RegistersPageState extends State<RegistersPage> {
  @override
  void initState() {
    super.initState();
    pages.clear();
  }

  ({List<dynamic> rows, int p, int n}) _page(String k, List<dynamic> rows) {
    final n = rows.isEmpty ? 1 : (rows.length / 5).ceil();
    final p = (pages[k] ?? 0).clamp(0, n - 1);
    pages[k] = p;
    return (rows: rows.skip(p * 5).take(5).toList(), p: p, n: n);
  }

  Widget _box(String title, String ic, List<(String, String, bool)> rows, Widget? foot, {bool veg = false}) => CardBox(
        padding: const EdgeInsets.all(20),
        color: veg ? const Color(0xFFF6FBF7) : C.surface,
        border: veg ? const Color(0xFFD5EEDC) : C.line,
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [
            Container(
              width: 38, height: 38, alignment: Alignment.center,
              decoration: BoxDecoration(color: veg ? C.okSoft : C.pSoft, borderRadius: BorderRadius.circular(12)),
              child: Ic(ic, size: 20, color: veg ? C.ok : C.p),
            ),
            hgap(10),
            H2(title),
          ]),
          gap(12),
          for (final r in rows) KV.txt(r.$1, r.$2, bold: r.$3),
          if (foot != null) ...[gap(14), foot],
        ]),
      );

  Widget _table(String title, String ic, List<String> head, List<List<Widget>> rows, List<VoidCallback> taps, ({List<dynamic> rows, int p, int n}) pg,
          String key, {bool veg = false}) =>
      Section(
        titleWidget: Wrap(spacing: 10, crossAxisAlignment: WrapCrossAlignment.center, children: [
          Container(
            width: 30, height: 30, alignment: Alignment.center,
            decoration: BoxDecoration(color: veg ? C.okSoft : C.pSoft, borderRadius: BorderRadius.circular(9)),
            child: Ic(ic, size: 16, color: veg ? C.ok : C.p),
          ),
          H2(title),
          Text(t('tapRow'), style: ts(12.5, c: C.muted)),
        ]),
        child: CardBox(
          padding: const EdgeInsets.fromLTRB(16, 6, 16, 6),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            LayoutBuilder(builder: (c, k) {
              final tw = k.maxWidth < 680 ? 680.0 : k.maxWidth;
              return SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: SizedBox(
                  width: tw,
                  child: rows.isEmpty
                      ? Padding(padding: const EdgeInsets.all(12), child: Text('–', style: ts(14, c: C.muted)))
                      : SimpleTable(head: head, rows: rows, onTap: taps),
                ),
              );
            }),
            Pager(page: pg.p, pages: pg.n, onPage: (v) => setState(() => pages[key] = v)),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final sh = curShift(), ls = lastShift(), ps = curPetty();
    final cashBox = sh != null
        ? _box(t('regCash'), 'cash', [
            ('${t('opening')} ${fmtT(N(sh['openedAt']))}', rm(sh['openTotal']), false),
            (t('cashSales'), rm(shiftSales(sh, 'cash')), false),
            (t('expected'), rm(expCash(sh)), true),
          ], Btn(t('closeDay'), icon: 'lock', kind: BK.sec, full: true, onTap: () => closeDay(context)))
        : _box(t('regCash'), 'cash', [(t('status'), t('shiftClosed'), false)], Btn(t('openShift'), full: true, onTap: () => openShift(context)));
    final tsh = ls != null && ls['tngOpenedAt'] != null && ls['tngClosedAt'] == null ? ls : null;
    final tngBox = tsh != null
        ? _box(t('regTng'), 'wallet', [
            ('${t('opening')} ${fmtT(N(tsh['tngOpenedAt']))}', rm(tsh['openTng']), false),
            (t('tngSales'), rm(shiftSales(tsh, 'tng')), false),
            (t('expected'), rm(expTng(tsh) ?? 0), true),
          ], Btn(t('closeTng'), icon: 'lock', kind: BK.sec, full: true, onTap: () => closeTng(context, tsh['id'])))
        : _box(
            t('regTng'),
            'wallet',
            [(t('status'), sh != null && sh['tngOpenedAt'] == null ? t('tngNotOpened') : t('tngClosedS'), false)],
            sh != null && sh['tngOpenedAt'] == null ? Btn(t('openTng'), kind: BK.soft, full: true, onTap: () => openTng(context)) : null);
    final vegBox = ps != null
        ? _box(
            t('regVege'),
            'bag',
            [
              ('${t('opening')} ${fmtD(N(ps['openedAt']))} ${fmtT(N(ps['openedAt']))}', rm(ps['openTotal']), false),
              (t('vegeSpent'), rm(-pettySpent(ps)), false),
              (t('expected'), rm(pettyExpected(ps)), true),
            ],
            Row(children: [
              Expanded(child: Btn(t('vegeEdit'), icon: 'edit', kind: BK.sec, full: true, onTap: () => regHist(context, 'petty', ps['id']))),
              hgap(8),
              Expanded(child: Btn(t('closeVege'), icon: 'lock', kind: BK.sec, full: true, onTap: () => closePetty(context))),
            ]),
            veg: true)
        : _box(t('regVege'), 'bag', [(t('status'), t('vegeClosed'), false)], Btn(t('openVege'), full: true, onTap: () => openPetty(context)), veg: true);

    final allSh = [...shifts]..sort((a, b) => N(b['openedAt']).compareTo(N(a['openedAt'])));
    final pgC = _page('cash', allSh);
    final pgT = _page('tng', allSh.where((h) => h['tngOpenedAt'] != null).toList());
    final pgP = _page('petty', [...petty]..sort((a, b) => N(b['openedAt']).compareTo(N(a['openedAt']))));
    Widget dateCell(String top, String sub) =>
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(top, style: ts(14, w: w8)), Text(sub, style: ts(12, c: C.muted))]);
    const chev = Ic('chev', size: 15, color: C.muted);
    final flipChev = Transform.flip(flipX: true, child: chev);

    final cashRows = [
      for (final h in pgC.rows)
        [
          dateCell(fmtD(N(h['openedAt'])), '${fmtT(N(h['openedAt']))}–${h['closedAt'] != null ? fmtT(N(h['closedAt'])) : t('open')}'),
          Text(rm(h['openTotal'])),
          Text(rm(shiftSales(h, 'cash'))),
          Text(cashSpent(h) != 0 ? rm(-cashSpent(h)) : '–'),
          Text(rm(expCash(h)), style: ts(14, w: w8)),
          Text(h['closedAt'] != null ? rm(h['closeTotal']) : '–'),
          VarTxt(h['closedAt'] != null ? N(h['closeTotal']) - expCash(h) : null, size: 14),
          flipChev,
        ]
    ];
    final tngRows = [
      for (final h in pgT.rows)
        [
          dateCell(fmtD(N(h['openedAt'])), '${fmtT(N(h['tngOpenedAt']))}–${h['tngClosedAt'] != null ? fmtT(N(h['tngClosedAt'])) : t('open')}'),
          Text(rm(h['openTng'])),
          Text(rm(shiftSales(h, 'tng'))),
          Text(tngSpent(h) != 0 ? rm(-tngSpent(h)) : '–'),
          Text(rm(expTng(h) ?? 0), style: ts(14, w: w8)),
          h['tngClosedAt'] != null
              ? Text(rm(h['closeTng']))
              : (h['closedAt'] != null ? LinkBtn(t('closeTng'), onTap: () => closeTng(context, h['id'])) : const Text('–')),
          VarTxt(h['tngClosedAt'] != null ? N(h['closeTng']) - (expTng(h) ?? 0) : null, size: 14),
          flipChev,
        ]
    ];
    final pRows = [
      for (final p in pgP.rows)
        [
          dateCell('${fmtD(N(p['openedAt']))} ${fmtT(N(p['openedAt']))}', p['closedAt'] != null ? '→ ${fmtD(N(p['closedAt']))} ${fmtT(N(p['closedAt']))}' : t('open')),
          Text(rm(p['openTotal'])),
          Text('${rm(-pettySpent(p))} · ${pettyItems(p).length} ${t('items')}'),
          Text(rm(pettyExpected(p)), style: ts(14, w: w8)),
          Text(p['closedAt'] != null ? rm(p['closeTotal']) : '–'),
          VarTxt(p['closedAt'] != null ? N(p['closeTotal']) - pettyExpected(p) : null, size: 14),
          flipChev,
        ]
    ];
    final chs = changes.take(40).toList();
    final unseen = chs.where((c) => c['seen'] != true).length;
    final w = MediaQuery.sizeOf(context).width;
    return ListView(padding: pagePad(context), children: [
      LayoutBuilder(builder: (c, k) {
        final cols = w < 900 ? 1 : 3;
        final bw = (k.maxWidth - (cols - 1) * 14) / cols;
        return Wrap(spacing: 14, runSpacing: 14, children: [for (final b in [cashBox, tngBox, vegBox]) SizedBox(width: bw, child: b)]);
      }),
      gap(14),
      Note(t('regLiveNote')),
      gap(26),
      Section(
        titleWidget: Wrap(spacing: 10, crossAxisAlignment: WrapCrossAlignment.center, children: [
          Container(
            width: 30, height: 30, alignment: Alignment.center,
            decoration: BoxDecoration(color: C.warnSoft, borderRadius: BorderRadius.circular(9)),
            child: const Ic('alert', size: 16, color: C.warn),
          ),
          H2(t('changesTitle')),
          if (unseen > 0) Tag('$unseen ${t('newTag')}', kind: TK.warn),
        ]),
        trailing: unseen > 0
            ? Btn(t('markSeen'), icon: 'check', kind: BK.sec, size: BS.sm, onTap: () {
                for (final c in changes) {
                  c['seen'] = true;
                }
                save();
              })
            : null,
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Note(t('changesNote')),
          gap(10),
          CardBox(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 4),
            child: chs.isEmpty
                ? Padding(padding: const EdgeInsets.symmetric(vertical: 16), child: Text(t('noChanges'), style: ts(14, c: C.muted)))
                : Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: chs.map((c) => ChangeRow(c)).toList()),
          ),
        ]),
      ),
      _table(t('regCash'), 'cash', [t('date'), t('opening'), t('cashSales'), t('paidOut'), t('expected'), t('counted'), t('overShort'), ''], cashRows,
          [for (final h in pgC.rows) () => regHist(context, 'cash', h['id'])], pgC, 'cash'),
      _table(t('regTng'), 'wallet', [t('date'), t('opening'), t('tngSales'), t('paidOut'), t('expected'), t('counted'), t('overShort'), ''], tngRows,
          [for (final h in pgT.rows) () => regHist(context, 'tng', h['id'])], pgT, 'tng'),
      _table(t('regVege'), 'bag', [t('date'), t('opening'), t('vegeSpent'), t('expected'), t('counted'), t('overShort'), ''], pRows,
          [for (final p in pgP.rows) () => regHist(context, 'petty', p['id'])], pgP, 'petty', veg: true),
    ]);
  }
}

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

import '../../data/consts.dart';
import '../../data/logic.dart';
import '../../data/store.dart';
import '../../data/util.dart';
import '../../services.dart';
import '../actions.dart';
import '../theme.dart';
import '../widgets.dart';
import 'kitchen.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});
  @override
  Widget build(BuildContext context) {
    final rb = rangeBounds();
    final a = rb[0], b = rb[1], days = rb[2];
    final os = orders.where((o) => o['status'] != 'voided' && N(o['t']) >= a && N(o['t']) < b).toList();
    final sales = os.fold<num>(0, (s, o) => s + oCollected(o));
    final pend = os.where((o) => o['paid'] != true).fold<num>(0, (s, o) => s + oTotal(o));
    final fees = os.fold<num>(0, (s, o) => s + oFee(o));
    final disc = os.fold<num>(0, (s, o) => s + oDiscount(o));
    final discN = os.where((o) => oDiscount(o) > 0.001).length;
    final inRange = expenses.where((e) {
      final d = dayStart(isoMs(Str(e['date'])));
      return d >= a && d < b;
    }).toList();
    final otherInc = inRange.where((e) => e['cat'] == 'income').fold<num>(0, (s, e) => s + N(e['amount']));
    final exp = inRange.where((e) => e['cat'] != 'income').fold<num>(0, (s, e) => s + N(e['amount']));
    final profit = sales + otherInc - exp;
    final byCh = <String, num>{for (final c in kChs) c: 0};
    final byPay = <String, num>{};
    final qty = <String, num>{};
    final names = <String, dynamic>{};
    for (final o in os) {
      byCh[Str(o['ch'])] = (byCh[Str(o['ch'])] ?? 0) + oTotal(o);
      final p = o['paid'] == true ? Str(o['pay']) : 'unpaid';
      byPay[p] = (byPay[p] ?? 0) + oTotal(o);
      for (final l in L(o['lines'])) {
        qty[Str(l['id'])] = (qty[Str(l['id'])] ?? 0) + N(l['qty']);
        names[Str(l['id'])] = l['names'];
      }
    }
    final top = qty.entries.toList()..sort((x, y) => y.value.compareTo(x.value));
    final top5 = top.take(5).toList();
    final narrow = isNarrow(context);
    final w = MediaQuery.sizeOf(context).width;

    // out-of-stock reminder from the latest close
    final closes = shifts.where((x) => x['closedAt'] != null && x['stock'] != null).toList()..sort((x, y) => N(y['closedAt']).compareTo(N(x['closedAt'])));
    final lastClose = closes.isNotEmpty ? closes.first : null;
    final outItems = lastClose == null
        ? <dynamic>[]
        : stockList
            .where((x) => Mp(lastClose['stock'])[x['id']] != null && D(Mp(lastClose['stock'])[x['id']]) == 0 && Mp(lastClose['restocked'])[x['id']] != true)
            .toList();

    Widget kpi(String ic, String l, String v, String? h, {bool main = false, Color? vc}) => Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          decoration: BoxDecoration(color: main ? C.p : C.surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: main ? C.p : C.line)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Ic(ic, size: 16, color: main ? const Color(0xFFDCCDFB) : C.muted),
              hgap(7),
              Expanded(child: Text(l, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(13, w: w7, c: main ? const Color(0xFFDCCDFB) : C.muted))),
            ]),
            gap(10),
            FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(v, style: ts(24, w: w8, ls: -0.5, c: main ? Colors.white : (vc ?? C.ink)))),
            if (h != null && h.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text(h, maxLines: 2, style: ts(12, w: w6, c: main ? const Color(0xFFDCCDFB) : C.muted))),
          ]),
        );
    final kpis = [
      kpi('trend', t('salesRecv'), rm(sales), pend > 0 ? t('pendingHint').replaceAll('{x}', rm(pend)) : '', main: true),
      kpi('receipt', t('ordersCount'), '${os.length}', '${t('avgOrder')} ${rm(os.isNotEmpty ? (sales + pend) / os.length : 0)}'),
      kpi('tag', t('discounts'), rm(disc), t('discHint', discN), vc: disc > 0 ? C.warn : null),
      kpi('scooter', t('platformFee'), rm(fees), t('feeHint'), vc: fees > 0 ? C.warn : null),
      kpi('camera', t('expensesK'), rm(exp), null),
      kpi('wallet', t('profit'), rm(profit), otherInc > 0 ? t('incomeIncl').replaceAll('{x}', rm(otherInc)) : t('profitHint'), vc: profit >= 0 ? C.ok : C.bad),
    ];
    final kpiCols = narrow ? 2 : (w < 1280 ? 3 : 6);

    final presets = [('today', 'today'), ('yesterday', 'yesterday'), ('week', 'thisWeek'), ('month', 'thisMonth')];
    final range = Mp(S['range']);
    final pickMs = range['preset'] == 'date' ? isoMs(Str(range['date'])) : (range['preset'] == 'yesterday' ? now() - kDay : now());

    Widget panel(String title, Widget child) =>
        CardBox(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [H2(title), gap(16), child]));
    Widget legend(Map<String, num> m, Color Function(String) col, String Function(String) label) {
      final e = m.entries.where((x) => x.value > 0).toList()..sort((x, y) => y.value.compareTo(x.value));
      return Column(children: [
        for (var i = 0; i < e.length; i++)
          Container(
            padding: const EdgeInsets.symmetric(vertical: 7),
            decoration: BoxDecoration(border: i == e.length - 1 ? null : const Border(bottom: BorderSide(color: C.line))),
            child: Row(children: [
              Container(width: 10, height: 10, decoration: BoxDecoration(color: col(e[i].key), borderRadius: BorderRadius.circular(3))),
              hgap(10),
              Expanded(child: Text(label(e[i].key), style: ts(14, w: w6, c: C.ink2))),
              Text(rm(e[i].value), style: ts(14, w: w7)),
            ]),
          ),
      ]);
    }

    Widget donut(Map<String, num> m, Color Function(String) col) {
      final e = m.entries.where((x) => x.value > 0).toList()..sort((x, y) => y.value.compareTo(x.value));
      return SizedBox(
        width: 150,
        height: 150,
        child: PieChart(PieChartData(
          sectionsSpace: 2,
          centerSpaceRadius: 48,
          sections: [for (final x in e) PieChartSectionData(value: x.value.toDouble(), color: col(x.key), radius: 24, showTitle: false)],
        )),
      );
    }

    // sales chart: by hour (one day) or by day
    List<String> labels;
    List<double> data;
    if (days == 1) {
      final h = List<double>.filled(24, 0);
      for (final o in os) {
        h[dt(N(o['t'])).hour] += oTotal(o).toDouble();
      }
      final hrs = List<int>.generate(15, (i) => i + 7);
      labels = hrs.map((x) => '$x:00').toList();
      data = hrs.map((x) => h[x]).toList();
    } else {
      final ds = List<int>.generate(days, (i) => a + i * kDay);
      labels = ds.map(fmtD).toList();
      data = ds.map((d) => os.where((o) => sameDay(N(o['t']), d)).fold<num>(0, (s, o) => s + oTotal(o)).toDouble()).toList();
    }
    final maxY = data.fold<double>(0, (m, v) => v > m ? v : m);
    final step = (labels.length / 8).ceil().clamp(1, 99);
    final bar = SizedBox(
      height: 230,
      child: BarChart(BarChartData(
        maxY: maxY <= 0 ? 10 : maxY * 1.15,
        alignment: BarChartAlignment.spaceAround,
        borderData: FlBorderData(show: false),
        gridData: FlGridData(show: true, drawVerticalLine: false, getDrawingHorizontalLine: (_) => const FlLine(color: Color(0xFFF0EFF4), strokeWidth: 1)),
        titlesData: FlTitlesData(
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          leftTitles: AxisTitles(
              sideTitles: SideTitles(
                  showTitles: true,
                  reservedSize: 44,
                  getTitlesWidget: (v, meta) => Text(v.toStringAsFixed(0), style: ts(11, w: w6, c: C.muted)))),
          bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                  showTitles: true,
                  reservedSize: 26,
                  getTitlesWidget: (v, meta) {
                    final i = v.toInt();
                    if (i < 0 || i >= labels.length || i % step != 0) return const SizedBox.shrink();
                    return Padding(padding: const EdgeInsets.only(top: 6), child: Text(labels[i], style: ts(11, w: w6, c: C.muted)));
                  })),
        ),
        barTouchData: BarTouchData(
          touchTooltipData: BarTouchTooltipData(
            getTooltipColor: (_) => C.ink,
            getTooltipItem: (g, gi, rod, ri) => BarTooltipItem('${labels[g.x]}\n${rm(rod.toY)}', ts(12.5, w: w7, c: Colors.white)),
          ),
        ),
        barGroups: [
          for (var i = 0; i < data.length; i++)
            BarChartGroupData(x: i, barRods: [
              BarChartRodData(toY: data[i], color: C.p, width: days > 20 ? 8 : 20, borderRadius: const BorderRadius.vertical(top: Radius.circular(6))),
            ]),
        ],
      )),
    );

    Color payCol(String k) => kPayCol[k] ?? const Color(0xFFCBD5E1);
    Color chCol(String k) => kCh[k] ?? const Color(0xFFCBD5E1);

    // register summary (single day)
    Widget? reg;
    if (days == 1) {
      final dayShifts = shifts.where((s) => sameDay(N(s['openedAt']), a)).toList();
      if (dayShifts.isNotEmpty) {
        final sh = dayShifts.last;
        final ec = expCash(sh), et = expTng(sh);
        final closed = sh['closedAt'] != null;
        reg = Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          ExpBox([
            ('${t('opening')} (${t('cash')})', Text(rm(sh['openTotal']), style: ts(17, w: w8))),
            ('${t('expected')} (${t('cash')})', Text(rm(ec), style: ts(17, w: w8))),
            ('${t('counted')} (${t('cash')})', Text(closed ? rm(sh['closeTotal']) : '–', style: ts(17, w: w8))),
            ('${t('overShort')} (${t('cash')})', VarTxt(closed ? N(sh['closeTotal']) - ec : null, size: 17)),
            ('${t('expected')} (${t('tng')})', Text(et == null ? t('tngNotOpened') : rm(et), style: ts(17, w: w8))),
            ('${t('overShort')} (${t('tng')})', VarTxt(sh['tngClosedAt'] != null && et != null ? N(sh['closeTng']) - et : null, size: 17)),
          ]),
          if (sh['stock'] != null) ...[
            Lbl(t('stockReport')),
            Wrap(spacing: 14, runSpacing: 6, children: [
              for (final s in stockList)
                Text.rich(TextSpan(children: [
                  TextSpan(text: '${nm(s['names'])}: ', style: ts(13.5, c: C.muted)),
                  TextSpan(
                      text: Mp(sh['stock'])[s['id']] == null ? '–' : _qty(Mp(sh['stock'])[s['id']]),
                      style: ts(13.5, w: w8, c: D(Mp(sh['stock'])[s['id']]) == 0 && Mp(sh['stock'])[s['id']] != null ? C.bad : C.ink)),
                  TextSpan(text: ' ${s['unit']}', style: ts(13.5, c: C.muted)),
                ])),
            ]),
          ],
        ]);
      } else {
        reg = Padding(padding: const EdgeInsets.symmetric(vertical: 20), child: Text(t('noShift'), style: ts(14, w: w6, c: C.muted)));
      }
    }

    final recent = orders.where((o) => N(o['t']) >= a && N(o['t']) < b).toList().reversed.toList();
    final panels = <Widget>[
      _span(narrow || w < 1180 ? 12 : 8, panel(t(days == 1 ? 'salesByHour' : 'salesByDay'), bar)),
      _span(narrow || w < 1180 ? 12 : 4,
          panel(t('byPayment'), os.isEmpty ? Text(t('noData'), style: ts(14, c: C.muted)) : Column(children: [donut(byPay, payCol), gap(10), legend(byPay, payCol, (k) => k == 'unpaid' ? t('pendingPay') : t('pay_$k'))]))),
      _span(narrow || w < 1180 ? 12 : 6,
          panel(t('byChannel'), os.isEmpty ? Text(t('noData'), style: ts(14, c: C.muted)) : Wrap(spacing: 20, runSpacing: 12, crossAxisAlignment: WrapCrossAlignment.center, children: [donut(byCh, chCol), SizedBox(width: narrow ? double.infinity : 260, child: legend(byCh, chCol, (k) => t('ch_$k')))]))),
      _span(
          narrow || w < 1180 ? 12 : 6,
          panel(
              t('topItems'),
              top5.isEmpty
                  ? Text(t('noData'), style: ts(14, c: C.muted))
                  : Column(children: [
                      for (final e in top5)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          child: Row(children: [
                            Pic(item(e.key) ?? {'names': names[e.key]}, w: 40, h: 40, mono: 18),
                            hgap(12),
                            Expanded(child: Text(nm(names[e.key]), maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14, w: w7))),
                            SizedBox(
                              width: 110,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(4),
                                child: LinearProgressIndicator(value: e.value / top5.first.value, minHeight: 8, backgroundColor: C.sunken, color: C.p),
                              ),
                            ),
                            SizedBox(width: 36, child: Text('${e.value}', textAlign: TextAlign.right, style: ts(14, w: w8))),
                          ]),
                        ),
                    ]))),
      if (reg != null) _span(12, panel(t('register'), reg)),
      _span(
        12,
        CardBox(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 6),
              child: Wrap(alignment: WrapAlignment.spaceBetween, spacing: 12, runSpacing: 4, children: [
                Text.rich(TextSpan(children: [
                  TextSpan(text: t('recentOrders'), style: ts(16, w: w8)),
                  if (days == 1) TextSpan(text: '  ${longDate(a)}', style: ts(14, w: w7, c: C.muted)),
                ])),
                Text(t('tapToEdit'), style: ts(13.5, c: C.muted)),
              ]),
            ),
            if (recent.isEmpty) Padding(padding: const EdgeInsets.all(16), child: Text(t('noData'), style: ts(14, c: C.muted))),
            for (final o in recent) _recentRow(context, o, days),
          ]),
        ),
      ),
    ];

    return ListView(padding: pagePad(context), children: [
      if (curShift() == null && !todayClosed() && !isOffDay(now())) ...[
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: C.pSoft, borderRadius: BorderRadius.circular(18), border: Border.all(color: C.pLine)),
          child: Row(children: [
            const Ic('cash', color: C.p),
            hgap(12),
            Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t('shiftNotOpen'), style: ts(15, w: w8)),
              Sub(clockedIn() ? t('shiftNotOpenSub') : t('clockFirst')),
            ])),
            hgap(10),
            Btn(t(clockedIn() ? 'openShift' : 'clockIn'), onTap: () => clockedIn() ? openShift(context) : clockIn(context)),
          ]),
        ),
        gap(14),
      ],
      if (outItems.isNotEmpty) ...[
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: C.badSoft, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFF4C7C7))),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Ic('alert', color: C.bad),
            hgap(10),
            Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t('outTitle'), style: ts(15, w: w8, c: const Color(0xFF991B1B))),
              Padding(
                padding: const EdgeInsets.only(top: 2, bottom: 10),
                child: Text(t('outSub').replaceAll('{x}', '${fmtD(N(lastClose!['closedAt']))} ${fmtT(N(lastClose['closedAt']))}'), style: ts(13.5, c: const Color(0xFF991B1B))),
              ),
              wrapRow([
                for (final x in outItems)
                  Container(
                    padding: const EdgeInsets.fromLTRB(12, 4, 4, 4),
                    decoration: BoxDecoration(color: C.surface, borderRadius: BorderRadius.circular(999), border: Border.all(color: const Color(0xFFF4C7C7))),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Text('${nm(x['names'])} · 0 ${x['unit']}', style: ts(13, w: w7, c: C.bad)),
                      hgap(8),
                      Btn(t('restocked'), icon: 'check', kind: BK.sec, size: BS.sm, onTap: () {
                        lastClose['restocked'] = <String, dynamic>{...Mp(lastClose['restocked']), Str(x['id']): true};
                        save();
                      }),
                    ]),
                  ),
                Btn(t('tgSendBot'), icon: 'bell', kind: BK.tg, size: BS.sm, onTap: () async {
                  final e = await sendTelegram(oosText(lastClose, outItems));
                  toast(e == null ? t('tgSentOk') : '${t('tgFailed')} ($e)', e == null ? 'check' : 'alert');
                }),
                if (outItems.length > 1)
                  Btn(t('restockedAll'), icon: 'check', kind: BK.danger, size: BS.sm, onTap: () {
                    lastClose['restocked'] = <String, dynamic>{for (final s in stockList) Str(s['id']): true};
                    save();
                  }),
              ]),
            ])),
          ]),
        ),
        gap(14),
      ],
      wrapRow([
        for (final p in presets)
          PillBtn(t(p.$2), on: range['preset'] == p.$1, onTap: () {
            S['range'] = <String, dynamic>{'preset': p.$1, 'date': ''};
            save();
          }),
        PillBtn(fmtD(pickMs), icon: 'calendar', on: range['preset'] == 'date', onTap: () => _calendar(context)),
        Text(days == 1 ? longDate(a) : '${fmtD(a)} – ${fmtD(b - kDay)}', style: ts(13.5, w: w6, c: C.muted)),
      ]),
      gap(20),
      LayoutBuilder(builder: (c, k) {
        final cw = (k.maxWidth - (kpiCols - 1) * 12) / kpiCols;
        return Wrap(spacing: 12, runSpacing: 12, children: [for (final x in kpis) SizedBox(width: cw, child: x)]);
      }),
      gap(14),
      LayoutBuilder(builder: (c, k) {
        final unit = (k.maxWidth - 11 * 14) / 12;
        return Wrap(spacing: 14, runSpacing: 14, children: [
          for (final p in panels)
            if (p is _Span) SizedBox(width: unit * p.span + 14 * (p.span - 1), child: p.child) else p,
        ]);
      }),
    ]);
  }

  static String _qty(dynamic v) {
    final n = N(v);
    return n % 1 == 0 ? n.toInt().toString() : n.toString();
  }

  Widget _span(int s, Widget c) => _Span(s, c);

  Widget _recentRow(BuildContext context, dynamic o, int days) {
    final voided = o['status'] == 'voided';
    final tag = voided
        ? Tag(t('voided'))
        : o['paid'] == true
            ? Tag(o['pay'] == 'platform' ? t('ch_${o['ch']}') : t('pay_${o['pay']}'), kind: TK.ok)
            : Tag(t(isDel(o) ? 'pendingPay' : 'unpaid'), kind: TK.warn);
    return InkWell(
      onTap: () => viewOrder(context, o['id']),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: const BoxDecoration(border: Border(top: BorderSide(color: C.line))),
        child: Row(children: [
          NoBox('${o['n']}', kCh[o['ch']] ?? C.p, size: 42),
          hgap(12),
          Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(orderCodes(o), maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(14.5, w: w8, ls: 0.3)),
            Row(children: [
              Flexible(
                  child: Text('${days == 1 ? '' : '${fmtD(N(o['t']))} '}${fmtT(N(o['t']))} · ${Str(o['tag']).isNotEmpty ? o['tag'] : t('ch_${o['ch']}')}',
                      overflow: TextOverflow.ellipsis, style: ts(12.5, c: C.muted))),
              if (isDel(o)) ...[hgap(6), Tag(t('deliveryLabel'), kind: TK.del)],
            ]),
          ])),
          hgap(8),
          tag,
          SizedBox(
            width: 96,
            child: Text(rm(oTotal(o)),
                textAlign: TextAlign.right,
                style: ts(14.5, w: w8, c: voided ? C.muted : C.ink).copyWith(decoration: voided ? TextDecoration.lineThrough : null)),
          ),
        ]),
      ),
    );
  }

  Future<void> _calendar(BuildContext context) async {
    final range = Mp(S['range']);
    final sel = range['preset'] == 'date' ? dt(isoMs(Str(range['date']))) : DateTime.now();
    var y = sel.year, m = sel.month;
    final has = orders.where((o) => o['status'] != 'voided').map((o) => isoDate(N(o['t']))).toSet();
    await showDlg(context, (c) {
      return StatefulBuilder(builder: (c, set) {
        final first = DateTime(y, m, 1);
        final dim = DateTime(y, m + 1, 0).day;
        final lead = first.weekday - 1;
        final today = isoDate(now());
        final selIso = range['preset'] == 'date' ? Str(range['date']) : (range['preset'] == 'today' ? today : '');
        final n = DateTime.now();
        final atMax = y > n.year || (y == n.year && m >= n.month);
        void pick(String iso) {
          S['range'] = iso == today ? <String, dynamic>{'preset': 'today', 'date': ''} : <String, dynamic>{'preset': 'date', 'date': iso};
          save();
          Navigator.pop(c);
        }

        return Dlg(
          width: 380,
          closeBtn: false,
          header: Padding(
            padding: const EdgeInsets.fromLTRB(14, 16, 14, 8),
            child: Row(children: [
              IconBtn('chev', onTap: () => set(() {
                    m--;
                    if (m < 1) {
                      m = 12;
                      y--;
                    }
                  })),
              Expanded(child: Text(monthName('$y-${two(m)}'), textAlign: TextAlign.center, style: ts(17, w: w8))),
              Opacity(
                opacity: atMax ? 0.3 : 1,
                child: Transform.flip(
                    flipX: true,
                    child: IconBtn('chev',
                        onTap: atMax
                            ? null
                            : () => set(() {
                                  m++;
                                  if (m > 12) {
                                    m = 1;
                                    y++;
                                  }
                                }))),
              ),
            ]),
          ),
          body: GridView.count(
            crossAxisCount: 7,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 4,
            crossAxisSpacing: 4,
            childAspectRatio: 1.05,
            children: [
              for (var i = 0; i < 7; i++) Center(child: Text(weekdayNarrow(i), style: ts(12, w: w7, c: C.muted))),
              for (var i = 0; i < lead; i++) const SizedBox.shrink(),
              for (var d = 1; d <= dim; d++)
                Builder(builder: (_) {
                  final iso = '$y-${two(m)}-${two(d)}';
                  final fut = iso.compareTo(today) > 0;
                  final isSel = iso == selIso, isToday = iso == today;
                  return InkWell(
                    borderRadius: BorderRadius.circular(12),
                    onTap: fut ? null : () => pick(iso),
                    child: Container(
                      decoration: BoxDecoration(
                        color: isSel ? C.p : null,
                        borderRadius: BorderRadius.circular(12),
                        border: isToday && !isSel ? Border.all(color: C.pLine, width: 1.5) : null,
                      ),
                      child: Stack(alignment: Alignment.center, children: [
                        Text('$d', style: ts(14, w: w7, c: fut ? const Color(0xFFCFCBDB) : (isSel ? Colors.white : (isToday ? C.p : C.ink)))),
                        if (has.contains(iso)) Positioned(bottom: 5, child: Dot(isSel ? Colors.white : C.p, size: 4)),
                      ]),
                    ),
                  );
                }),
            ],
          ),
          foot: [
            Btn(t('cancel'), kind: BK.sec, onTap: () => Navigator.pop(c)),
            const Spacer(),
            Btn(t('today'), onTap: () => pick(today)),
          ],
        );
      });
    });
  }
}

class _Span extends StatelessWidget {
  final int span;
  final Widget child;
  const _Span(this.span, this.child);
  @override
  Widget build(BuildContext context) => child;
}

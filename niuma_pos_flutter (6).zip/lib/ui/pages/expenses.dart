// Snap receipt + monthly ledger: income, spent, net profit, by category, payments grouped by day (newest first).
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

import '../../data/consts.dart';
import '../../data/logic.dart';
import '../../data/store.dart';
import '../../data/util.dart';
import '../../services.dart';
import '../actions.dart';
import '../theme.dart';
import '../widgets.dart';
import 'kitchen.dart';

class ExpensesPage extends StatelessWidget {
  const ExpensesPage({super.key});

  List<dynamic> _month(String mk) => expenses.where((e) => Str(e['date']).startsWith(mk)).toList();

  @override
  Widget build(BuildContext context) {
    final mk = Str(S['expMonth']).isNotEmpty ? Str(S['expMonth']) : monthKey(now());
    final y = int.parse(mk.split('-')[0]), m = int.parse(mk.split('-')[1]);
    final prevKey = monthKey(DateTime(y, m - 1, 1).millisecondsSinceEpoch);
    final isCur = mk == monthKey(now());
    final cutDay = DateTime.now().day;
    final cur = _month(mk), prv = _month(prevKey);
    final inc = cur.where((e) => e['cat'] == 'income').fold<num>(0, (s, e) => s + N(e['amount']));
    final spend = cur.where((e) => e['cat'] != 'income').fold<num>(0, (s, e) => s + N(e['amount']));
    final prevSpend = prv
        .where((e) => e['cat'] != 'income' && (!isCur || (int.tryParse(Str(e['date']).substring(8, 10)) ?? 0) <= cutDay))
        .fold<num>(0, (s, e) => s + N(e['amount']));
    final diff = prevSpend > 0 ? (spend - prevSpend) / prevSpend * 100 : 0;
    final mStart = DateTime(y, m, 1).millisecondsSinceEpoch, mEnd = DateTime(y, m + 1, 1).millisecondsSinceEpoch;
    final posSales = orders.where((o) => N(o['t']) >= mStart && N(o['t']) < mEnd).fold<num>(0, (s, o) => s + oCollected(o));
    final byCat = <String, num>{};
    for (final e in cur.where((e) => e['cat'] != 'income')) {
      byCat[Str(e['cat'])] = (byCat[Str(e['cat'])] ?? 0) + N(e['amount']);
    }
    final months = [for (var i = 0; i < 6; i++) monthKey(DateTime(DateTime.now().year, DateTime.now().month - i, 1).millisecondsSinceEpoch)];
    final rows = [...cur]..sort((a, b) {
        final c = Str(b['date']).compareTo(Str(a['date']));
        return c != 0 ? c : expAt(b).compareTo(expAt(a));
      });
    final narrow = isNarrow(context);
    final w = MediaQuery.sizeOf(context).width;

    num sumCat(List<dynamic> list, String c) => list.where((e) => e['cat'] == c).fold<num>(0, (s, e) => s + N(e['amount']));
    final cats = kExpCats.where((c) => sumCat(cur, c) > 0 || sumCat(prv, c) > 0).toList();
    final maxY = cats.fold<double>(0, (mx, c) {
      final v = [sumCat(cur, c), sumCat(prv, c)].reduce((a, b) => a > b ? a : b).toDouble();
      return v > mx ? v : mx;
    });

    Widget kpi(String ic, String l, String v, Widget? h, {bool main = false, Color? vc}) => Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          decoration: BoxDecoration(color: main ? C.p : C.surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: main ? C.p : C.line)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Ic(ic, size: 16, color: main ? const Color(0xFFDCCDFB) : C.muted),
              hgap(7),
              Expanded(child: Text(l, style: ts(13, w: w7, c: main ? const Color(0xFFDCCDFB) : C.muted))),
            ]),
            gap(10),
            FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(v, style: ts(24, w: w8, ls: -0.5, c: main ? Colors.white : (vc ?? C.ink)))),
            if (h != null) Padding(padding: const EdgeInsets.only(top: 4), child: h),
          ]),
        );
    final kpis = [
      kpi('trend', t('cat_income'), rm(inc), Text(t('incomeHint'), style: ts(12, w: w6, c: C.muted)), vc: C.ok),
      kpi('receipt', t('monthTotal'), rm(spend),
          prevSpend > 0 ? Tag('${diff > 0 ? '+' : ''}${diff.toStringAsFixed(0)}% ${t(isCur ? 'vsLastSame' : 'vsLast')}', kind: diff > 0 ? TK.bad : TK.ok) : null),
      kpi('wallet', t('netLedger'), rm(posSales + inc - spend), Text(t('netLedgerHint').replaceAll('{x}', rm(posSales)), style: ts(12, w: w6, c: const Color(0xFFDCCDFB))),
          main: true),
    ];

    final chart = SizedBox(
      height: 320,
      child: cats.isEmpty
          ? Center(child: Text(t('noReceipts'), style: ts(14, c: C.muted)))
          : BarChart(BarChartData(
              maxY: maxY <= 0 ? 10 : maxY * 1.15,
              borderData: FlBorderData(show: false),
              gridData: FlGridData(show: true, drawVerticalLine: false, getDrawingHorizontalLine: (_) => const FlLine(color: Color(0xFFF0EFF4), strokeWidth: 1)),
              titlesData: FlTitlesData(
                topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                leftTitles: AxisTitles(
                    sideTitles: SideTitles(showTitles: true, reservedSize: 44, getTitlesWidget: (v, meta) => Text(v.toStringAsFixed(0), style: ts(11, w: w6, c: C.muted)))),
                bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                        showTitles: true,
                        reservedSize: 40,
                        getTitlesWidget: (v, meta) {
                          final i = v.toInt();
                          if (i < 0 || i >= cats.length) return const SizedBox.shrink();
                          return Padding(
                              padding: const EdgeInsets.only(top: 6),
                              child: Text(t('cat_${cats[i]}'), textAlign: TextAlign.center, maxLines: 2, style: ts(10.5, w: w6, c: C.muted)));
                        })),
              ),
              barTouchData: BarTouchData(
                touchTooltipData: BarTouchTooltipData(
                  getTooltipColor: (_) => C.ink,
                  getTooltipItem: (g, gi, rod, ri) => BarTooltipItem('${ri == 0 ? monthName(prevKey) : monthName(mk)}: ${rm(rod.toY)}', ts(12, w: w7, c: Colors.white)),
                ),
              ),
              barGroups: [
                for (var i = 0; i < cats.length; i++)
                  BarChartGroupData(x: i, barsSpace: 3, barRods: [
                    BarChartRodData(toY: sumCat(prv, cats[i]).toDouble(), color: const Color(0xFFE4DDF5), width: 12, borderRadius: const BorderRadius.vertical(top: Radius.circular(5))),
                    BarChartRodData(toY: sumCat(cur, cats[i]).toDouble(), color: kCatCol[cats[i]], width: 12, borderRadius: const BorderRadius.vertical(top: Radius.circular(5))),
                  ]),
              ],
            )),
    );

    final byCatList = byCat.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final legend = byCatList.isEmpty
        ? Text(t('noReceipts'), style: ts(14, c: C.muted))
        : Column(children: [
            for (var i = 0; i < byCatList.length; i++)
              Container(
                padding: const EdgeInsets.symmetric(vertical: 7),
                decoration: BoxDecoration(border: i == byCatList.length - 1 ? null : const Border(bottom: BorderSide(color: C.line))),
                child: Row(children: [
                  Container(width: 10, height: 10, decoration: BoxDecoration(color: kCatCol[byCatList[i].key], borderRadius: BorderRadius.circular(3))),
                  hgap(10),
                  Expanded(child: Text(t('cat_${byCatList[i].key}'), style: ts(14, w: w6, c: C.ink2))),
                  Text(rm(byCatList[i].value), style: ts(14, w: w7)),
                ]),
              ),
          ]);

    // list grouped by day
    final list = <Widget>[];
    String last = '';
    for (final e in rows) {
      final d = Str(e['date']);
      if (d != last) {
        last = d;
        final dayNet = rows.where((x) => x['date'] == d).fold<num>(0, (s, x) => s + (x['cat'] == 'income' ? -N(x['amount']) : N(x['amount'])));
        list.add(Container(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
          child: Row(children: [
            Expanded(child: Text(longDate(isoMs(d, '12:00')), style: ts(13.5, w: w8, c: C.ink2))),
            Text(rm(-dayNet), style: ts(13.5, w: w7, c: C.muted)),
          ]),
        ));
      }
      final ph = photoBytes(e['photo'] is String ? e['photo'] as String : null);
      final p = e['paidBy'];
      list.add(InkWell(
        onTap: () => editExpense(context, e['id']),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          decoration: const BoxDecoration(border: Border(top: BorderSide(color: C.line))),
          child: Row(children: [
            Container(
              width: 42, height: 42, alignment: Alignment.center,
              decoration: BoxDecoration(color: C.sunken, borderRadius: BorderRadius.circular(12)),
              clipBehavior: Clip.antiAlias,
              child: ph != null ? Image.memory(ph, width: 42, height: 42, fit: BoxFit.cover) : const Ic('receipt', color: C.muted),
            ),
            hgap(12),
            Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(Str(e['vendor']).isNotEmpty ? Str(e['vendor']) : t('cat_${e['cat']}'), maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14.5, w: w7)),
              Text(fmtT(expAt(e)), style: ts(12.5, c: C.muted)),
            ])),
            if (!narrow) ...[
              p != null ? Tag(t('paid_$p'), kind: p == 'petty' ? TK.ok : (p == 'card' ? TK.mute : TK.pur)) : Tag(t('payUnknown'), kind: TK.warn),
              hgap(6),
              Tag(t('cat_${e['cat']}'), color: kCatCol[e['cat']]),
            ],
            SizedBox(
              width: 100,
              child: Text(e['cat'] == 'income' ? '+${rm(e['amount'])}' : rm(-N(e['amount'])),
                  textAlign: TextAlign.right, style: ts(14.5, w: w8, c: e['cat'] == 'income' ? C.ok : C.ink)),
            ),
          ]),
        ),
      ));
    }

    return ListView(padding: pagePad(context), children: [
      Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [C.p, C.pHover], begin: Alignment.topLeft, end: Alignment.bottomRight),
          borderRadius: BorderRadius.circular(22),
        ),
        child: Flex(
          direction: narrow ? Axis.vertical : Axis.horizontal,
          crossAxisAlignment: narrow ? CrossAxisAlignment.start : CrossAxisAlignment.center,
          children: [
            Container(
              width: 56, height: 56, alignment: Alignment.center,
              decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.14), borderRadius: BorderRadius.circular(18)),
              child: const Ic('camera', size: 26, color: Colors.white),
            ),
            narrow ? gap(14) : hgap(16),
            if (narrow)
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(t('snap'), style: ts(18, w: w8, c: Colors.white)),
                Text(t('snapSub'), style: ts(13.5, c: Colors.white70)),
              ])
            else
              Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(t('snap'), style: ts(18, w: w8, c: Colors.white)),
                Text(t('snapSub'), style: ts(13.5, c: Colors.white70)),
              ])),
            narrow ? gap(14) : hgap(16),
            Wrap(spacing: 8, runSpacing: 8, children: [
              Btn(t('snapBtn'), icon: 'camera', size: BS.lg, bg: Colors.white.withValues(alpha: 0.22), onTap: () => snapReceipt(context)),
              Btn(t('addManual'), size: BS.lg, bg: Colors.white.withValues(alpha: 0.14), onTap: () => manualExpense(context)),
            ]),
          ],
        ),
      ),
      gap(26),
      Row(children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(color: C.surface, borderRadius: BorderRadius.circular(10), border: Border.all(color: C.line2, width: 1.5)),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: months.contains(mk) ? mk : months.first,
              style: ts(14, w: w7),
              items: [for (final k in months) DropdownMenuItem(value: k, child: Text(monthName(k)))],
              onChanged: (v) {
                if (v == null) return;
                S['expMonth'] = v;
                save();
              },
            ),
          ),
        ),
      ]),
      gap(14),
      LayoutBuilder(builder: (c, k) {
        final cols = narrow ? 1 : 3;
        final cw = (k.maxWidth - (cols - 1) * 12) / cols;
        return Wrap(spacing: 12, runSpacing: 12, children: [for (final x in kpis) SizedBox(width: cw, child: x)]);
      }),
      gap(14),
      if (w < 1180) ...[
        CardBox(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [H2(t('byCategory')), gap(16), legend])),
        gap(14),
        CardBox(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [H2(t('byCategory')), gap(16), chart])),
      ] else
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(flex: 4, child: CardBox(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [H2(t('byCategory')), gap(16), legend]))),
          hgap(14),
          Expanded(flex: 8, child: CardBox(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [H2(t('byCategory')), gap(16), chart]))),
        ]),
      gap(14),
      CardBox(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Padding(padding: const EdgeInsets.fromLTRB(16, 12, 16, 4), child: H2(t('receipts'))),
          ...list,
          if (rows.isEmpty) Padding(padding: const EdgeInsets.fromLTRB(16, 20, 16, 20), child: Text(t('noReceipts'), style: ts(14, c: C.muted))),
        ]),
      ),
    ]);
  }
}

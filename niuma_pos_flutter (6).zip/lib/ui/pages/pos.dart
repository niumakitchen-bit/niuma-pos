import 'package:flutter/material.dart';

import '../../data/consts.dart';
import '../../data/logic.dart';
import '../../data/store.dart';
import '../../data/util.dart';
import '../actions.dart';
import '../theme.dart';
import '../widgets.dart';

class PosPage extends StatelessWidget {
  const PosPage({super.key});
  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.sizeOf(context).width;
    final mobile = w < 700;
    final showCart = w >= 920;
    final sh = curShift();
    final ch = Str(S['channel']);
    final delCh = kDelivery.contains(ch);
    // All series on one page: Fish, Noodle, then Add-ons (add-ons are not sold on delivery apps).
    final sections = <(String, List<dynamic>, bool)>[
      (t('fishSeries'), menuList.where((m) => m['isAddon'] != true && m['series'] == 'fish').toList(), false),
      (t('noodleSeries'), menuList.where((m) => m['isAddon'] != true && m['series'] != 'fish').toList(), false),
      if (!delCh) (t('addons'), menuList.where((m) => m['isAddon'] == true).toList(), true),
    ];
    Widget grid(List<dynamic> items, bool showAdds) => LayoutBuilder(builder: (context, c) {
          final minW = showAdds ? 220.0 : (mobile ? 150.0 : 178.0);
          final cols = (c.maxWidth / minW).floor().clamp(1, 8);
          final tileW = (c.maxWidth - (cols - 1) * (showAdds ? 10 : 14)) / cols;
          return Wrap(
            spacing: showAdds ? 10 : 14,
            runSpacing: showAdds ? 10 : 14,
            children: [for (final it in items) SizedBox(width: tileW, child: _Tile(it, addon: showAdds, mobile: mobile))],
          );
        });
    final closed = todayClosed();
    final menu = ListView(
      padding: EdgeInsets.fromLTRB(mobile ? 16 : 26, mobile ? 16 : 22, mobile ? 16 : 26, 100),
      children: [
        if (sh == null) ...[
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(color: C.warnSoft, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFFCE3B6))),
            child: Row(children: [
              const Ic('lock', size: 17, color: Color(0xFF92400E)),
              hgap(12),
              Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(t(closed ? 'lockedClosed' : 'lockedTitle'), style: ts(14.5, w: w8, c: const Color(0xFF92400E))),
                Text(t(closed ? 'posClosedSub' : 'posNotOpenSub'), style: ts(13, c: const Color(0xFF92400E))),
              ])),
              if (!closed) Btn(t('openShift'), size: BS.sm, onTap: () => openShift(context)),
            ]),
          ),
          gap(16),
        ],
        if (delCh || !mobile)
          Wrap(spacing: 12, runSpacing: 10, crossAxisAlignment: WrapCrossAlignment.center, children: [
            if (delCh) Tag('${t('ch_$ch')}: ${t('delMenuHint')}', kind: TK.del, icon: 'scooter', size: 13),
            if (!mobile) Text(longDate(now()), style: ts(13.5, w: w6, c: C.muted)),
          ]),
        for (final sec in sections)
          if (sec.$2.isNotEmpty) ...[
            Padding(
              padding: const EdgeInsets.only(top: 22, bottom: 14),
              child: Text(sec.$1,
                  style: ts(20, w: w8, ls: -0.2).copyWith(
                      decoration: TextDecoration.underline, decorationThickness: 2.5, decorationColor: C.ink)),
            ),
            grid(sec.$2, sec.$3),
          ],
      ],
    );
    return Stack(children: [
      Row(children: [
        Expanded(
            child: RepaintBoundary(
                child: Sel(
                    select: () => '$lang|${S['channel']}|${curShift() != null}|${todayClosed()}|${MediaQuery.sizeOf(context).width ~/ 40}|${menuSig()}',
                    builder: (_) => menu))),
        if (showCart && sh != null)
          Container(
            width: 392,
            decoration: const BoxDecoration(color: C.surface, border: Border(left: BorderSide(color: C.line))),
            child: RepaintBoundary(child: CartPanel()), // not const: must rebuild when the cart changes
          ),
      ]),
      if ((!showCart || sh == null) && cart.isNotEmpty)
        Positioned(
          right: 16,
          bottom: 20,
          child: Material(
            color: C.p,
            elevation: 8,
            shadowColor: const Color(0x596D28D9),
            shape: const StadiumBorder(),
            child: InkWell(
              customBorder: const StadiumBorder(),
              onTap: () => showDlg(context, (c) => Dlg(title: '', body: SizedBox(height: 600, child: CartPanel(inSheet: true)))),
              child: Container(
                height: 54,
                padding: const EdgeInsets.symmetric(horizontal: 22),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  const Ic('bag', size: 17, color: Colors.white),
                  hgap(8),
                  Text('${cartCount()}  |  ${rm(cartTotal())}', style: ts(15, w: w7, c: Colors.white)),
                ]),
              ),
            ),
          ),
        ),
    ]);
  }
}

class _Tile extends StatelessWidget {
  final dynamic it;
  final bool addon, mobile;
  const _Tile(this.it, {this.addon = false, this.mobile = false});
  @override
  Widget build(BuildContext context) {
    final avail = it['available'] == true;
    final price = it['pb'] != null
        ? Text.rich(TextSpan(children: [
            TextSpan(text: '${t('small')} ', style: ts(14, w: w7, c: C.muted)),
            TextSpan(text: rm0(it['ps']), style: ts(14, w: w7)),
            TextSpan(text: ' · ${t('big')} ', style: ts(14, w: w7, c: C.muted)),
            TextSpan(text: rm0(it['pb']), style: ts(14, w: w7)),
          ]))
        : Text('${it['isAddon'] == true ? '+' : ''}${rm0(it['ps'])}', style: ts(14, w: w7));
    final content = addon
        ? Padding(
            padding: const EdgeInsets.all(10),
            child: Row(children: [
              Pic(it, w: 56, h: 56, radius: 12, mono: 26),
              hgap(12),
              Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(nm(it['names']), style: ts(15, w: w7, h: 1.3)),
                gap(2),
                avail ? price : Text(t('soldOut'), style: ts(14, w: w7, c: C.muted)),
              ])),
            ]),
          )
        : Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Stack(children: [
              avail
                  ? Pic(it, w: double.infinity, h: mobile ? 104 : 128, radius: 0, mono: 64)
                  : ColorFiltered(
                      colorFilter: const ColorFilter.matrix(_grey),
                      child: Pic(it, w: double.infinity, h: mobile ? 104 : 128, radius: 0, mono: 64),
                    ),
              if (!avail) Positioned(top: 10, left: 10, child: Tag(t('soldOut'))),
            ]),
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(nm(it['names']), style: ts(15, w: w7, h: 1.3)),
                gap(8),
                price,
              ]),
            ),
          ]);
    return Opacity(
      opacity: avail ? 1 : 0.5,
      child: Material(
        color: C.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(addon ? 16 : 18), side: const BorderSide(color: C.line)),
        clipBehavior: Clip.antiAlias,
        child: InkWell(onTap: avail ? () => _tap(context) : null, child: content),
      ),
    );
  }

  void _tap(BuildContext context) {
    if (it['isAddon'] == true) {
      if (curShift() == null) {
        toast(t(todayClosed() ? 'posClosedSub' : 'posNotOpenSub'), 'lock');
        return;
      }
      addToCart(<String, dynamic>{'id': it['id'], 'big': false, 'addons': <dynamic>[], 'qty': 1, 'price': null});
      save();
      return;
    }
    showDlg(context, (c) => OptionDialog(id: it['id']));
  }
}

const List<double> _grey = [
  0.2126, 0.7152, 0.0722, 0, 0,
  0.2126, 0.7152, 0.0722, 0, 0,
  0.2126, 0.7152, 0.0722, 0, 0,
  0, 0, 0, 1, 0,
];

/// Dish options: size, required choices (fish / noodle / milk / alcohol), add-ons, quantity.
class OptionDialog extends StatefulWidget {
  final dynamic id;
  const OptionDialog({super.key, required this.id});
  @override
  State<OptionDialog> createState() => _OptionDialogState();
}

class _OptionDialogState extends State<OptionDialog> {
  late final Map<String, dynamic> it = item(widget.id)!;
  bool big = false, tried = false;
  late final Map<String, String> choices = Map<String, String>.from(kSeriesDef[Str(it['series'] ?? 'noodle')] ?? {});
  final addons = <String>{};
  final opts = <String>{};
  int qty = 1;

  @override
  Widget build(BuildContext context) {
    final ch = Str(S['channel']);
    final del = kDelivery.contains(ch);
    final adds = del ? <dynamic>[] : menuList.where((m) => m['isAddon'] == true && m['available'] == true).toList();
    final groups = kSeries[Str(it['series'] ?? 'noodle')] ?? const <String>[];
    num unit;
    if (del) {
      unit = itemApp(it, big, ch) + opts.fold<num>(0, (s, o) => s + optApp(dOpt(o), ch));
    } else {
      unit = (big && it['pb'] != null ? N(it['pb']) : N(it['ps'])) + addons.fold<num>(0, (s, a) => s + N(item(a)?['ps']));
    }
    final miss = groups.where((g) => choices[g] == null).length;
    final sh = curShift();
    Widget sizeBtn(String label, String? price, bool on, VoidCallback onTap) => InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
                color: on ? C.pSoft : C.surface,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: on ? C.p : C.line2, width: on ? 2 : 1.5)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(label, style: ts(14.5, w: w7, c: on ? C.p : C.ink)),
              if (price != null) Text(price, style: ts(13, w: w6, c: C.muted)),
            ]),
          ),
        );
    Widget grid(int cols, List<Widget> children) => LayoutBuilder(builder: (c, k) {
          final w = (k.maxWidth - (cols - 1) * 8) / cols;
          return Wrap(spacing: 8, runSpacing: 8, children: [for (final x in children) SizedBox(width: w, child: x)]);
        });
    return Dlg(
      titleWidget: Row(children: [
        Flexible(child: Text(nm(it['names']), style: ts(19, w: w8, ls: -0.3))),
        if (del) ...[hgap(8), Tag(t('appPrice'), kind: TK.del)],
      ]),
      body: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Pic(it, w: double.infinity, h: 150, radius: 16, mono: 72),
        if (it['pb'] != null) ...[
          Lbl('${t('small')} / ${t('big')}'),
          grid(2, [
            sizeBtn(t('small'), rm(del ? itemApp(it, false, ch) : it['ps']), !big, () => setState(() => big = false)),
            sizeBtn(t('big'), rm(del ? itemApp(it, true, ch) : it['pb']), big, () => setState(() => big = true)),
          ]),
        ],
        for (final g in groups) ...[
          Lbl(nm(kGroups[g]!['names']), trailing: tried && choices[g] == null ? Tag(t('pickOne'), kind: TK.bad) : null),
          grid(
            (kGroups[g]!['opts'] as List).length < (g == 'noodle' ? 3 : 2) ? (kGroups[g]!['opts'] as List).length : (g == 'noodle' ? 3 : 2),
            [
              for (final o in kGroups[g]!['opts'] as List)
                sizeBtn(nm(o[1]), null, choices[g] == o[0], () => setState(() => choices[g] = o[0] as String)),
            ],
          ),
        ],
        if (adds.isNotEmpty) ...[
          Lbl(t('addons')),
          grid(isNarrow(context) ? 1 : 2, [
            for (final a in adds)
              InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () => setState(() => addons.contains(a['id']) ? addons.remove(a['id']) : addons.add(Str(a['id']))),
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                      color: addons.contains(a['id']) ? C.pSoft : C.surface,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: addons.contains(a['id']) ? C.p : C.line2, width: addons.contains(a['id']) ? 2 : 1.5)),
                  child: Row(children: [
                    Pic(a, w: 40, h: 40, mono: 18),
                    hgap(10),
                    Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(nm(a['names']), style: ts(14, w: w7)),
                      Text('+${rm0(a['ps'])}', style: ts(12.5, w: w6, c: C.muted)),
                    ])),
                    if (addons.contains(a['id'])) const Ic('check', size: 17, color: C.p),
                  ]),
                ),
              ),
          ]),
        ],
      ]),
      foot: [
        Container(
          height: 56,
          decoration: BoxDecoration(color: C.sunken, borderRadius: BorderRadius.circular(14)),
          child: Row(children: [
            InkWell(onTap: () => setState(() => qty = qty > 1 ? qty - 1 : 1), child: const SizedBox(width: 48, height: 56, child: Center(child: Ic('minus')))),
            SizedBox(width: 28, child: Text('$qty', textAlign: TextAlign.center, style: ts(18, w: w8))),
            InkWell(onTap: () => setState(() => qty++), child: const SizedBox(width: 48, height: 56, child: Center(child: Ic('plus')))),
          ]),
        ),
        Expanded(
          child: sh == null
              ? Btn(t(todayClosed() ? 'cantAddClosed' : 'cantAddNotOpen'), icon: 'lock', size: BS.lg, full: true)
              : Btn(miss > 0 ? t('pickRemaining').replaceAll('{n}', '$miss') : '${t('add')}  ${rm(unit * qty)}', size: BS.lg, full: true, onTap: () {
                  if (miss > 0) {
                    setState(() => tried = true);
                    return;
                  }
                  addToCart(<String, dynamic>{
                    'id': it['id'], 'big': big, 'choices': Map<String, dynamic>.from(choices),
                    'addons': (addons.toList()..sort()), 'opts': (opts.toList()..sort()), 'qty': qty, 'price': null,
                  });
                  save();
                  Navigator.pop(context);
                }),
        ),
      ],
    );
  }
}

/// Order being built: channel, lines, table/ref, note, total, Send to kitchen.
class CartPanel extends StatelessWidget {
  final bool inSheet;
  const CartPanel({super.key, this.inSheet = false});
  @override
  Widget build(BuildContext context) {
    final ch = Str(S['channel']);
    final deliv = kDelivery.contains(ch);
    final shop = cartTotal(), app = cartApp();
    final lines = cart;
    return Column(children: [
      Container(
        padding: EdgeInsets.fromLTRB(20, inSheet ? 0 : 18, 20, 14),
        decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: C.line))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [
            Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t('newOrder'), style: ts(13, w: w7, c: C.muted)),
              Text('#${nextNo()}', style: ts(22, w: w8, ls: -0.4)),
            ])),
            if (lines.isNotEmpty)
              LinkBtn(t('clear'), icon: 'trash', color: C.muted, onTap: () {
                S['cart'] = <dynamic>[];
                S['orderDisc'] = null;
                save();
              }),
          ]),
          gap(14),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(children: [
              for (final c in kChs)
                Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: PillBtn(t('ch_$c'), on: ch == c, dot: kCh[c], onTap: () {
                    S['channel'] = c;
                    save();
                  }),
                ),
            ]),
          ),
        ]),
      ),
      Expanded(
        child: lines.isEmpty
            ? Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                Container(
                    width: 64, height: 64, alignment: Alignment.center,
                    decoration: const BoxDecoration(color: C.sunken, shape: BoxShape.circle),
                    child: const Ic('bag', size: 26, color: Color(0xFFB7B2C4))),
                gap(12),
                Text(t('emptyCart'), style: ts(14.5, w: w6, c: C.muted)),
              ]))
            : ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
                itemCount: lines.length,
                itemBuilder: (c, i) => _CartLine(i, deliv),
              ),
      ),
      Container(
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 18),
        decoration: const BoxDecoration(border: Border(top: BorderSide(color: C.line))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [
            Expanded(
                child: _CartField(
                    key: const ValueKey('tagIn'), value: Str(S['tag']), hint: deliv ? t('deliveryRef') : t('tableName'), onChanged: (s) {
              S['tag'] = s;
              save();
            })),
            hgap(8),
            Expanded(
                child: _CartField(key: const ValueKey('noteIn'), value: Str(S['note']), hint: '${t('note')}: ${t('noteHint')}', onChanged: (s) {
              S['note'] = s;
              save();
            })),
          ]),
          gap(12),
          if (deliv && lines.isNotEmpty) ...[
            Row(children: [Expanded(child: Text(t('shopPrice'), style: ts(14, w: w6, c: C.muted))), Text(rm(shop), style: ts(14, w: w6, c: C.muted))]),
            gap(4),
          ],
          Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Expanded(child: Text(deliv ? t('appPrice') : t('total'), style: ts(15, w: w7))),
            Text(rm(deliv ? app : shop), style: ts(28, w: w8, ls: -0.6)),
          ]),
          gap(12),
          Btn(t('sendKitchen'), icon: deliv ? 'scooter' : 'flame', size: BS.lg, full: true, onTap: lines.isEmpty || curShift() == null
              ? null
              : () {
                  final o = buildOrder();
                  save();
                  if (inSheet) Navigator.pop(context);
                  toast(t('sentToast', o['n']));
                }),
          gap(8),
          Text(deliv ? t('payDeliveryHint') : t('payLaterHint'), textAlign: TextAlign.center, style: ts(12.5, c: C.muted)),
        ]),
      ),
    ]);
  }
}

class _CartField extends StatefulWidget {
  final String value, hint;
  final ValueChanged<String> onChanged;
  const _CartField({super.key, required this.value, required this.hint, required this.onChanged});
  @override
  State<_CartField> createState() => _CartFieldState();
}

class _CartFieldState extends State<_CartField> {
  late final c = TextEditingController(text: widget.value);
  @override
  void didUpdateWidget(covariant _CartField old) {
    super.didUpdateWidget(old);
    if (widget.value.isEmpty && c.text.isNotEmpty) c.clear(); // cleared after sending the order
  }

  @override
  Widget build(BuildContext context) => TextField(
        controller: c,
        style: ts(14),
        decoration: InputDecoration(hintText: widget.hint, contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10)),
        onChanged: widget.onChanged,
      );
}

class _CartLine extends StatelessWidget {
  final int i;
  final bool deliv;
  const _CartLine(this.i, this.deliv);
  @override
  Widget build(BuildContext context) {
    final l = cart[i];
    final it = item(l['id']);
    if (it == null) return const SizedBox.shrink();
    final sub = [
      if (it['pb'] != null && it['isAddon'] != true) t(l['big'] == true ? 'big' : 'small'),
      ...choiceList(l),
      ...L(l['addons']).map((a) => '+ ${nm(item(a)?['names'])}'),
      ...L(l['opts']).map((o) => nm(dOpt(o)?['names'])),
    ].where((s) => s.isNotEmpty).join(', ');
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(border: i == cart.length - 1 ? null : const Border(bottom: BorderSide(color: C.line))),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Pic(it),
        hgap(12),
        Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(nm(it['names']), style: ts(14.5, w: w7, h: 1.3)),
          if (sub.isNotEmpty) Text(sub, style: ts(12.5, c: C.muted)),
        ])),
        hgap(8),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text(rm((deliv ? lineApp(l) : lineUnit(l)) * N(l['qty'])), style: ts(14.5, w: w7)),
          if (deliv) Text('${t('shopPrice')} ${rm(lineUnit(l) * N(l['qty']))}', style: ts(12, w: w6, c: C.muted)),
          gap(8),
          StepperBox(
            value: '${l['qty']}',
            onMinus: () {
              l['qty'] = I(l['qty']) - 1;
              if (I(l['qty']) <= 0) cart.removeAt(i);
              save();
            },
            onPlus: () {
              l['qty'] = I(l['qty']) + 1;
              save();
            },
          ),
        ]),
      ]),
    );
  }
}

import 'package:flutter/material.dart';

import '../../data/consts.dart';
import '../../data/logic.dart';
import '../../data/store.dart';
import '../../data/util.dart';
import '../../services.dart';
import '../theme.dart';
import '../widgets.dart';
import 'kitchen.dart';

class MenuPage extends StatelessWidget {
  const MenuPage({super.key});
  @override
  Widget build(BuildContext context) {
    Widget row(dynamic it, bool last) => Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(border: last ? null : const Border(bottom: BorderSide(color: C.line))),
          child: Row(children: [
            Pic(it, w: 44, h: 44),
            hgap(12),
            Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                if (Str(it['code']).isNotEmpty)
                  Container(
                    margin: const EdgeInsets.only(right: 8),
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(color: C.ink, borderRadius: BorderRadius.circular(7)),
                    child: Text(Str(it['code']), style: ts(12.5, w: w8, c: Colors.white, ls: 0.4)),
                  ),
                Flexible(child: Text(nm(it['names']), style: ts(14.5, w: w7))),
              ]),
              gap(2),
              Text(sizePrice(it), style: ts(13, c: C.muted)),
            ])),
            if (!isNarrow(context)) ...[Tag(t(it['available'] == true ? 'available' : 'soldOut'), kind: it['available'] == true ? TK.ok : TK.mute), hgap(8)],
            Switch(
              value: it['available'] == true,
              activeTrackColor: C.ok,
              onChanged: (v) {
                it['available'] = v;
                save();
              },
            ),
            IconBtn('edit', onTap: () => showDlg(context, (c) => ItemDialog(id: it['id']))),
          ]),
        );
    Widget list(List<dynamic> l) => CardBox(
        padding: EdgeInsets.zero, child: Column(children: [for (var i = 0; i < l.length; i++) row(l[i], i == l.length - 1)]));
    final fish = menuList.where((m) => m['isAddon'] != true && m['series'] == 'fish').toList();
    final noodle = menuList.where((m) => m['isAddon'] != true && m['series'] != 'fish').toList();
    final adds = menuList.where((m) => m['isAddon'] == true).toList();
    return Align(
      alignment: Alignment.topLeft,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 900),
        child: ListView(padding: pagePad(context), children: [
          Section(
              title: t('fishSeries'),
              trailing: Btn(t('addItem'), icon: 'plus', size: BS.sm, onTap: () => showDlg(context, (c) => const ItemDialog(id: null))),
              child: list(fish)),
          Section(title: t('noodleSeries'), child: list(noodle)),
          Section(title: t('addons'), child: list(adds)),
        ]),
      ),
    );
  }
}

class ItemDialog extends StatefulWidget {
  final dynamic id;
  const ItemDialog({super.key, required this.id});
  @override
  State<ItemDialog> createState() => _ItemDialogState();
}

class _ItemDialogState extends State<ItemDialog> {
  late final bool isNew = item(widget.id) == null;
  late final Map<String, dynamic> it = isNew
      ? <String, dynamic>{
          'id': '', 'isAddon': false, 'series': S['cat'] == 'noodle' ? 'noodle' : 'fish', 'ps': null, 'pb': null, 'available': true,
          'tint': now() % 8, 'names': <String, dynamic>{'en': '', 'zh': '', 'my': ''}, 'photo': null,
        }
      : deepCopy(item(widget.id)) as Map<String, dynamic>;
  late final code = TextEditingController(text: Str(it['code']));
  late final en = TextEditingController(text: Str(Mp(it['names'])['en']));
  late final zh = TextEditingController(text: Str(Mp(it['names'])['zh']));
  late final my = TextEditingController(text: Str(Mp(it['names'])['my']));
  late final ps = TextEditingController(text: it['ps'] == null ? '' : '${it['ps']}');
  late final pb = TextEditingController(text: it['pb'] == null ? '' : '${it['pb']}');
  bool err = false;

  void _grab() {
    it['names'] = <String, dynamic>{'en': en.text.trim(), 'zh': zh.text.trim(), 'my': my.text.trim()};
    it['code'] = code.text.trim().isEmpty ? null : code.text.trim().toUpperCase();
  }

  void _save() {
    _grab();
    final p = double.tryParse(ps.text);
    final b = pb.text.trim().isEmpty ? null : double.tryParse(pb.text);
    if (Str(Mp(it['names'])['en']).isEmpty || p == null || p < 0 || (pb.text.trim().isNotEmpty && b == null)) {
      setState(() => err = true);
      return;
    }
    it['ps'] = p;
    it['pb'] = it['isAddon'] == true ? null : b;
    final app = Mp(it['app']);
    for (final c in kDelivery) {
      final a = Mp(app[c]);
      a['ps'] = appRound(p, kAppF[c]!);
      a['pb'] = it['pb'] != null ? appRound(N(it['pb']), kAppF[c]!) : null;
      app[c] = a;
    }
    it['app'] = app;
    if (isNew) {
      it['id'] = '${it['isAddon'] == true ? 'a' : 'm'}${now()}';
      menuList.add(it);
      menuList.sort((a, b) => Str(a['id']).compareTo(Str(b['id'])));
    } else {
      final i = menuList.indexWhere((m) => m['id'] == it['id']);
      if (i >= 0) menuList[i] = it;
    }
    save();
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final addon = it['isAddon'] == true;
    Widget f(String label, TextEditingController c, {bool num = false}) => FieldBox(
        label,
        TextField(
            controller: c,
            keyboardType: num ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.text,
            style: ts(15),
            onChanged: (_) => setState(() {})));
    Widget two(Widget a, Widget b) => Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: a), hgap(14), Expanded(child: b)]);
    final preview = <String, dynamic>{...it, 'names': {'zh': zh.text.isNotEmpty ? zh.text : '?', 'en': en.text.isNotEmpty ? en.text : '?', 'my': my.text}, 'code': code.text};
    return Dlg(
      title: t(isNew ? 'addItem' : 'editItem'),
      body: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          Pic(preview, w: 84, h: 84, radius: 16, mono: 38),
          hgap(12),
          Expanded(
            child: Wrap(spacing: 8, runSpacing: 8, children: [
              Btn(t(it['photo'] != null ? 'changePhoto' : 'addPhoto'), icon: 'image', kind: BK.sec, size: BS.sm, onTap: () async {
                final p = await takePhoto(maxSize: 480, quality: 78, allowGallery: true);
                if (p != null && mounted) setState(() => it['photo'] = p);
              }),
              if (it['photo'] != null) Btn(t('removePhoto'), kind: BK.danger, size: BS.sm, onTap: () => setState(() => it['photo'] = null)),
            ]),
          ),
        ]),
        gap(16),
        if (isNew) ...[
          Seg<bool>(items: [(false, t('typeMain')), (true, t('typeAddon'))], value: addon, onChanged: (v) => setState(() => it['isAddon'] = v)),
          gap(14),
        ],
        if (!addon) ...[
          Text(t('series'), style: ts(13, w: w7, c: C.ink2)),
          gap(8),
          Seg<String>(
              items: [('fish', t('fishSeries')), ('noodle', t('noodleSeries'))],
              value: it['series'] == 'fish' ? 'fish' : 'noodle',
              onChanged: (v) => setState(() => it['series'] = v)),
          gap(14),
        ],
        two(f(t('dishCode'), code), const SizedBox.shrink()),
        gap(14),
        f(t('nameEn'), en),
        gap(14),
        two(f(t('nameZh'), zh), f(t('nameMy'), my)),
        gap(14),
        two(f(addon ? t('price') : t('priceSmall'), ps, num: true), addon ? const SizedBox.shrink() : f(t('priceBig'), pb, num: true)),
        if (!addon) Padding(padding: const EdgeInsets.only(top: 6), child: Text(t('priceBigHint'), style: ts(13, c: C.muted))),
        if (err) ...[gap(12), Note(t('checkFields'), kind: NK.bad)],
      ]),
      foot: [
        if (!isNew)
          Btn(t('delete'), kind: BK.danger, onTap: () {
            menuList.removeWhere((m) => m['id'] == it['id']);
            cart.removeWhere((l) => l['id'] == it['id']);
            save();
            Navigator.pop(context);
          }),
        const Spacer(),
        Btn(t('cancel'), kind: BK.sec, onTap: () => Navigator.pop(context)),
        Btn(t('save'), onTap: _save),
      ],
    );
  }
}

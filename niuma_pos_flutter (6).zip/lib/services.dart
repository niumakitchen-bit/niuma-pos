// Telegram (through the server), sounds, camera.
import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:audioplayers/audioplayers.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

import 'config.dart';

/// Sends [text] to the shop's Telegram chat. Returns null when sent, or the error message.
Future<String?> sendTelegram(String text) async {
  try {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return 'not signed in';
    final token = await user.getIdToken();
    final r = await http
        .post(Uri.parse(AppConfig.telegramEndpoint),
            headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $token'}, body: jsonEncode({'text': text}))
        .timeout(const Duration(seconds: 15));
    final j = jsonDecode(r.body);
    if (r.statusCode == 200 && j is Map && j['ok'] == true) return null;
    return (j is Map ? (j['error'] ?? j['description']) : null)?.toString() ?? 'HTTP ${r.statusCode}';
  } catch (e) {
    return e.toString();
  }
}

/* ---------- sounds: generated tones, no audio files ---------- */
Uint8List _wav(List<List<double>> notes, {bool square = false}) {
  const rate = 22050;
  final total = notes.fold<double>(0, (m, n) => math.max(m, n[1] + n[2]));
  final count = (total * rate).ceil();
  final pcm = Float64List(count);
  for (final n in notes) {
    final f = n[0], start = (n[1] * rate).round(), len = (n[2] * rate).round();
    for (var i = 0; i < len && start + i < count; i++) {
      final tt = i / rate;
      final env = math.min(1.0, i / (0.02 * rate)) * math.exp(-4.0 * tt / n[2]);
      var s = math.sin(2 * math.pi * f * tt);
      if (square) s = s >= 0 ? 0.6 : -0.6;
      pcm[start + i] += s * env * 0.35;
    }
  }
  final b = BytesBuilder();
  void u32(int v) => b.add([v & 255, (v >> 8) & 255, (v >> 16) & 255, (v >> 24) & 255]);
  void u16(int v) => b.add([v & 255, (v >> 8) & 255]);
  b.add(ascii.encode('RIFF'));
  u32(36 + count * 2);
  b.add(ascii.encode('WAVEfmt '));
  u32(16);
  u16(1);
  u16(1);
  u32(rate);
  u32(rate * 2);
  u16(2);
  u16(16);
  b.add(ascii.encode('data'));
  u32(count * 2);
  for (final v in pcm) {
    final s = (v.clamp(-1.0, 1.0) * 32767).round();
    u16(s & 0xFFFF);
  }
  return b.toBytes();
}

final _player = AudioPlayer();
final Uint8List _chime = _wav([
  [880, 0, 0.38],
  [1175, 0.16, 0.38],
  [1568, 0.32, 0.38]
]);
final Uint8List _alarm = _wav([
  [990, 0, 0.2],
  [660, 0.25, 0.2],
  [990, 0.5, 0.2],
  [660, 0.75, 0.2]
], square: true);

Future<void> _play(Uint8List b) async {
  try {
    await _player.stop();
    await _player.play(BytesSource(b));
  } catch (_) {}
}

void chime() => _play(_chime);
void alarmSound() => _play(_alarm);

/* ---------- camera ---------- */
final _picker = ImagePicker();

/// Takes a photo (front camera for clock in/out). Returns a small JPEG as a data URI, or null.
Future<String?> takePhoto({bool front = false, double maxSize = 360, int quality = 65, bool allowGallery = false}) async {
  try {
    final x = await _picker.pickImage(
        source: allowGallery ? ImageSource.gallery : ImageSource.camera,
        preferredCameraDevice: front ? CameraDevice.front : CameraDevice.rear,
        maxWidth: maxSize,
        maxHeight: maxSize,
        imageQuality: quality);
    if (x == null) return null;
    final bytes = await x.readAsBytes();
    return 'data:image/jpeg;base64,${base64Encode(bytes)}';
  } catch (_) {
    return null;
  }
}

final Map<String, Uint8List> _bytesCache = {};

/// Decoded photo bytes. The same Uint8List is returned for the same photo, so Flutter's image cache
/// recognises it and does not decode the picture again on every redraw.
Uint8List? photoBytes(String? dataUri) {
  if (dataUri == null || !dataUri.startsWith('data:')) return null;
  final hit = _bytesCache.remove(dataUri);
  if (hit != null) return _bytesCache[dataUri] = hit; // move to newest
  final i = dataUri.indexOf(',');
  try {
    final b = base64Decode(dataUri.substring(i + 1));
    _bytesCache[dataUri] = b;
    if (_bytesCache.length > 300) _bytesCache.remove(_bytesCache.keys.first);
    return b;
  } catch (_) {
    return null;
  }
}

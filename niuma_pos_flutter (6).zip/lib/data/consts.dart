// Constants and default data, same as the web app (core.js).
import 'package:flutter/material.dart';

const Map<String, Color> kCh = {
  'dineIn': Color(0xFF6D28D9),
  'takeaway': Color(0xFF0EA5E9),
  'grab': Color(0xFF00B14F),
  'foodpanda': Color(0xFFD70F64),
  'shopee': Color(0xFFEE4D2D),
};
const List<String> kChs = ['dineIn', 'takeaway', 'grab', 'foodpanda', 'shopee'];
const List<String> kDelivery = ['grab', 'foodpanda', 'shopee'];
const List<String> kPays = ['cash', 'tng'];
const Map<String, Color> kPayCol = {
  'cash': Color(0xFF16A34A),
  'duitnow': Color(0xFFE11D48),
  'tng': Color(0xFF2563EB),
  'card': Color(0xFFF59E0B),
  'platform': Color(0xFF8A8598),
  'unpaid': Color(0xFFF59E0B),
};
const List<num> kNotes = [100, 50, 20, 10, 5, 1];
const List<num> kCoins = [0.5, 0.2, 0.1, 0.05];
const List<num> kDenoms = [100, 50, 20, 10, 5, 1, 0.5, 0.2, 0.1, 0.05];

const List<String> kCats = [
  'income', 'fishhead', 'fishslice', 'mince', 'lard', 'noodle', 'rent', 'gas', 'veg',
  'oil', 'dry', 'milk', 'wine', 'paste', 'balls', 'wage', 'other'
];
final List<String> kExpCats = kCats.where((c) => c != 'income').toList();
const Map<String, Color> kCatCol = {
  'income': Color(0xFF16A34A), 'fishhead': Color(0xFFEF4444), 'fishslice': Color(0xFFF97316),
  'mince': Color(0xFFB91C1C), 'lard': Color(0xFFCA8A04), 'noodle': Color(0xFFF59E0B),
  'rent': Color(0xFF64748B), 'gas': Color(0xFF3B82F6), 'veg': Color(0xFF22C55E),
  'oil': Color(0xFFEAB308), 'dry': Color(0xFFA855F7), 'milk': Color(0xFF0EA5E9),
  'wine': Color(0xFFBE185D), 'paste': Color(0xFFFB7185), 'balls': Color(0xFF14B8A6),
  'wage': Color(0xFFEC4899), 'other': Color(0xFF94A3B8),
};

Map<String, String> _n(String en, String zh, String my) => {'en': en, 'zh': zh, 'my': my};
final List<List<dynamic>> _yn = [
  ['yes', _n('Yes', '要', 'ထည့်')],
  ['no', _n('No', '不要', 'မထည့်')],
];
// Option groups every dish in a series must answer, in this order (size is asked first).
final Map<String, Map<String, dynamic>> kGroups = {
  'fish': {
    'names': _n('Fish', '鱼', 'ငါး'),
    'opts': [
      ['goreng', _n('Goreng (fried)', '炸', 'ကြော်')],
      ['masak', _n('Masak (cooked)', '煮', 'ပြုတ်')],
    ],
  },
  'noodle': {
    'names': _n('Noodle', '面', 'ခေါက်ဆွဲ'),
    'opts': [
      ['A', _n('Mihun (A)', '米粉 (A)', 'ကြာဇံ (A)')],
      ['B', _n('Thick Pan Mee (B)', '粗板面 (B)', 'ပန်မီး အထူ (B)')],
      ['C', _n('Thin Pan Mee (C)', '幼板面 (C)', 'ပန်မီး အပါး (C)')],
      ['D', _n('Pan Mee Slice (D)', '面片 (D)', 'ပန်မီး အပြား (D)')],
      ['E', _n('Yee Mee (E)', '伊面 (E)', 'ယီမီး (E)')],
    ],
  },
  'milk': {'names': _n('Milk', '淡奶', 'နို့'), 'opts': _yn},
  'alcohol': {'names': _n('Alcohol', '酒', 'အရက်'), 'opts': _yn},
};
const Map<String, List<String>> kSeries = {
  'fish': ['fish', 'noodle', 'milk', 'alcohol'],
  'noodle': ['noodle'],
};
// Pre-selected answers: if the customer wants nothing special, staff just tap Add.
const Map<String, Map<String, String>> kSeriesDef = {
  'fish': {'fish': 'goreng', 'noodle': 'A', 'milk': 'yes', 'alcohol': 'yes'},
  'noodle': {'noodle': 'B'},
};
const List<String> kReasons = ['r_regular', 'r_staff', 'r_promo', 'r_wrong', 'r_other'];
const List<List<String>> kNav = [
  ['dashboard', 'grid'], ['pos', 'pos'], ['kitchen', 'flame'], ['openOrders', 'clock']
];
const List<List<String>> kNav2 = [
  ['registers', 'coins'], ['attendance', 'user'], ['expenses', 'camera'], ['menu', 'book'], ['settings', 'gear']
];
const List<Color> kTint = [
  Color(0xFFFFF1E6), Color(0xFFEAF2FF), Color(0xFFF4EDE1), Color(0xFFFFE9E9),
  Color(0xFFEAF7EF), Color(0xFFF3EEFE), Color(0xFFFFF7DB), Color(0xFFE8F7F6)
];
const List<Color> kTink = [
  Color(0xFFC2410C), Color(0xFF1D4ED8), Color(0xFF8A5A2B), Color(0xFFB91C1C),
  Color(0xFF15803D), Color(0xFF6D28D9), Color(0xFFA16207), Color(0xFF0F766E)
];

// Each platform has its own app price. Default = shop price + platform markup, ending in .90.
const Map<String, double> kAppF = {'grab': 1.2, 'foodpanda': 1.25, 'shopee': 1.15};
double appRound(num v, [double f = 1.2]) {
  final x = (v * f).ceil() - 0.1;
  return x < 0.9 ? 0.9 : double.parse(x.toStringAsFixed(2));
}

Map<String, dynamic> _m(String id, String? code, String mono, String? series, bool addon, num ps, num? pb, int tint,
        String en, String zh, String my) =>
    <String, dynamic>{
      'id': id, if (code != null) 'code': code, 'mono': mono, if (series != null) 'series': series,
      'isAddon': addon, 'ps': ps, 'pb': pb, 'available': true, 'tint': tint,
      'names': <String, dynamic>{'en': en, 'zh': zh, 'my': my},
    };

List<dynamic> defaultMenu() {
  final list = <Map<String, dynamic>>[
    _m('m01', 'S1', '头', 'fish', false, 14, 16, 0, 'Fish head noodles', '鱼头面', 'ငါးခေါင်း ခေါက်ဆွဲ'),
    _m('m02', 'S2', '片', 'fish', false, 12, 14, 1, 'Fish slice noodles', '鱼片面', 'ငါးအသား ခေါက်ဆွဲ'),
    _m('m03', 'S3', '滑', 'fish', false, 13, 15, 3, 'Fish paste noodles', '鱼滑面', 'ငါးဖယ် ခေါက်ဆွဲ'),
    _m('m04', 'S4', '斑', 'fish', false, 22, null, 7, 'Grouper fish head noodles', '石斑鱼头面', 'ကျောက်ငါးခေါင်း ခေါက်ဆွဲ'),
    _m('m05', 'S5', '综', 'fish', false, 30, null, 5, 'All in one', '综合鱼面', 'အစုံ ခေါက်ဆွဲ'),
    _m('m06', 'N1', '汤', 'noodle', false, 9, 11, 2, 'Pan mee soup', '板面（汤）', 'ပန်မီး ဟင်းရည်'),
    _m('m07', 'N2', '干', 'noodle', false, 9, 11, 6, 'Dry pan mee', '干捞板面', 'ပန်မီး အခြောက်'),
    _m('m08', 'N3', '辣', 'noodle', false, 10, 12, 3, 'Chili pan mee', '辣椒板面', 'ငရုတ်သီး ပန်မီး'),
    _m('a01', null, '头', null, true, 8, null, 0, 'Fish head', '鱼头', 'ငါးခေါင်း'),
    _m('a02', null, '片', null, true, 5, null, 1, 'Fish slice', '鱼片', 'ငါးအသား'),
    _m('a03', null, '滑', null, true, 7, null, 3, 'Fish paste', '鱼滑', 'ငါးဖယ်'),
    _m('a04', null, '面', null, true, 1.5, null, 2, 'Extra noodle', '加面', 'ခေါက်ဆွဲ အပို'),
    _m('a05', null, '蛋', null, true, 1.5, null, 6, 'Egg', '鸡蛋', 'ကြက်ဥ'),
    _m('a06', null, '虾', null, true, 4, null, 3, '1 prawn', '虾（1只）', 'ပုစွန် (၁ ကောင်)'),
    _m('a07', null, '虾', null, true, 10, null, 0, '3 prawns', '虾（3只）', 'ပုစွန် (၃ ကောင်)'),
    _m('a08', null, '碎', null, true, 2, null, 4, 'Minced pork', '肉碎', 'ဝက်သားစင်း'),
    _m('a09', null, '江', null, true, 2, null, 7, 'Ikan bilis', '江鱼仔', 'ငါးသေးလေးခြောက်'),
    _m('a10', null, '丸', null, true, 4, null, 1, '6 fish balls', '鱼丸（6粒）', 'ငါးဘောလုံး (၆ လုံး)'),
    _m('a11', null, '肉', null, true, 2, null, 4, '4 pork balls', '肉丸（4粒）', 'ဝက်သားလုံး (၄ လုံး)'),
  ];
  for (final m in list) {
    m['app'] = <String, dynamic>{
      for (final c in kDelivery)
        c: <String, dynamic>{
          'ps': appRound(m['ps'] as num, kAppF[c]!),
          'pb': m['pb'] == null ? null : appRound(m['pb'] as num, kAppF[c]!),
        }
    };
  }
  return list;
}

Map<String, dynamic> _x(String id, String en, String zh, String my, [String? unit]) => <String, dynamic>{
      'id': id, if (unit != null) 'unit': unit, 'names': <String, dynamic>{'en': en, 'zh': zh, 'my': my},
    };

List<dynamic> defaultTasks() => [
      _x('t1', 'Wash dishes', '洗碗', 'ပန်းကန်ဆေး'),
      _x('t2', 'Put all the food into the fridge', '把所有食材放进冰箱', 'အစားအစာအားလုံး ရေခဲသေတ္တာထဲထည့်'),
      _x('t3', 'Turn off the gas', '关煤气', 'ဂက်စ်ပိတ်'),
      _x('t4', 'Throw rubbish', '倒垃圾', 'အမှိုက်ပစ်'),
      _x('t5', 'Clean the floor', '清洗地板', 'ကြမ်းပြင်သန့်ရှင်း'),
      _x('t6', 'Check stock', '检查库存', 'ကုန်ပစ္စည်းစစ်'),
      _x('t7', 'Snap receipts of the day', '拍下今天的收据', 'ယနေ့ဘောက်ချာများ ဓာတ်ပုံရိုက်'),
      _x('t8', 'Fry ikan bilis', '炸江鱼仔', 'ငါးသေးလေး ကြော်'),
    ];

List<dynamic> defaultStock() => [
      _x('s1', 'Fish head', '鱼头', 'ငါးခေါင်း', 'packet'),
      _x('s2', 'Fish slice', '鱼片', 'ငါးအသား', 'packet'),
      _x('s3', 'Fish paste', '鱼滑', 'ငါးဖယ်', 'set'),
      _x('s4', 'Pan mee', '板面', 'ပန်မီး', 'set'),
      _x('s5', 'Eggs', '鸡蛋', 'ကြက်ဥ', 'pcs'),
      _x('s6', 'Mihun', '米粉', 'ကြာဇံ', 'packet'),
      _x('s7', 'Minced pork', '肉碎', 'ဝက်သားစင်း', 'tong'),
      _x('s8', 'Fried shallot', '炸葱头', 'ကြက်သွန်နီကြော်', 'tong'),
      _x('s9', 'Salted vegetable', '咸菜', 'မုန်ညင်းချဉ်', 'packet'),
      _x('s10', 'Fish balls', '鱼丸', 'ငါးဘောလုံး', 'packet'),
      _x('s11', 'Pork balls', '肉丸', 'ဝက်သားလုံး', 'packet'),
      _x('s12', 'Ikan bilis soup', '江鱼仔汤', 'ငါးသေးလေး ဟင်းရည်', 'packet'),
      _x('s13', 'Ikan bilis goreng', '炸江鱼仔', 'ငါးသေးလေးကြော်', 'tong'),
      _x('s14', 'Ginger', '姜', 'ချင်း', 'packet'),
      _x('s15', 'Tomato', '番茄', 'ခရမ်းချဉ်သီး', 'packet'),
    ];

Map<String, dynamic> freshState() => <String, dynamic>{
      'lang': 'en', 'tab': 'pos', 'menu': defaultMenu(), 'orders': <dynamic>[], 'cart': <dynamic>[],
      'channel': 'dineIn', 'note': '', 'tag': '', 'orderDisc': null,
      'expenses': <dynamic>[], 'shifts': <dynamic>[], 'tasks': defaultTasks(), 'stock': defaultStock(),
      'cat': 'fish', 'petty': <dynamic>[], 'changes': <dynamic>[],
      'staff': <dynamic>[<String, dynamic>{'id': 'st1', 'name': 'Staff 1'}], 'att': <dynamic>[],
      'tg': <String, dynamic>{'phone': '0122046187'},
      'hours': <String, dynamic>{
        'clockIn': '07:00', 'clockOut': '20:30',
        'open': <dynamic>[<dynamic>['08:00', '14:00'], <dynamic>['17:30', '20:30']],
        'offTue': <dynamic>[1, 3],
      },
      'range': <String, dynamic>{'preset': 'today', 'date': ''},
      'prep': <String, dynamic>{'grab': 15, 'foodpanda': 15, 'shopee': 15},
      'delPlat': 'all', 'delSeg': 'wait', 'delOpts': <dynamic>[], 'expMonth': '', 'rent': 1350,
    };

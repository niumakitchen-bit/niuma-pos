// Small helpers for the JSON-shaped state (same field names as the web app).
import 'dart:math';

import 'package:intl/intl.dart';

import '../l10n_data.dart';

/// The whole app state, same shape as `S` in the web app.
late Map<String, dynamic> S;

num N(dynamic v) => v is num ? v : (v is String ? (num.tryParse(v) ?? 0) : 0);
double D(dynamic v) => N(v).toDouble();
int I(dynamic v) => N(v).toInt();
String Str(dynamic v) => v == null ? '' : v.toString();
List<dynamic> L(dynamic v) => v is List ? v : <dynamic>[];
Map<String, dynamic> Mp(dynamic v) => v is Map<String, dynamic> ? v : (v is Map ? Map<String, dynamic>.from(v) : <String, dynamic>{});
double? numOrNull(dynamic v) => v is num ? v.toDouble() : (v is String ? double.tryParse(v) : null);

dynamic deepCopy(dynamic v) {
  if (v is Map) return <String, dynamic>{for (final e in v.entries) e.key.toString(): deepCopy(e.value)};
  if (v is List) return <dynamic>[for (final x in v) deepCopy(x)];
  return v;
}

List<dynamic> get orders => S['orders'] as List<dynamic>;
List<dynamic> get expenses => S['expenses'] as List<dynamic>;
List<dynamic> get shifts => S['shifts'] as List<dynamic>;
List<dynamic> get petty => S['petty'] as List<dynamic>;
List<dynamic> get changes => S['changes'] as List<dynamic>;
List<dynamic> get att => S['att'] as List<dynamic>;
List<dynamic> get menuList => S['menu'] as List<dynamic>;
List<dynamic> get stockList => S['stock'] as List<dynamic>;
List<dynamic> get taskList => S['tasks'] as List<dynamic>;
List<dynamic> get staffList => S['staff'] as List<dynamic>;
List<dynamic> get cart => S['cart'] as List<dynamic>;
Map<String, dynamic> get hours => S['hours'] as Map<String, dynamic>;
Map<String, dynamic> get tg => S['tg'] as Map<String, dynamic>;
String get lang => Str(S['lang']).isEmpty ? 'en' : Str(S['lang']);

/// Translation, with `{n}` filled in like the web app.
String t(String k, [Object? n]) {
  final s = kT[lang]?[k] ?? kT['en']![k] ?? k;
  return n == null ? s : s.replaceAll('{n}', '$n');
}

String nm(dynamic names) {
  final m = Mp(names);
  final v = Str(m[lang]);
  return v.isNotEmpty ? v : Str(m['en']);
}

int now() => DateTime.now().millisecondsSinceEpoch;
const int kDay = 86400000;
DateTime dt(num ms) => DateTime.fromMillisecondsSinceEpoch(ms.toInt());
String two(int n) => n.toString().padLeft(2, '0');
int dayStart(num ms) {
  final d = dt(ms);
  return DateTime(d.year, d.month, d.day).millisecondsSinceEpoch;
}

bool sameDay(num a, num b) => dayStart(a) == dayStart(b);
String fmtT(num ms) {
  final d = dt(ms);
  return '${two(d.hour)}:${two(d.minute)}';
}

String fmtD(num ms) {
  final d = dt(ms);
  return '${two(d.day)}/${two(d.month)}';
}

String isoDate(num ms) {
  final d = dt(ms);
  return '${d.year}-${two(d.month)}-${two(d.day)}';
}

String monthKey(num ms) {
  final d = dt(ms);
  return '${d.year}-${two(d.month)}';
}

/// Parse "YYYY-MM-DD" (+ optional HH:MM) as local time.
int isoMs(String iso, [String time = '00:00']) {
  final p = iso.split('-');
  final h = time.split(':');
  if (p.length < 3) return now();
  return DateTime(int.tryParse(p[0]) ?? 2000, int.tryParse(p[1]) ?? 1, int.tryParse(p[2]) ?? 1,
          int.tryParse(h[0]) ?? 0, h.length > 1 ? (int.tryParse(h[1]) ?? 0) : 0, h.length > 2 ? (int.tryParse(h[2]) ?? 0) : 0)
      .millisecondsSinceEpoch;
}

String get _loc => {'en': 'en', 'zh': 'zh_CN', 'my': 'my'}[lang] ?? 'en';
String longDate(num ms) {
  try {
    return DateFormat('EEEE, d MMMM', _loc).format(dt(ms));
  } catch (_) {
    return fmtD(ms);
  }
}

String monthName(String key) {
  final p = key.split('-');
  try {
    return DateFormat('MMMM y', _loc).format(DateTime(int.parse(p[0]), int.parse(p[1]), 1));
  } catch (_) {
    return key;
  }
}

String weekdayNarrow(int i) {
  try {
    return DateFormat('EEEEE', _loc).format(DateTime(2024, 1, 1 + i));
  } catch (_) {
    return 'MTWTFSS'[i];
  }
}

final _rand = Random();
String uid(String p) => p + now().toRadixString(36) + _rand.nextInt(1 << 30).toRadixString(36).padLeft(4, '0').substring(0, 4);

double r2(num x) => (x * 100).round() / 100;

/// "RM 1,234.50", negative with a real minus sign.
String rm(dynamic v) {
  final x = r2(N(v));
  final f = NumberFormat('#,##0.00', 'en_US').format(x.abs());
  return '${x < 0 ? '−' : ''}RM $f';
}

String rm0(dynamic v) {
  final x = N(v);
  return 'RM${x % 1 == 0 ? x.toStringAsFixed(0) : x.toStringAsFixed(2)}';
}

String denLbl(num d) => d >= 1 ? 'RM${d.toStringAsFixed(0)}' : '${(d * 100).round()}sen';
String denKey(num d) => d % 1 == 0 ? d.toInt().toString() : d.toString();

num denTotal(dynamic c) {
  num s = 0;
  Mp(c).forEach((d, n) => s += (num.tryParse(d) ?? 0) * N(n));
  return r2(s);
}

Map<String, dynamic> toDen(num total) {
  var left = (total * 100).round();
  final c = <String, dynamic>{};
  for (final d in kDenomsLocal) {
    final v = (d * 100).round();
    var n = left ~/ v;
    if (d >= 50 && n > 2) n = 2;
    if (n > 0) {
      c[denKey(d)] = n;
      left -= n * v;
    }
  }
  return c;
}

const List<num> kDenomsLocal = [100, 50, 20, 10, 5, 1, 0.5, 0.2, 0.1, 0.05];

int hm(String s) {
  final p = s.split(':');
  return (int.tryParse(p[0]) ?? 0) * 60 + (p.length > 1 ? (int.tryParse(p[1]) ?? 0) : 0);
}

int atHM(num day, String s) => dayStart(day) + hm(s) * 60000;
int daysIn(num ms) {
  final d = dt(ms);
  return DateTime(d.year, d.month + 1, 0).day;
}

String fmtLeft(num ms) {
  final a = ms.abs().toInt();
  return '${two(a ~/ 60000)}:${two((a ~/ 1000) % 60)}';
}

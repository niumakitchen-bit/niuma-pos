// ============================================================================
//  EDIT THIS FILE ONCE: paste the values from your Firebase project.
//  Firebase console → Project settings → General → Your apps.
//  (Web app: "SDK setup and configuration" → Config. iOS app: GoogleService-Info.plist.)
// ============================================================================
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

class AppConfig {
  // ---- Firebase: Web app ----
  static const webApiKey = 'AIzaSyAgdTwMErxg4q1r57CIWhQljlFlcGsUrAo';
  static const webAppId = '1:689100065461:web:2182d0d7ec98f823ea0cfc'; // 1:1234567890:web:abc123...
  static const messagingSenderId = '689100065461'; // 1234567890
  static const projectId = 'niuma-pos-8567'; // niuma-pos-xxxxx
  static const authDomain = 'niuma-pos-8567.firebaseapp.com';
  static const storageBucket = 'niuma-pos-8567.firebasestorage.app';

  // ---- Firebase: iOS app (iPhone + iPad) ----
  static const iosApiKey = webApiKey; // project key (works for iOS too); replace with API_KEY from GoogleService-Info.plist if sign-in fails on iPhone
  static const iosAppId = '1:689100065461:ios:cba534767b07e341ea0cfc'; // 1:1234567890:ios:abc123...
  static const iosBundleId = 'com.niumakitchen.niumaPos'; // created by flutter create --org com.niumakitchen

  // ---- Your website on Cloudflare Pages (used by the iPhone/iPad app to send Telegram messages) ----
  static const siteUrl = 'https://niuma-pos.pages.dev';

  static FirebaseOptions get firebase => kIsWeb
      ? const FirebaseOptions(
          apiKey: webApiKey, appId: webAppId, messagingSenderId: messagingSenderId,
          projectId: projectId, authDomain: authDomain, storageBucket: storageBucket)
      : const FirebaseOptions(
          apiKey: iosApiKey, appId: iosAppId, messagingSenderId: messagingSenderId,
          projectId: projectId, storageBucket: storageBucket, iosBundleId: iosBundleId);

  /// Telegram is sent by the server (Cloudflare Pages Function), so the bot token never sits on a device.
  static String get telegramEndpoint => kIsWeb ? '/api/telegram' : '$siteUrl/api/telegram';
}

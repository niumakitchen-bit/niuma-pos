#!/bin/bash
# Run this on a Mac (once) to make the iPhone / iPad app:  bash tool/setup_ios.sh
# Needs: Xcode, Flutter, CocoaPods (sudo gem install cocoapods).
set -e
cd "$(dirname "$0")/.."
flutter create --platforms=web,ios --org com.niumakitchen --project-name niuma_pos .
rm -f test/widget_test.dart
flutter pub get
PL=ios/Runner/Info.plist
setp() { /usr/libexec/PlistBuddy -c "Set :$1 $2" "$PL" 2>/dev/null || /usr/libexec/PlistBuddy -c "Add :$1 string $2" "$PL"; }
setp NSCameraUsageDescription "Take a photo when clocking in and out, and of supplier receipts."
setp NSPhotoLibraryUsageDescription "Pick a photo for a dish."
setp CFBundleDisplayName "Niuma POS"
flutter build ios --config-only --no-codesign
sed -i '' "s/^# platform :ios.*/platform :ios, '13.0'/" ios/Podfile
grep -q "^platform :ios" ios/Podfile || sed -i '' "1s/^/platform :ios, '13.0'\n/" ios/Podfile
(cd ios && pod install --repo-update)
echo ""
echo "Done. Xcode will open: choose Runner → Signing & Capabilities → Team (your Apple ID), plug in the iPhone/iPad, press Run."
open ios/Runner.xcworkspace

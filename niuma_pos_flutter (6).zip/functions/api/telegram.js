// Cloudflare Pages Function: POST /api/telegram  {text}
// Sends a message to the shop's Telegram chat. Only signed-in Niuma POS users (Firebase ID token) may call it.
//
// Cloudflare Pages → your project → Settings → Variables and Secrets (Production):
//   TG_TOKEN          the bot token from @BotFather         (type: Secret)
//   TG_CHAT_ID        your chat id, e.g. 123456789           (type: Secret)
//   FIREBASE_PROJECT  your Firebase project id, e.g. niuma-pos-1a2b3
//   ALLOWED_EMAILS    owner@gmail.com,buddy@gmail.com        (same emails as firestore.rules)

const JWKS_URL = 'https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com';
const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};
const json = (body, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json', ...cors } });

function b64urlToBytes(s) {
  s = s.replace(/-/g, '+').replace(/_/g, '/');
  while (s.length % 4) s += '=';
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
const b64urlJson = (s) => JSON.parse(new TextDecoder().decode(b64urlToBytes(s)));

async function verifyFirebaseToken(token, projectId) {
  const parts = (token || '').split('.');
  if (parts.length !== 3) throw new Error('bad token');
  const header = b64urlJson(parts[0]);
  const payload = b64urlJson(parts[1]);
  const now = Math.floor(Date.now() / 1000);
  if (header.alg !== 'RS256') throw new Error('bad alg');
  if (payload.aud !== projectId || payload.iss !== `https://securetoken.google.com/${projectId}`) throw new Error('wrong project');
  if (!(payload.exp > now) || !(payload.iat <= now + 60)) throw new Error('expired');
  const jwks = await (await fetch(JWKS_URL, { cf: { cacheTtl: 3600 } })).json();
  const jwk = (jwks.keys || []).find((k) => k.kid === header.kid);
  if (!jwk) throw new Error('unknown key');
  const key = await crypto.subtle.importKey('jwk', jwk, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['verify']);
  const ok = await crypto.subtle.verify('RSASSA-PKCS1-v1_5', key, b64urlToBytes(parts[2]), new TextEncoder().encode(parts[0] + '.' + parts[1]));
  if (!ok) throw new Error('bad signature');
  return payload;
}

export async function onRequestOptions() {
  return new Response(null, { status: 204, headers: cors });
}

export async function onRequestPost({ request, env }) {
  if (!env.TG_TOKEN || !env.TG_CHAT_ID || !env.FIREBASE_PROJECT) return json({ ok: false, error: 'server not set up (TG_TOKEN / TG_CHAT_ID / FIREBASE_PROJECT)' }, 500);
  let user;
  try {
    user = await verifyFirebaseToken((request.headers.get('Authorization') || '').replace(/^Bearer\s+/i, ''), env.FIREBASE_PROJECT);
  } catch (e) {
    return json({ ok: false, error: 'not signed in' }, 401);
  }
  const allowed = (env.ALLOWED_EMAILS || '').split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);
  if (allowed.length && !allowed.includes(String(user.email || '').toLowerCase())) return json({ ok: false, error: 'email not allowed' }, 403);
  let text = '';
  try {
    text = String((await request.json()).text || '').slice(0, 3500);
  } catch (e) {}
  if (!text) return json({ ok: false, error: 'empty message' }, 400);
  const r = await fetch(`https://api.telegram.org/bot${env.TG_TOKEN}/sendMessage`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ chat_id: env.TG_CHAT_ID, text }),
  });
  const j = await r.json().catch(() => ({}));
  return json(j.ok ? { ok: true } : { ok: false, error: j.description || 'telegram error' }, j.ok ? 200 : 502);
}

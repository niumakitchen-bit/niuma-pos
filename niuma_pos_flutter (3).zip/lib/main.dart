import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/date_symbol_data_local.dart';

import 'config.dart';
import 'data/store.dart';
import 'data/util.dart';
import 'ui/shell.dart';
import 'ui/theme.dart';
import 'ui/widgets.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: AppConfig.firebase);
  // Offline-first: work continues without internet and syncs when back online.
  FirebaseFirestore.instance.settings = const Settings(persistenceEnabled: true, cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED);
  for (final l in ['en', 'zh_CN', 'my']) {
    try {
      await initializeDateFormatting(l);
    } catch (_) {}
  }
  await store.load();
  runApp(const NiumaApp());
}

class NiumaApp extends StatelessWidget {
  const NiumaApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Niuma POS',
      debugShowCheckedModeBanner: false,
      navigatorKey: navKey,
      theme: buildTheme(),
      localizationsDelegates: const [GlobalMaterialLocalizations.delegate, GlobalWidgetsLocalizations.delegate, GlobalCupertinoLocalizations.delegate],
      supportedLocales: const [Locale('en'), Locale('zh'), Locale('my')],
      home: const AuthGate(),
    );
  }
}

/// Shows the sign-in page until someone signs in, then starts syncing.
class AuthGate extends StatefulWidget {
  const AuthGate({super.key});
  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  String? _uid;
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Scaffold(backgroundColor: C.bg, body: Center(child: CircularProgressIndicator(color: C.p)));
        }
        final user = snap.data;
        if (user == null) {
          _uid = null;
          return const LoginPage();
        }
        if (_uid != user.uid) {
          _uid = user.uid;
          WidgetsBinding.instance.addPostFrameCallback((_) => store.start());
        }
        return const Shell();
      },
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final pass = TextEditingController();
  String? err;
  bool busy = false;

  Future<void> _go() async {
    setState(() {
      busy = true;
      err = null;
    });
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(email: email.text.trim(), password: pass.text);
    } on FirebaseAuthException catch (e) {
      setState(() => err = switch (e.code) {
            'invalid-credential' || 'wrong-password' || 'user-not-found' || 'invalid-email' => _tx('Wrong email or password.', '邮箱或密码不对。', 'အီးမေးလ် သို့ စကားဝှက် မှားနေသည်။'),
            'network-request-failed' => _tx('No internet connection.', '没有网络。', 'အင်တာနက် မရှိပါ။'),
            _ => e.message ?? e.code,
          });
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  String _tx(String en, String zh, String my) => lang == 'zh' ? zh : (lang == 'my' ? my : en);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: C.bg,
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 400),
            child: CardBox(
              padding: const EdgeInsets.all(28),
              child: AutofillGroup(
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  Row(children: [
                    Container(
                      width: 44, height: 44, alignment: Alignment.center,
                      decoration: BoxDecoration(color: C.p, borderRadius: BorderRadius.circular(14)),
                      child: Text('N', style: ts(20, w: w8, c: Colors.white)),
                    ),
                    hgap(12),
                    Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('Niuma Kitchen', style: ts(18, w: w8)),
                      Text('Heart Garden, Balakong', style: ts(13, w: w6, c: C.muted)),
                    ])),
                  ]),
                  gap(26),
                  FieldBox(_tx('Email', '邮箱', 'အီးမေးလ်'),
                      TextField(controller: email, keyboardType: TextInputType.emailAddress, autofillHints: const [AutofillHints.email], style: ts(15))),
                  gap(14),
                  FieldBox(
                      _tx('Password', '密码', 'စကားဝှက်'),
                      TextField(
                          controller: pass, obscureText: true, autofillHints: const [AutofillHints.password], style: ts(15), onSubmitted: (_) => _go())),
                  if (err != null) ...[gap(14), Note(err!, kind: NK.bad)],
                  gap(20),
                  Btn(_tx('Sign in', '登入', 'ဝင်မည်'), size: BS.lg, full: true, onTap: busy ? null : _go),
                  gap(14),
                  Text(_tx('Accounts are added by the owner in Firebase.', '账号由老板在 Firebase 里添加。', 'အကောင့်ကို ပိုင်ရှင်က ထည့်ပေးသည်။'),
                      textAlign: TextAlign.center, style: ts(12.5, c: C.muted)),
                  if (kIsWeb) ...[gap(4), Text('niuma-pos', textAlign: TextAlign.center, style: ts(11, c: C.line2))],
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

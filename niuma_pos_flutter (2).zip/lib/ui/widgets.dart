// Reusable pieces matching the web app's CSS components (.btn, .pill, .seg, .tag, .card, .note, ...).
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../data/consts.dart';
import '../data/logic.dart';
import '../data/store.dart';
import '../data/util.dart';
import '../icons_data.dart';
import '../services.dart';
import 'theme.dart';

class Ic extends StatelessWidget {
  final String name;
  final double size;
  final Color? color;
  const Ic(this.name, {super.key, this.size = 20, this.color});
  @override
  Widget build(BuildContext context) {
    final c = color ?? DefaultTextStyle.of(context).style.color ?? C.ink;
    return SvgPicture.string(
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#000" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${kIconPaths[name] ?? ''}</svg>',
      width: size,
      height: size,
      colorFilter: ColorFilter.mode(c, BlendMode.srcIn),
    );
  }
}

enum BK { primary, sec, soft, danger, ok, ghost, tg }

enum BS { sm, md, lg }

class Btn extends StatelessWidget {
  final String label;
  final String? icon;
  final VoidCallback? onTap;
  final BK kind;
  final BS size;
  final bool full;
  final Widget? trailing;
  final Color? bg;
  const Btn(this.label,
      {super.key, this.icon, this.onTap, this.kind = BK.primary, this.size = BS.md, this.full = false, this.trailing, this.bg});
  @override
  Widget build(BuildContext context) {
    final dis = onTap == null;
    Color b, f;
    Color? border;
    switch (kind) {
      case BK.primary:
        b = bg ?? C.p;
        f = Colors.white;
      case BK.sec:
        b = C.surface;
        f = C.ink;
        border = C.line2;
      case BK.soft:
        b = C.pSoft;
        f = C.p;
      case BK.danger:
        b = C.surface;
        f = C.bad;
        border = const Color(0xFFF3CACA);
      case BK.ok:
        b = C.ok;
        f = Colors.white;
      case BK.ghost:
        b = Colors.transparent;
        f = C.ink2;
      case BK.tg:
        b = const Color(0xFF229ED9);
        f = Colors.white;
    }
    if (dis && (kind == BK.primary || kind == BK.ok || kind == BK.tg)) {
      b = C.disabled;
      f = Colors.white;
    }
    final h = size == BS.sm ? 36.0 : (size == BS.lg ? 56.0 : 44.0);
    final fs = size == BS.sm ? 13.5 : (size == BS.lg ? 16.0 : 14.5);
    final r = size == BS.sm ? 10.0 : (size == BS.lg ? 14.0 : 12.0);
    final pad = size == BS.sm ? 12.0 : (size == BS.lg ? 22.0 : 18.0);
    final child = Row(
      mainAxisSize: full ? MainAxisSize.max : MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (icon != null) ...[Ic(icon!, size: size == BS.lg ? 20 : 17, color: f), const SizedBox(width: 8)],
        Flexible(child: Text(label, overflow: TextOverflow.ellipsis, maxLines: 1, style: ts(fs, w: w7, c: f))),
        if (trailing != null) ...[const SizedBox(width: 8), trailing!],
      ],
    );
    return Opacity(
      opacity: dis && (kind == BK.sec || kind == BK.soft || kind == BK.danger || kind == BK.ghost) ? 0.45 : 1,
      child: Material(
        color: b,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(r),
            side: border != null ? BorderSide(color: border, width: 1.5) : BorderSide.none),
        child: InkWell(
          borderRadius: BorderRadius.circular(r),
          onTap: onTap,
          child: Container(height: h, padding: EdgeInsets.symmetric(horizontal: pad), alignment: Alignment.center, child: child),
        ),
      ),
    );
  }
}

class IconBtn extends StatelessWidget {
  final String icon;
  final VoidCallback? onTap;
  final double size;
  final Color? color;
  const IconBtn(this.icon, {super.key, this.onTap, this.size = 40, this.color});
  @override
  Widget build(BuildContext context) => Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onTap,
          child: SizedBox(width: size, height: size, child: Center(child: Ic(icon, size: 17, color: color ?? C.ink2))),
        ),
      );
}

class LinkBtn extends StatelessWidget {
  final String label;
  final String? icon;
  final VoidCallback? onTap;
  final Color color;
  const LinkBtn(this.label, {super.key, this.icon, this.onTap, this.color = C.p});
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            if (icon != null) ...[Ic(icon!, size: 15, color: color), const SizedBox(width: 5)],
            Flexible(child: Text(label, style: ts(13, w: w7, c: color))),
          ]),
        ),
      );
}

class PillBtn extends StatelessWidget {
  final String label;
  final bool on;
  final VoidCallback? onTap;
  final Color? dot;
  final Widget? trailing;
  final String? icon;
  const PillBtn(this.label, {super.key, this.on = false, this.onTap, this.dot, this.trailing, this.icon});
  @override
  Widget build(BuildContext context) {
    final f = on ? Colors.white : C.ink2;
    return Material(
      color: on ? C.ink : C.surface,
      shape: StadiumBorder(side: on ? BorderSide.none : const BorderSide(color: C.line2, width: 1.5)),
      child: InkWell(
        customBorder: const StadiumBorder(),
        onTap: onTap,
        child: Container(
          height: 38,
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            if (dot != null) ...[
              Container(width: 8, height: 8, decoration: BoxDecoration(color: dot, shape: BoxShape.circle)),
              const SizedBox(width: 7)
            ],
            if (icon != null) ...[Ic(icon!, size: 16, color: f), const SizedBox(width: 6)],
            Text(label, style: ts(13.5, w: w7, c: f)),
            if (trailing != null) ...[const SizedBox(width: 6), trailing!],
          ]),
        ),
      ),
    );
  }
}

class Seg<T> extends StatelessWidget {
  final List<(T, String)> items;
  final T value;
  final ValueChanged<T> onChanged;
  final bool expand;
  const Seg({super.key, required this.items, required this.value, required this.onChanged, this.expand = false});
  @override
  Widget build(BuildContext context) {
    Widget btn((T, String) it) {
      final on = it.$1 == value;
      final b = GestureDetector(
        onTap: () => onChanged(it.$1),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          height: 36,
          padding: const EdgeInsets.symmetric(horizontal: 14),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: on ? C.surface : Colors.transparent,
            borderRadius: BorderRadius.circular(9),
            boxShadow: on ? const [BoxShadow(color: Color(0x1A16131F), blurRadius: 3, offset: Offset(0, 1))] : null,
          ),
          child: Text(it.$2, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(13.5, w: w7, c: on ? C.ink : C.ink2)),
        ),
      );
      return expand ? Expanded(child: b) : b;
    }

    final children = items.map(btn).toList();
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(color: C.sunken, borderRadius: BorderRadius.circular(12)),
      child: expand ? Row(children: children) : Wrap(spacing: 2, runSpacing: 2, children: children),
    );
  }
}

enum TK { ok, warn, bad, mute, p, del, pur }

class Tag extends StatelessWidget {
  final String text;
  final TK kind;
  final String? icon;
  final Color? color;
  final double size;
  const Tag(this.text, {super.key, this.kind = TK.mute, this.icon, this.color, this.size = 12});
  @override
  Widget build(BuildContext context) {
    Color b, f;
    switch (kind) {
      case TK.ok:
        b = C.okSoft;
        f = C.ok;
      case TK.warn:
        b = C.warnSoft;
        f = C.warn;
      case TK.bad:
        b = C.badSoft;
        f = C.bad;
      case TK.mute:
        b = C.sunken;
        f = C.muted;
      case TK.p:
      case TK.pur:
        b = C.pSoft;
        f = C.p;
      case TK.del:
        b = C.delSoft;
        f = C.del;
    }
    if (color != null) {
      f = color!;
      b = color!.withValues(alpha: 0.10);
    }
    return Container(
      padding: EdgeInsets.symmetric(horizontal: size > 12 ? 12 : 9, vertical: size > 12 ? 6 : 4),
      decoration: BoxDecoration(color: b, borderRadius: BorderRadius.circular(999)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        if (icon != null) ...[Ic(icon!, size: 14, color: f), const SizedBox(width: 5)],
        Text(text, style: ts(size, w: w7, c: f)),
      ]),
    );
  }
}

class CardBox extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color color;
  final Color border;
  final double radius;
  final Border? customBorder;
  const CardBox(
      {super.key, required this.child, this.padding = const EdgeInsets.all(18), this.color = C.surface, this.border = C.line, this.radius = 20, this.customBorder});
  @override
  Widget build(BuildContext context) => Container(
        padding: padding,
        decoration: BoxDecoration(
            color: color, borderRadius: BorderRadius.circular(radius), border: customBorder ?? Border.all(color: border)),
        child: child,
      );
}

enum NK { info, warn, bad, ok }

class Note extends StatelessWidget {
  final String text;
  final NK kind;
  final String? icon;
  final Widget? extra;
  const Note(this.text, {super.key, this.kind = NK.info, this.icon, this.extra});
  @override
  Widget build(BuildContext context) {
    final (Color b, Color f) = switch (kind) {
      NK.info => (C.pSoft, const Color(0xFF4C1D95)),
      NK.warn => (C.warnSoft, const Color(0xFF92400E)),
      NK.bad => (C.badSoft, const Color(0xFF991B1B)),
      NK.ok => (C.okSoft, const Color(0xFF166534)),
    };
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(color: b, borderRadius: BorderRadius.circular(12)),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(padding: const EdgeInsets.only(top: 1), child: Ic(icon ?? (kind == NK.info ? 'info' : (kind == NK.ok ? 'check' : 'alert')), size: 17, color: f)),
        const SizedBox(width: 10),
        Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(text, style: ts(13.5, w: w6, c: f, h: 1.45)),
          if (extra != null) extra!,
        ])),
      ]),
    );
  }
}

class H2 extends StatelessWidget {
  final String text;
  final double size;
  const H2(this.text, {super.key, this.size = 16});
  @override
  Widget build(BuildContext context) => Text(text, style: ts(size, w: w8, ls: -0.1));
}

class Sub extends StatelessWidget {
  final String text;
  final Color color;
  const Sub(this.text, {super.key, this.color = C.muted});
  @override
  Widget build(BuildContext context) => Padding(
      padding: const EdgeInsets.only(top: 3), child: Text(text, style: ts(13.5, c: color, h: 1.45)));
}

class Lbl extends StatelessWidget {
  final String text;
  final Widget? trailing;
  const Lbl(this.text, {super.key, this.trailing});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 18, bottom: 10),
        child: Row(children: [
          Flexible(child: Text(text, style: ts(13, w: w7, c: C.ink2))),
          if (trailing != null) ...[const SizedBox(width: 8), trailing!],
        ]),
      );
}

class Section extends StatelessWidget {
  final String? title;
  final Widget? titleWidget;
  final Widget? trailing;
  final Widget child;
  final String? sub;
  const Section({super.key, this.title, this.titleWidget, this.trailing, required this.child, this.sub});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 26),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (title != null || titleWidget != null || trailing != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Row(children: [
                Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  titleWidget ?? H2(title ?? ''),
                  if (sub != null) Sub(sub!),
                ])),
                if (trailing != null) trailing!,
              ]),
            ),
          child,
        ]),
      );
}

/// Dish picture: the uploaded photo, or a monogram on a soft tint.
class Pic extends StatelessWidget {
  final dynamic it;
  final double w, h, radius, mono;
  const Pic(this.it, {super.key, this.w = 44, this.h = 44, this.radius = 10, this.mono = 20});
  @override
  Widget build(BuildContext context) {
    if (it == null) {
      return Container(width: w, height: h, decoration: BoxDecoration(color: C.sunken, borderRadius: BorderRadius.circular(radius)));
    }
    final bytes = photoBytes(it['photo'] is String ? it['photo'] as String : null);
    if (bytes != null) {
      return ClipRRect(borderRadius: BorderRadius.circular(radius), child: Image.memory(bytes, width: w, height: h, fit: BoxFit.cover, gaplessPlayback: true));
    }
    final k = I(it['tint'] ?? 5) % kTint.length;
    final names = Mp(it['names']);
    final String ch;
    if (lang == 'zh') {
      final m = Str(it['mono']);
      final z = Str(names['zh']).trim();
      ch = m.isNotEmpty ? m : (z.isNotEmpty ? z.characters.first : '?');
    } else {
      final code = Str(it['code']);
      final n = nm(names).trim();
      ch = code.isNotEmpty ? code : (n.isNotEmpty ? n.characters.first.toUpperCase() : '?');
    }
    return Container(
      width: w,
      height: h,
      alignment: Alignment.center,
      decoration: BoxDecoration(color: kTint[k], borderRadius: BorderRadius.circular(radius)),
      child: FittedBox(
          fit: BoxFit.scaleDown,
          child: Padding(
            padding: const EdgeInsets.all(4),
            child: Text(ch, style: ts(mono, w: w7, c: kTink[k].withValues(alpha: 0.9), h: 1)),
          )),
    );
  }
}

class StepperBox extends StatelessWidget {
  final String value;
  final VoidCallback onMinus, onPlus;
  final double height;
  const StepperBox({super.key, required this.value, required this.onMinus, required this.onPlus, this.height = 32});
  @override
  Widget build(BuildContext context) => Container(
        height: height,
        decoration: BoxDecoration(color: C.sunken, borderRadius: BorderRadius.circular(10)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          InkWell(onTap: onMinus, child: SizedBox(width: 30, height: height, child: const Center(child: Ic('minus', size: 15, color: C.ink2)))),
          ConstrainedBox(
              constraints: const BoxConstraints(minWidth: 20),
              child: Text(value, textAlign: TextAlign.center, style: ts(13.5, w: w8))),
          InkWell(onTap: onPlus, child: SizedBox(width: 30, height: height, child: const Center(child: Ic('plus', size: 15, color: C.ink2)))),
        ]),
      );
}

/// Over/short value: green "Exact", red short, orange over.
class VarTxt extends StatelessWidget {
  final num? v;
  final double size;
  const VarTxt(this.v, {super.key, this.size = 14.5});
  @override
  Widget build(BuildContext context) {
    if (v == null) return Text('–', style: ts(size, c: C.muted));
    final x = v!;
    final exact = x.abs() < .005;
    return Text(exact ? t('exact') : '${x > 0 ? '+' : ''}${rm(x)}',
        style: ts(size, w: w8, c: exact ? C.ok : (x < 0 ? C.bad : C.warn)));
  }
}

class KV extends StatelessWidget {
  final String label;
  final Widget value;
  const KV(this.label, this.value, {super.key});
  KV.txt(this.label, String v, {super.key, bool bold = false}) : value = Text(v, style: ts(14.5, w: bold ? w8 : w6));
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(children: [
          Expanded(child: Text(label, style: ts(14.5, w: w6, c: C.muted))),
          value,
        ]),
      );
}

class FieldBox extends StatelessWidget {
  final String label;
  final Widget child;
  const FieldBox(this.label, this.child, {super.key});
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(padding: const EdgeInsets.only(bottom: 7), child: Text(label, style: ts(13, w: w7, c: C.ink2))),
        child,
      ]);
}

/// Text input that keeps its own controller (safe across rebuilds).
class Inp extends StatefulWidget {
  final String value;
  final ValueChanged<String>? onChanged;
  final ValueChanged<String>? onSubmitted;
  final String? hint;
  final bool number, big, small, obscure, autofocus;
  final TextAlign align;
  final double? width;
  final TextEditingController? controller;
  const Inp(
      {super.key, this.value = '', this.onChanged, this.onSubmitted, this.hint, this.number = false, this.big = false, this.small = false,
      this.obscure = false, this.autofocus = false, this.align = TextAlign.start, this.width, this.controller});
  @override
  State<Inp> createState() => _InpState();
}

class _InpState extends State<Inp> {
  late final TextEditingController c = widget.controller ?? TextEditingController(text: widget.value);
  @override
  Widget build(BuildContext context) {
    final f = TextField(
      controller: c,
      autofocus: widget.autofocus,
      obscureText: widget.obscure,
      textAlign: widget.align,
      keyboardType: widget.number ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.text,
      inputFormatters: widget.number ? [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))] : null,
      onChanged: widget.onChanged,
      onSubmitted: widget.onSubmitted,
      style: ts(widget.big ? 22 : (widget.small ? 14 : 15), w: widget.big ? w8 : w5),
      decoration: InputDecoration(
        hintText: widget.hint,
        contentPadding: EdgeInsets.symmetric(horizontal: widget.small ? 10 : 14, vertical: widget.big ? 16 : (widget.small ? 10 : 13)),
      ),
    );
    return widget.width != null ? SizedBox(width: widget.width, child: f) : f;
  }
}

/* ---------------- dialogs ---------------- */
bool isNarrow(BuildContext c) => MediaQuery.sizeOf(c).width < 700;

/// Opens a dialog (bottom sheet on phones). The dialog rebuilds when the store changes.
Future<T?> showDlg<T>(BuildContext context, WidgetBuilder builder, {bool dismissible = true}) async {
  store.dialogs++;
  try {
    Widget wrap(BuildContext c) => ListenableBuilder(listenable: store, builder: (c2, _) => builder(c2));
    if (isNarrow(context)) {
      return await showModalBottomSheet<T>(
        context: context,
        isScrollControlled: true,
        isDismissible: dismissible,
        enableDrag: dismissible,
        backgroundColor: Colors.transparent,
        builder: (c) => Padding(padding: EdgeInsets.only(bottom: MediaQuery.viewInsetsOf(c).bottom), child: wrap(c)),
      );
    }
    return await showDialog<T>(
        context: context, barrierDismissible: dismissible, barrierColor: const Color(0x7316131F), builder: (c) => Center(child: wrap(c)));
  } finally {
    store.dialogClosed();
  }
}

class Dlg extends StatelessWidget {
  final String title;
  final Widget? titleWidget;
  final String? sub;
  final String? kicker;
  final Widget body;
  final List<Widget> foot;
  final bool wide;
  final Widget? header;
  final Color? headColor;
  final bool closeBtn;
  final double? width;
  const Dlg(
      {super.key, this.title = '', this.titleWidget, this.sub, this.kicker, required this.body, this.foot = const [], this.wide = false,
      this.header, this.headColor, this.closeBtn = true, this.width});
  @override
  Widget build(BuildContext context) {
    final narrow = isNarrow(context);
    final maxH = MediaQuery.sizeOf(context).height * (narrow ? 0.94 : 0.9);
    final w = width ?? (wide ? 680.0 : 520.0);
    final light = headColor != null;
    return Material(
      color: C.surface,
      borderRadius: narrow ? const BorderRadius.vertical(top: Radius.circular(24)) : BorderRadius.circular(24),
      clipBehavior: Clip.antiAlias,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: narrow ? double.infinity : w, maxHeight: maxH),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          header ??
              Container(
                color: headColor,
                padding: const EdgeInsets.fromLTRB(22, 20, 14, 12),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    if (kicker != null) Padding(padding: const EdgeInsets.only(bottom: 4), child: Text(kicker!, style: ts(12.5, w: w7, c: light ? Colors.white70 : C.muted))),
                    titleWidget ?? Text(title, style: ts(19, w: w8, ls: -0.3, c: light ? Colors.white : C.ink)),
                    if (sub != null && sub!.isNotEmpty) Sub(sub!, color: light ? Colors.white70 : C.muted),
                  ])),
                  if (closeBtn) IconBtn('x', onTap: () => Navigator.of(context).pop(), color: light ? Colors.white : C.ink2),
                ]),
              ),
          Flexible(child: SingleChildScrollView(padding: const EdgeInsets.fromLTRB(22, 6, 22, 18), child: body)),
          if (foot.isNotEmpty)
            Container(
              decoration: const BoxDecoration(border: Border(top: BorderSide(color: C.line))),
              padding: EdgeInsets.fromLTRB(18, 14, 18, 14 + (narrow ? MediaQuery.paddingOf(context).bottom : 0)),
              child: Row(children: _gap(foot)),
            ),
        ]),
      ),
    );
  }

  List<Widget> _gap(List<Widget> l) {
    final out = <Widget>[];
    for (var i = 0; i < l.length; i++) {
      if (i > 0) out.add(const SizedBox(width: 10));
      out.add(l[i]);
    }
    return out;
  }
}

Widget gap(double h) => SizedBox(height: h);
Widget hgap(double w) => SizedBox(width: w);

/// Wrap a list of widgets with spacing.
Widget wrapRow(List<Widget> c, {double spacing = 8, double run = 8}) => Wrap(spacing: spacing, runSpacing: run, crossAxisAlignment: WrapCrossAlignment.center, children: c);

class Dot extends StatelessWidget {
  final Color color;
  final double size;
  const Dot(this.color, {super.key, this.size = 8});
  @override
  Widget build(BuildContext context) => Container(width: size, height: size, decoration: BoxDecoration(color: color, shape: BoxShape.circle));
}

/// Number badge (order number square).
class NoBox extends StatelessWidget {
  final String text;
  final Color color;
  final double size;
  const NoBox(this.text, this.color, {super.key, this.size = 46});
  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        alignment: Alignment.center,
        decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(size * 0.3)),
        child: Text(text, style: ts(16, w: w8, c: Colors.white)),
      );
}

/// Simple table like the web .cmp tables: first column left, others right.
class SimpleTable extends StatelessWidget {
  final List<String> head;
  final List<List<Widget>> rows;
  final List<VoidCallback?>? onTap;
  final double fs;
  const SimpleTable({super.key, required this.head, required this.rows, this.onTap, this.fs = 14});
  @override
  Widget build(BuildContext context) {
    Widget cell(Widget w, int i, {bool header = false}) => Padding(
          padding: EdgeInsets.fromLTRB(i == 0 ? 0 : 12, header ? 8 : 10, 0, header ? 8 : 10),
          child: Align(alignment: i == 0 ? Alignment.centerLeft : Alignment.centerRight, child: w),
        );
    return Table(
      defaultVerticalAlignment: TableCellVerticalAlignment.middle,
      columnWidths: const {0: FlexColumnWidth(1.3)},
      defaultColumnWidth: const IntrinsicColumnWidth(),
      children: [
        TableRow(
            decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: C.line))),
            children: [for (var i = 0; i < head.length; i++) cell(Text(head[i], style: ts(12.5, w: w7, c: C.muted)), i, header: true)]),
        for (var r = 0; r < rows.length; r++)
          TableRow(
            decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: C.line))),
            children: [
              for (var i = 0; i < rows[r].length; i++)
                TableRowInkWell(onTap: onTap != null && r < onTap!.length ? onTap![r] : null, child: cell(DefaultTextStyle(style: ts(fs, w: w6), child: rows[r][i]), i)),
            ],
          ),
      ],
    );
  }
}

/// Pager: 5 rows a page with Previous / Next.
class Pager extends StatelessWidget {
  final int page, pages;
  final ValueChanged<int> onPage;
  const Pager({super.key, required this.page, required this.pages, required this.onPage});
  @override
  Widget build(BuildContext context) {
    if (pages <= 1) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 10, bottom: 6),
      child: Row(mainAxisAlignment: MainAxisAlignment.end, children: [
        Btn(t('prev'), icon: 'chev', kind: BK.sec, size: BS.sm, onTap: page > 0 ? () => onPage(page - 1) : null),
        hgap(12),
        Text(t('pageOf').replaceAll('{p}', '${page + 1}').replaceAll('{n}', '$pages'), style: ts(13, w: w7, c: C.muted)),
        hgap(12),
        Btn(t('next'), kind: BK.sec, size: BS.sm, onTap: page < pages - 1 ? () => onPage(page + 1) : null,
            trailing: Transform.flip(flipX: true, child: const Ic('chev', size: 15))),
      ]),
    );
  }
}

/// Photo thumbnail (tap to view).
class PhotoThumb extends StatelessWidget {
  final String? src;
  final String label;
  final double size;
  const PhotoThumb(this.src, this.label, {super.key, this.size = 38});
  @override
  Widget build(BuildContext context) {
    final b = photoBytes(src);
    if (b == null) {
      return Container(
          width: size, height: size, alignment: Alignment.center,
          decoration: BoxDecoration(color: C.sunken, borderRadius: BorderRadius.circular(10)),
          child: Text(label.isEmpty ? '?' : label.characters.first, style: ts(14, w: w8, c: C.muted)));
    }
    return GestureDetector(
      onTap: () => showDlg(context, (c) => Dlg(body: ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.memory(b)), foot: [
            Expanded(child: Btn(t('close'), kind: BK.sec, onTap: () => Navigator.pop(c))),
          ])),
      child: ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.memory(b, width: size, height: size, fit: BoxFit.cover)),
    );
  }
}

/// Denomination count grid (notes + coins) used for opening/closing cash and petty cash.
class DenGrid extends StatelessWidget {
  final Map<String, dynamic> counts;
  final VoidCallback onChanged;
  final num? expected;
  const DenGrid({super.key, required this.counts, required this.onChanged, this.expected});
  @override
  Widget build(BuildContext context) {
    final narrow = isNarrow(context);
    Widget cell(num d) {
      final k = denKey(d);
      final n = I(counts[k]);
      return Container(
        padding: const EdgeInsets.fromLTRB(14, 10, 10, 10),
        decoration: BoxDecoration(border: Border.all(color: C.line2, width: 1.5), borderRadius: BorderRadius.circular(14)),
        child: Row(children: [
          Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(denLbl(d), style: ts(15, w: w8)),
            Text(rm(d * n), style: ts(12, w: w6, c: C.muted)),
          ])),
          _DenStepper(
            key: ValueKey('den$k'),
            value: n,
            onChanged: (v) {
              if (v <= 0) {
                counts.remove(k);
              } else {
                counts[k] = v;
              }
              onChanged();
            },
          ),
        ]),
      );
    }

    Widget grid(List<num> ds) => GridView.count(
          crossAxisCount: narrow ? 1 : 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 8,
          crossAxisSpacing: 8,
          childAspectRatio: narrow ? 5.2 : 3.4,
          children: ds.map(cell).toList(),
        );
    final tot = denTotal(counts);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Lbl(t('notes')),
      grid(kNotes),
      Lbl(t('coins')),
      grid(kCoins),
      gap(14),
      Row(children: [Expanded(child: Text(t('cashTotal'), style: ts(15, w: w7))), Text(rm(tot), style: ts(24, w: w8, ls: -0.5))]),
      if (expected != null) ...[
        gap(12),
        ExpBox([
          (t('expected'), Text(rm(expected), style: ts(17, w: w8))),
          (t('counted'), Text(rm(tot), style: ts(17, w: w8))),
          (t('overShort'), VarTxt(tot > 0 ? tot - expected! : null, size: 17)),
        ]),
      ],
    ]);
  }
}

class _DenStepper extends StatefulWidget {
  final int value;
  final ValueChanged<int> onChanged;
  const _DenStepper({super.key, required this.value, required this.onChanged});
  @override
  State<_DenStepper> createState() => _DenStepperState();
}

class _DenStepperState extends State<_DenStepper> {
  late final c = TextEditingController(text: widget.value > 0 ? '${widget.value}' : '');
  final f = FocusNode();
  @override
  void didUpdateWidget(covariant _DenStepper old) {
    super.didUpdateWidget(old);
    if (!f.hasFocus) {
      final s = widget.value > 0 ? '${widget.value}' : '';
      if (c.text != s) c.text = s;
    }
  }

  @override
  Widget build(BuildContext context) => Container(
        height: 40,
        decoration: BoxDecoration(color: C.sunken, borderRadius: BorderRadius.circular(10)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          InkWell(
              onTap: () => widget.onChanged((widget.value - 1).clamp(0, 9999)),
              child: const SizedBox(width: 34, height: 40, child: Center(child: Ic('minus', size: 15, color: C.ink2)))),
          SizedBox(
            width: 46,
            child: TextField(
              controller: c,
              focusNode: f,
              textAlign: TextAlign.center,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              style: ts(15, w: w8),
              decoration: const InputDecoration(
                  border: InputBorder.none, enabledBorder: InputBorder.none, focusedBorder: InputBorder.none, filled: false,
                  hintText: '0', contentPadding: EdgeInsets.zero, isDense: true),
              onChanged: (s) => widget.onChanged(int.tryParse(s) ?? 0),
            ),
          ),
          InkWell(
              onTap: () => widget.onChanged(widget.value + 1),
              child: const SizedBox(width: 34, height: 40, child: Center(child: Ic('plus', size: 15, color: C.ink2)))),
        ]),
      );
}

/// Row of small "label / big value" boxes (web .expbox / .reg).
class ExpBox extends StatelessWidget {
  final List<(String, Widget)> items;
  const ExpBox(this.items, {super.key});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: C.sunken, borderRadius: BorderRadius.circular(14)),
        child: Wrap(spacing: 18, runSpacing: 12, children: [
          for (final it in items)
            ConstrainedBox(
              constraints: const BoxConstraints(minWidth: 110),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                Text(it.$1, style: ts(12, w: w7, c: C.muted)),
                gap(4),
                it.$2,
              ]),
            ),
        ]),
      );
}

/// Purple chips for required choices, orange for app options.
class ChoiceChips extends StatelessWidget {
  final dynamic line;
  const ChoiceChips(this.line, {super.key});
  @override
  Widget build(BuildContext context) {
    final c = [sizeWord(line), ...codeChoices(line)].where((s) => s.isNotEmpty).toList();
    final o = L(line['opts']).map((x) => nm(x['names'])).toList();
    if (c.isEmpty && o.isEmpty) return const SizedBox.shrink();
    Widget chip(String s, bool p) => Container(
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
          decoration: BoxDecoration(color: p ? C.pSoft : C.delSoft, borderRadius: BorderRadius.circular(999)),
          child: Text(s, style: ts(12.5, w: w7, c: p ? C.p : const Color(0xFF9A3412))),
        );
    return Padding(
      padding: const EdgeInsets.only(top: 5),
      child: Wrap(spacing: 5, runSpacing: 5, children: [...c.map((s) => chip(s, true)), ...o.map((s) => chip(s, false))]),
    );
  }
}

/// Confirm dialog helper.
Future<bool> confirmDlg(BuildContext context, String title, {String? sub, Widget? body, String? okLabel, bool danger = true}) async {
  final r = await showDlg<bool>(
      context,
      (c) => Dlg(title: title, sub: sub, body: body ?? const SizedBox.shrink(), foot: [
            Btn(t('cancel'), kind: BK.sec, onTap: () => Navigator.pop(c, false)),
            const Spacer(),
            Btn(okLabel ?? t('ok'), bg: danger ? C.bad : null, onTap: () => Navigator.pop(c, true)),
          ]));
  return r == true;
}
